package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait TriStateCheckBoxState extends js.Object

object TriStateCheckBoxState{
  @JSGlobal("sap.ui.commons.TriStateCheckBoxState.Checked")
  @js.native
  object Checked extends TriStateCheckBoxState

  @JSGlobal("sap.ui.commons.TriStateCheckBoxState.Mixed")
  @js.native
  object Mixed extends TriStateCheckBoxState

  @JSGlobal("sap.ui.commons.TriStateCheckBoxState.Unchecked")
  @js.native
  object Unchecked extends TriStateCheckBoxState
}

/* copy to Enum.scala
sealed trait TriStateCheckBoxState{
  private[ui] def toFacade: sap.ui.commons.TriStateCheckBoxState
}

object TriStateCheckBoxState {
  def fromFacade(s: ui.commons.TriStateCheckBoxState): TriStateCheckBoxState = s match {
    case ui.commons.TriStateCheckBoxState.Checked => TriStateCheckBoxState.Checked
    case ui.commons.TriStateCheckBoxState.Mixed => TriStateCheckBoxState.Mixed
    case ui.commons.TriStateCheckBoxState.Unchecked => TriStateCheckBoxState.Unchecked
   case _ =>
     throw new UnsupportedOperationException(s"Unknown TriStateCheckBoxState: $s")
  }
  
  object Checked extends TriStateCheckBoxState {
    override private[ui] def toFacade: ui.commons.TriStateCheckBoxState = ui.commons.TriStateCheckBoxState.Checked
  }

  object Mixed extends TriStateCheckBoxState {
    override private[ui] def toFacade: ui.commons.TriStateCheckBoxState = ui.commons.TriStateCheckBoxState.Mixed
  }

  object Unchecked extends TriStateCheckBoxState {
    override private[ui] def toFacade: ui.commons.TriStateCheckBoxState = ui.commons.TriStateCheckBoxState.Unchecked
  }

}
*/
