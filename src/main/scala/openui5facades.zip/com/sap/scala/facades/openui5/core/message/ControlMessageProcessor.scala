
package com.sap.scala.facades.openui5.core.message

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.message.ControlMessageProcessor")
@js.native
class ControlMessageProcessor() extends MessageProcessor {
  def checkMessages(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
//  def setMessages(vMessages: /*TODO Type: 'map' not found.*/): Unit = js.native
}
     