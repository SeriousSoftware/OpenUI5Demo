
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.DatePicker")
@js.native
class DatePicker() extends TextField {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireChange(bInvalidValue: Boolean): this.type = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getLocale(): String = js.native
  def getMetadata(): Metadata = js.native
  def getYyyymmdd(): String = js.native
  def setLocale(sLocale: String): this.type = js.native
  def setYyyymmdd(sYyyymmdd: String): this.type = js.native
}
     