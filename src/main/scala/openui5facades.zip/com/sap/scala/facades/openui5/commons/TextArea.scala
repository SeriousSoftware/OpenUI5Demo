
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Wrapping}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.TextArea")
@js.native
class TextArea() extends TextField {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getCols(): Int = js.native
  def getCursorPos(): Int = js.native
  def getExplanation(): String = js.native
  def getHeight(): CSSSize = js.native
  def getLabeledBy(): String = js.native
  def getMetadata(): Metadata = js.native
  def getRows(): Int = js.native
  def getWrapping(): Wrapping = js.native
  def setCols(iCols: Int): this.type = js.native
  def setCursorPos(iCursorPos: Int): this.type = js.native
  def setExplanation(sExplanation: String): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setLabeledBy(sLabeledBy: String): this.type = js.native
  def setMaxLength(iMaxLength: Int): this.type = js.native
  def setRows(iRows: Int): this.type = js.native
  def setWrapping(sWrapping: Wrapping): this.type = js.native
}
     