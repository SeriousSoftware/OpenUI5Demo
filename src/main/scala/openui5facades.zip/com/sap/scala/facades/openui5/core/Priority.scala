package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Priority extends js.Object

object Priority{
  @JSGlobal("sap.ui.core.Priority.High")
  @js.native
  object High extends Priority

  @JSGlobal("sap.ui.core.Priority.Low")
  @js.native
  object Low extends Priority

  @JSGlobal("sap.ui.core.Priority.Medium")
  @js.native
  object Medium extends Priority

  @JSGlobal("sap.ui.core.Priority.None")
  @js.native
  object None extends Priority
}

/* copy to Enum.scala
sealed trait Priority{
  private[ui] def toFacade: sap.ui.core.Priority
}

object Priority {
  def fromFacade(s: ui.core.Priority): Priority = s match {
    case ui.core.Priority.High => Priority.High
    case ui.core.Priority.Low => Priority.Low
    case ui.core.Priority.Medium => Priority.Medium
    case ui.core.Priority.None => Priority.None
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Priority: $s")
  }
  
  object High extends Priority {
    override private[ui] def toFacade: ui.core.Priority = ui.core.Priority.High
  }

  object Low extends Priority {
    override private[ui] def toFacade: ui.core.Priority = ui.core.Priority.Low
  }

  object Medium extends Priority {
    override private[ui] def toFacade: ui.core.Priority = ui.core.Priority.Medium
  }

  object None extends Priority {
    override private[ui] def toFacade: ui.core.Priority = ui.core.Priority.None
  }

}
*/
