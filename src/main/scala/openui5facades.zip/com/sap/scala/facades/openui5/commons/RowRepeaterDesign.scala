package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait RowRepeaterDesign extends js.Object

object RowRepeaterDesign{
  @JSGlobal("sap.ui.commons.RowRepeaterDesign.BareShell")
  @js.native
  object BareShell extends RowRepeaterDesign

  @JSGlobal("sap.ui.commons.RowRepeaterDesign.Standard")
  @js.native
  object Standard extends RowRepeaterDesign

  @JSGlobal("sap.ui.commons.RowRepeaterDesign.Transparent")
  @js.native
  object Transparent extends RowRepeaterDesign
}

/* copy to Enum.scala
sealed trait RowRepeaterDesign{
  private[ui] def toFacade: sap.ui.commons.RowRepeaterDesign
}

object RowRepeaterDesign {
  def fromFacade(s: ui.commons.RowRepeaterDesign): RowRepeaterDesign = s match {
    case ui.commons.RowRepeaterDesign.BareShell => RowRepeaterDesign.BareShell
    case ui.commons.RowRepeaterDesign.Standard => RowRepeaterDesign.Standard
    case ui.commons.RowRepeaterDesign.Transparent => RowRepeaterDesign.Transparent
   case _ =>
     throw new UnsupportedOperationException(s"Unknown RowRepeaterDesign: $s")
  }
  
  object BareShell extends RowRepeaterDesign {
    override private[ui] def toFacade: ui.commons.RowRepeaterDesign = ui.commons.RowRepeaterDesign.BareShell
  }

  object Standard extends RowRepeaterDesign {
    override private[ui] def toFacade: ui.commons.RowRepeaterDesign = ui.commons.RowRepeaterDesign.Standard
  }

  object Transparent extends RowRepeaterDesign {
    override private[ui] def toFacade: ui.commons.RowRepeaterDesign = ui.commons.RowRepeaterDesign.Transparent
  }

}
*/
