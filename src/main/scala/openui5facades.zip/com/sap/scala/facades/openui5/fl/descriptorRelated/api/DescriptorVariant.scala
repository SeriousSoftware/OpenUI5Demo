
package com.sap.scala.facades.openui5.fl.descriptorRelated.api

import com.sap.scala.facades.openui5.fl.descriptorRelated.api.DescriptorInlineChange


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.fl.descriptorRelated.api.DescriptorVariant")
@js.native
class DescriptorVariant()  {
//  def addDescriptorInlineChange(oDescriptorInlineChange: DescriptorInlineChange): /*TODO Type: 'Promise' not found.*/ = js.native
  def getJson(): Object = js.native
//  def setPackage(sPackage: String): /*TODO Type: 'Promise' not found.*/ = js.native
//  def setTransportRequest(sTransportRequest: String): /*TODO Type: 'Promise' not found.*/ = js.native
//  def submit(): /*TODO Type: 'Promise' not found.*/ = js.native
}
     