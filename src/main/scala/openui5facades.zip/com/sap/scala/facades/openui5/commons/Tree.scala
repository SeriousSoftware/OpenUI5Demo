
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.model.Context
import com.sap.scala.facades.openui5.core.CSSSize
import com.sap.scala.facades.openui5.commons.{TreeNode,TreeSelectionMode}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Tree")
@js.native
class Tree() extends Control {
  def addNode(oNode: TreeNode): this.type = js.native
  def attachSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSelectionChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindNodes(oBindingInfo: Object): this.type = js.native
  def collapseAll(): Unit = js.native
  def destroyNodes(): this.type = js.native
  def detachSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSelectionChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def expandAll(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireSelect(mParameters: Object): Boolean = js.native
  def fireSelectionChange(mParameters: Object): this.type = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getMinWidth(): CSSSize = js.native
  def getNodeByContext(oContext: Context): Unit = js.native
  def getNodes(): js.Array[TreeNode] = js.native
  def getSelectionMode(): TreeSelectionMode = js.native
  def getShowHeader(): Boolean = js.native
  def getShowHeaderIcons(): Boolean = js.native
  def getShowHorizontalScrollbar(): Boolean = js.native
  def getTitle(): String = js.native
  def getWidth(): CSSSize = js.native
  def indexOfNode(oNode: TreeNode): Int = js.native
  def insertNode(oNode: TreeNode, iIndex: Int): this.type = js.native
  def removeAllNodes(): js.Array[TreeNode] = js.native
  def removeNode(vNode: Int | String | TreeNode): TreeNode = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setMinWidth(sMinWidth: CSSSize): this.type = js.native
  def setSelectionMode(sSelectionMode: TreeSelectionMode): this.type = js.native
  def setShowHeader(bShowHeader: Boolean): this.type = js.native
  def setShowHeaderIcons(bShowHeaderIcons: Boolean): this.type = js.native
  def setShowHorizontalScrollbar(bShowHorizontalScrollbar: Boolean): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
  def unbindNodes(): this.type = js.native
}
     