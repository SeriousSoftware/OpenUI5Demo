
package com.sap.scala.facades.openui5.base




import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.base.Interface")
@js.native
class Interface()  {

}
     