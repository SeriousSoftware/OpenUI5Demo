
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.EventBus")
@js.native
class EventBus() extends Object {
  def destroy(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def publish(sChannelId: String, sEventId: String, oData: Object): Unit = js.native
  def subscribe(sChannelId: String, sEventId: String, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def subscribeOnce(sChannelId: String, sEventId: String, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def unsubscribe(sChannelId: String, sEventId: String, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
}
     