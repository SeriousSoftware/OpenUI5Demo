
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,ImeMode,Design,ValueState,Control,TextAlign,ID,AccessibleRole,TextDirection}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.TextField")
@js.native
class TextField() extends Control {
//  def _checkChange(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
  def addAriaDescribedBy(vAriaDescribedBy: ID | Control): this.type = js.native
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def attachChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachLiveChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindValue(oBindingInfo: Object): this.type = js.native
  def detachChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachLiveChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireChange(mParameters: Object): this.type = js.native
  def fireLiveChange(mParameters: Object): this.type = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getAccessibleRole(): AccessibleRole = js.native
  def getAriaDescribedBy(): js.Array[ID] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getDesign(): Design = js.native
  def getEditable(): Boolean = js.native
  def getEnabled(): Boolean = js.native
  def getFocusInfo(): Object = js.native
  def getHelpId(): String = js.native
  def getImeMode(): ImeMode = js.native
  def getInputDomRef(): Object = js.native
  def getLiveValue(): String = js.native
  def getMaxLength(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getName(): String = js.native
  def getPlaceholder(): String = js.native
  def getRequired(): Boolean = js.native
  def getTextAlign(): TextAlign = js.native
  def getTextDirection(): TextDirection = js.native
  def getValue(): String = js.native
  def getValueState(): ValueState = js.native
  def getWidth(): CSSSize = js.native
//  def onfocusin(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onkeyup(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsapenter(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsapfocusleave(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onselectstart(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
  def removeAllAriaDescribedBy(): js.Array[ID] = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAriaDescribedBy(vAriaDescribedBy: Int | ID | Control): ID = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def setAccessibleRole(sAccessibleRole: AccessibleRole): this.type = js.native
  def setDesign(sDesign: Design): this.type = js.native
  def setEditable(bEditable: Boolean): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setHelpId(sHelpId: String): this.type = js.native
  def setImeMode(sImeMode: ImeMode): this.type = js.native
  def setMaxLength(iMaxLength: Int): this.type = js.native
  def setName(sName: String): this.type = js.native
  def setPlaceholder(sPlaceholder: String): this.type = js.native
  def setRequired(bRequired: Boolean): this.type = js.native
  def setTextAlign(sTextAlign: TextAlign): this.type = js.native
  def setTextDirection(sTextDirection: TextDirection): this.type = js.native
  def setValue(sValue: String): this.type = js.native
  def setValueState(sValueState: ValueState): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
  def unbindValue(): this.type = js.native
}
     