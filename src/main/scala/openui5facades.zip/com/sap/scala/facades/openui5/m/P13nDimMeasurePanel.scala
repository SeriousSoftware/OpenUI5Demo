
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.P13nDimMeasureItem
import com.sap.scala.facades.openui5.core.{Control,Item}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nDimMeasurePanel")
@js.native
class P13nDimMeasurePanel() extends P13nPanel {
  def addAvailableChartType(oAvailableChartType: Item): this.type = js.native
  def addDimMeasureItem(oDimMeasureItem: P13nDimMeasureItem): this.type = js.native
  def bindDimMeasureItems(oBindingInfo: Object): this.type = js.native
  def destroyAvailableChartTypes(): this.type = js.native
  def destroyDimMeasureItems(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAvailableChartTypes(): js.Array[Item] = js.native
  def getChartTypeKey(): String = js.native
  def getDimMeasureItems(): js.Array[P13nDimMeasureItem] = js.native
  def getMetadata(): Metadata = js.native
  def indexOfAvailableChartType(oAvailableChartType: Item): Int = js.native
  def indexOfDimMeasureItem(oDimMeasureItem: P13nDimMeasureItem): Int = js.native
  def insertAvailableChartType(oAvailableChartType: Item, iIndex: Int): this.type = js.native
  def insertDimMeasureItem(oDimMeasureItem: P13nDimMeasureItem, iIndex: Int): this.type = js.native
  def removeAllAvailableChartTypes(): js.Array[Item] = js.native
  def removeAllDimMeasureItems(): js.Array[P13nDimMeasureItem] = js.native
  def removeAvailableChartType(vAvailableChartType: Int | String | Item): Item = js.native
  def removeDimMeasureItem(vDimMeasureItem: Int | String | P13nDimMeasureItem): P13nDimMeasureItem = js.native
  def setChartTypeKey(sChartTypeKey: String): this.type = js.native
  def unbindDimMeasureItems(): this.type = js.native
}
     