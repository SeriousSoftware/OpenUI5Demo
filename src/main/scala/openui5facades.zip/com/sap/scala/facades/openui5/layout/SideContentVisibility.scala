package com.sap.scala.facades.openui5.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait SideContentVisibility extends js.Object

object SideContentVisibility{
  @JSGlobal("sap.ui.layout.SideContentVisibility.AlwaysShow")
  @js.native
  object AlwaysShow extends SideContentVisibility

  @JSGlobal("sap.ui.layout.SideContentVisibility.NeverShow")
  @js.native
  object NeverShow extends SideContentVisibility

  @JSGlobal("sap.ui.layout.SideContentVisibility.ShowAboveL")
  @js.native
  object ShowAboveL extends SideContentVisibility

  @JSGlobal("sap.ui.layout.SideContentVisibility.ShowAboveM")
  @js.native
  object ShowAboveM extends SideContentVisibility

  @JSGlobal("sap.ui.layout.SideContentVisibility.ShowAboveS")
  @js.native
  object ShowAboveS extends SideContentVisibility
}

/* copy to Enum.scala
sealed trait SideContentVisibility{
  private[ui] def toFacade: sap.ui.layout.SideContentVisibility
}

object SideContentVisibility {
  def fromFacade(s: ui.layout.SideContentVisibility): SideContentVisibility = s match {
    case ui.layout.SideContentVisibility.AlwaysShow => SideContentVisibility.AlwaysShow
    case ui.layout.SideContentVisibility.NeverShow => SideContentVisibility.NeverShow
    case ui.layout.SideContentVisibility.ShowAboveL => SideContentVisibility.ShowAboveL
    case ui.layout.SideContentVisibility.ShowAboveM => SideContentVisibility.ShowAboveM
    case ui.layout.SideContentVisibility.ShowAboveS => SideContentVisibility.ShowAboveS
   case _ =>
     throw new UnsupportedOperationException(s"Unknown SideContentVisibility: $s")
  }
  
  object AlwaysShow extends SideContentVisibility {
    override private[ui] def toFacade: ui.layout.SideContentVisibility = ui.layout.SideContentVisibility.AlwaysShow
  }

  object NeverShow extends SideContentVisibility {
    override private[ui] def toFacade: ui.layout.SideContentVisibility = ui.layout.SideContentVisibility.NeverShow
  }

  object ShowAboveL extends SideContentVisibility {
    override private[ui] def toFacade: ui.layout.SideContentVisibility = ui.layout.SideContentVisibility.ShowAboveL
  }

  object ShowAboveM extends SideContentVisibility {
    override private[ui] def toFacade: ui.layout.SideContentVisibility = ui.layout.SideContentVisibility.ShowAboveM
  }

  object ShowAboveS extends SideContentVisibility {
    override private[ui] def toFacade: ui.layout.SideContentVisibility = ui.layout.SideContentVisibility.ShowAboveS
  }

}
*/
