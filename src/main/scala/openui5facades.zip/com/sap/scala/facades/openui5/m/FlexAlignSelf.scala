package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait FlexAlignSelf extends js.Object

object FlexAlignSelf{
  @JSGlobal("sap.m.FlexAlignSelf.Auto")
  @js.native
  object Auto extends FlexAlignSelf

  @JSGlobal("sap.m.FlexAlignSelf.Baseline")
  @js.native
  object Baseline extends FlexAlignSelf

  @JSGlobal("sap.m.FlexAlignSelf.Center")
  @js.native
  object Center extends FlexAlignSelf

  @JSGlobal("sap.m.FlexAlignSelf.End")
  @js.native
  object End extends FlexAlignSelf

  @JSGlobal("sap.m.FlexAlignSelf.Inherit")
  @js.native
  object Inherit extends FlexAlignSelf

  @JSGlobal("sap.m.FlexAlignSelf.Start")
  @js.native
  object Start extends FlexAlignSelf

  @JSGlobal("sap.m.FlexAlignSelf.Stretch")
  @js.native
  object Stretch extends FlexAlignSelf
}

/* copy to Enum.scala
sealed trait FlexAlignSelf{
  private[ui] def toFacade: sap.m.FlexAlignSelf
}

object FlexAlignSelf {
  def fromFacade(s: m.FlexAlignSelf): FlexAlignSelf = s match {
    case m.FlexAlignSelf.Auto => FlexAlignSelf.Auto
    case m.FlexAlignSelf.Baseline => FlexAlignSelf.Baseline
    case m.FlexAlignSelf.Center => FlexAlignSelf.Center
    case m.FlexAlignSelf.End => FlexAlignSelf.End
    case m.FlexAlignSelf.Inherit => FlexAlignSelf.Inherit
    case m.FlexAlignSelf.Start => FlexAlignSelf.Start
    case m.FlexAlignSelf.Stretch => FlexAlignSelf.Stretch
   case _ =>
     throw new UnsupportedOperationException(s"Unknown FlexAlignSelf: $s")
  }
  
  object Auto extends FlexAlignSelf {
    override private[ui] def toFacade: m.FlexAlignSelf = m.FlexAlignSelf.Auto
  }

  object Baseline extends FlexAlignSelf {
    override private[ui] def toFacade: m.FlexAlignSelf = m.FlexAlignSelf.Baseline
  }

  object Center extends FlexAlignSelf {
    override private[ui] def toFacade: m.FlexAlignSelf = m.FlexAlignSelf.Center
  }

  object End extends FlexAlignSelf {
    override private[ui] def toFacade: m.FlexAlignSelf = m.FlexAlignSelf.End
  }

  object Inherit extends FlexAlignSelf {
    override private[ui] def toFacade: m.FlexAlignSelf = m.FlexAlignSelf.Inherit
  }

  object Start extends FlexAlignSelf {
    override private[ui] def toFacade: m.FlexAlignSelf = m.FlexAlignSelf.Start
  }

  object Stretch extends FlexAlignSelf {
    override private[ui] def toFacade: m.FlexAlignSelf = m.FlexAlignSelf.Stretch
  }

}
*/
