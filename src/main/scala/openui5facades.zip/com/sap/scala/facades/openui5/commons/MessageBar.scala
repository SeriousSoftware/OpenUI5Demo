
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.commons.Message


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.MessageBar")
@js.native
class MessageBar() extends Control {
  def addMessages(aAMessages: js.Array[Message]): Unit = js.native
  def deleteAllMessages(): this.type = js.native
//  def deleteMessages(aIds: /*TODO Type: 'string[]' not found.*/): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAnchorID(): String = js.native
  def getAnchorSnapPoint(): String = js.native
  def getMaxListed(): Int = js.native
  def getMaxToasted(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getVisible(): Boolean = js.native
  def setAnchorID(sAnchorID: String): this.type = js.native
  def setAnchorSnapPoint(sAnchorSnapPoint: String): this.type = js.native
  def setMaxListed(iMaxListed: Int): this.type = js.native
  def setMaxToasted(iMaxToasted: Int): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     