
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{MessageItem,Button}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.MessageView")
@js.native
class MessageView()  {
  def addItem(oItem: MessageItem): this.type = js.native
  def attachAfterOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachItemSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachListSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachLongtextLoaded(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachUrlValidated(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyHeaderButton(): this.type = js.native
  def destroyItems(): this.type = js.native
  def detachAfterOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachItemSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachListSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachLongtextLoaded(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachUrlValidated(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterOpen(mParameters: Object): this.type = js.native
  def fireItemSelect(mParameters: Object): this.type = js.native
  def fireListSelect(mParameters: Object): this.type = js.native
  def fireLongtextLoaded(mParameters: Object): this.type = js.native
  def fireUrlValidated(mParameters: Object): this.type = js.native
//  def getAsyncDescriptionHandler(): /*TODO Type: 'any' not found.*/ = js.native
//  def getAsyncURLHandler(): /*TODO Type: 'any' not found.*/ = js.native
  def getGroupItems(): Boolean = js.native
  def getHeaderButton(): Button = js.native
  def getItems(): js.Array[MessageItem] = js.native
  def getMetadata(): Metadata = js.native
  def indexOfItem(oItem: MessageItem): Int = js.native
  def insertItem(oItem: MessageItem, iIndex: Int): this.type = js.native
  def removeAllItems(): js.Array[MessageItem] = js.native
  def removeItem(vItem: Int | String | MessageItem): MessageItem = js.native
//  def setAsyncDescriptionHandler(oAsyncDescriptionHandler: /*TODO Type: 'any' not found.*/): this.type = js.native
//  def setAsyncURLHandler(oAsyncURLHandler: /*TODO Type: 'any' not found.*/): this.type = js.native
  def setDefaultHandlers(mDefaultHandlers: Object): Unit = js.native
  def setGroupItems(bGroupItems: Boolean): this.type = js.native
  def setHeaderButton(oHeaderButton: Button): this.type = js.native
}
     