package com.sap.scala.facades.openui5.f

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait AvatarShape extends js.Object

object AvatarShape{
  @JSGlobal("sap.f.AvatarShape.Circle")
  @js.native
  object Circle extends AvatarShape

  @JSGlobal("sap.f.AvatarShape.Square")
  @js.native
  object Square extends AvatarShape
}

/* copy to Enum.scala
sealed trait AvatarShape{
  private[ui] def toFacade: sap.f.AvatarShape
}

object AvatarShape {
  def fromFacade(s: f.AvatarShape): AvatarShape = s match {
    case f.AvatarShape.Circle => AvatarShape.Circle
    case f.AvatarShape.Square => AvatarShape.Square
   case _ =>
     throw new UnsupportedOperationException(s"Unknown AvatarShape: $s")
  }
  
  object Circle extends AvatarShape {
    override private[ui] def toFacade: f.AvatarShape = f.AvatarShape.Circle
  }

  object Square extends AvatarShape {
    override private[ui] def toFacade: f.AvatarShape = f.AvatarShape.Square
  }

}
*/
