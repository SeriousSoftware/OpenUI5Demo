package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ToolbarDesign extends js.Object

object ToolbarDesign{
  @JSGlobal("sap.ui.commons.ToolbarDesign.Flat")
  @js.native
  object Flat extends ToolbarDesign

  @JSGlobal("sap.ui.commons.ToolbarDesign.Standard")
  @js.native
  object Standard extends ToolbarDesign

  @JSGlobal("sap.ui.commons.ToolbarDesign.Transparent")
  @js.native
  object Transparent extends ToolbarDesign
}

/* copy to Enum.scala
sealed trait ToolbarDesign{
  private[ui] def toFacade: sap.ui.commons.ToolbarDesign
}

object ToolbarDesign {
  def fromFacade(s: ui.commons.ToolbarDesign): ToolbarDesign = s match {
    case ui.commons.ToolbarDesign.Flat => ToolbarDesign.Flat
    case ui.commons.ToolbarDesign.Standard => ToolbarDesign.Standard
    case ui.commons.ToolbarDesign.Transparent => ToolbarDesign.Transparent
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ToolbarDesign: $s")
  }
  
  object Flat extends ToolbarDesign {
    override private[ui] def toFacade: ui.commons.ToolbarDesign = ui.commons.ToolbarDesign.Flat
  }

  object Standard extends ToolbarDesign {
    override private[ui] def toFacade: ui.commons.ToolbarDesign = ui.commons.ToolbarDesign.Standard
  }

  object Transparent extends ToolbarDesign {
    override private[ui] def toFacade: ui.commons.ToolbarDesign = ui.commons.ToolbarDesign.Transparent
  }

}
*/
