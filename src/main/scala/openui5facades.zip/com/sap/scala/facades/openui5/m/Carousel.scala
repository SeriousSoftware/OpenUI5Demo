
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{PlacementType,CarouselArrowsPlacement}
import com.sap.scala.facades.openui5.core.{CSSSize,Control,ID}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.Carousel")
@js.native
class Carousel() extends Control {
  def addPage(oPage: Control): this.type = js.native
  def attachLoadPage(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachPageChanged(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachUnloadPage(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyPages(): this.type = js.native
  def detachLoadPage(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPageChanged(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachUnloadPage(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireLoadPage(mParameters: Object): this.type = js.native
  def firePageChanged(mParameters: Object): this.type = js.native
  def fireUnloadPage(mParameters: Object): this.type = js.native
  def getActivePage(): ID = js.native
  def getArrowsPlacement(): CarouselArrowsPlacement = js.native
  def getBusyIndicatorSize(): CSSSize = js.native
  def getHeight(): CSSSize = js.native
  def getLoop(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getPageIndicatorPlacement(): PlacementType = js.native
  def getPages(): js.Array[Control] = js.native
  def getShowBusyIndicator(): Boolean = js.native
  def getShowPageIndicator(): Boolean = js.native
  def getWidth(): CSSSize = js.native
  def indexOfPage(oPage: Control): Int = js.native
  def insertPage(oPage: Control, iIndex: Int): this.type = js.native
  def next(): this.type = js.native
  def previous(): this.type = js.native
  def removeAllPages(): js.Array[Control] = js.native
  def removePage(vPage: Int | String | Control): Control = js.native
  def setActivePage(oActivePage: ID | Control): this.type = js.native
  def setArrowsPlacement(sArrowsPlacement: CarouselArrowsPlacement): this.type = js.native
  def setBusyIndicatorSize(sBusyIndicatorSize: CSSSize): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setLoop(bLoop: Boolean): this.type = js.native
  def setPageIndicatorPlacement(sPageIndicatorPlacement: PlacementType): this.type = js.native
  def setShowBusyIndicator(bShowBusyIndicator: Boolean): this.type = js.native
  def setShowPageIndicator(bShowPageIndicator: Boolean): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     