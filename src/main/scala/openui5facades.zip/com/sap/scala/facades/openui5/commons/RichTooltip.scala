
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.URI
import com.sap.scala.facades.openui5.commons.FormattedTextView


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.RichTooltip")
@js.native
class RichTooltip() extends TooltipBase {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getImageAltText(): String = js.native
  def getImageSrc(): URI = js.native
  def getMetadata(): Metadata = js.native
  def getTitle(): String = js.native
  def getValueStateText(): String = js.native
  def onAfterRendering(): Unit = js.native
  def setImageAltText(sImageAltText: String): this.type = js.native
  def setImageSrc(sImageSrc: URI): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setValueStateText(sText: String): this.type = js.native
}
     