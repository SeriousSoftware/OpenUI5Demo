
package com.sap.scala.facades.openui5.core.util

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.util.ExportCell


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.util.ExportColumn")
@js.native
class ExportColumn() extends ManagedObject {
  def destroyTemplate(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getName(): String = js.native
  def getTemplate(): ExportCell = js.native
  def setName(sName: String): this.type = js.native
  def setTemplate(oTemplate: ExportCell): this.type = js.native
}
     