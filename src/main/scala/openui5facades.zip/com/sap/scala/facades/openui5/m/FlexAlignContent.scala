package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait FlexAlignContent extends js.Object

object FlexAlignContent{
  @JSGlobal("sap.m.FlexAlignContent.Center")
  @js.native
  object Center extends FlexAlignContent

  @JSGlobal("sap.m.FlexAlignContent.End")
  @js.native
  object End extends FlexAlignContent

  @JSGlobal("sap.m.FlexAlignContent.Inherit")
  @js.native
  object Inherit extends FlexAlignContent

  @JSGlobal("sap.m.FlexAlignContent.SpaceAround")
  @js.native
  object SpaceAround extends FlexAlignContent

  @JSGlobal("sap.m.FlexAlignContent.SpaceBetween")
  @js.native
  object SpaceBetween extends FlexAlignContent

  @JSGlobal("sap.m.FlexAlignContent.Start")
  @js.native
  object Start extends FlexAlignContent

  @JSGlobal("sap.m.FlexAlignContent.Stretch")
  @js.native
  object Stretch extends FlexAlignContent
}

/* copy to Enum.scala
sealed trait FlexAlignContent{
  private[ui] def toFacade: sap.m.FlexAlignContent
}

object FlexAlignContent {
  def fromFacade(s: m.FlexAlignContent): FlexAlignContent = s match {
    case m.FlexAlignContent.Center => FlexAlignContent.Center
    case m.FlexAlignContent.End => FlexAlignContent.End
    case m.FlexAlignContent.Inherit => FlexAlignContent.Inherit
    case m.FlexAlignContent.SpaceAround => FlexAlignContent.SpaceAround
    case m.FlexAlignContent.SpaceBetween => FlexAlignContent.SpaceBetween
    case m.FlexAlignContent.Start => FlexAlignContent.Start
    case m.FlexAlignContent.Stretch => FlexAlignContent.Stretch
   case _ =>
     throw new UnsupportedOperationException(s"Unknown FlexAlignContent: $s")
  }
  
  object Center extends FlexAlignContent {
    override private[ui] def toFacade: m.FlexAlignContent = m.FlexAlignContent.Center
  }

  object End extends FlexAlignContent {
    override private[ui] def toFacade: m.FlexAlignContent = m.FlexAlignContent.End
  }

  object Inherit extends FlexAlignContent {
    override private[ui] def toFacade: m.FlexAlignContent = m.FlexAlignContent.Inherit
  }

  object SpaceAround extends FlexAlignContent {
    override private[ui] def toFacade: m.FlexAlignContent = m.FlexAlignContent.SpaceAround
  }

  object SpaceBetween extends FlexAlignContent {
    override private[ui] def toFacade: m.FlexAlignContent = m.FlexAlignContent.SpaceBetween
  }

  object Start extends FlexAlignContent {
    override private[ui] def toFacade: m.FlexAlignContent = m.FlexAlignContent.Start
  }

  object Stretch extends FlexAlignContent {
    override private[ui] def toFacade: m.FlexAlignContent = m.FlexAlignContent.Stretch
  }

}
*/
