package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ToolbarSeparatorDesign extends js.Object

object ToolbarSeparatorDesign{
  @JSGlobal("sap.ui.commons.ToolbarSeparatorDesign.FullHeight")
  @js.native
  object FullHeight extends ToolbarSeparatorDesign

  @JSGlobal("sap.ui.commons.ToolbarSeparatorDesign.Standard")
  @js.native
  object Standard extends ToolbarSeparatorDesign
}

/* copy to Enum.scala
sealed trait ToolbarSeparatorDesign{
  private[ui] def toFacade: sap.ui.commons.ToolbarSeparatorDesign
}

object ToolbarSeparatorDesign {
  def fromFacade(s: ui.commons.ToolbarSeparatorDesign): ToolbarSeparatorDesign = s match {
    case ui.commons.ToolbarSeparatorDesign.FullHeight => ToolbarSeparatorDesign.FullHeight
    case ui.commons.ToolbarSeparatorDesign.Standard => ToolbarSeparatorDesign.Standard
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ToolbarSeparatorDesign: $s")
  }
  
  object FullHeight extends ToolbarSeparatorDesign {
    override private[ui] def toFacade: ui.commons.ToolbarSeparatorDesign = ui.commons.ToolbarSeparatorDesign.FullHeight
  }

  object Standard extends ToolbarSeparatorDesign {
    override private[ui] def toFacade: ui.commons.ToolbarSeparatorDesign = ui.commons.ToolbarSeparatorDesign.Standard
  }

}
*/
