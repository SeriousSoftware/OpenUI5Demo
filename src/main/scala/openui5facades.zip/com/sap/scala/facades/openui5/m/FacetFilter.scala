
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{FacetFilterList,Popover,Toolbar,FacetFilterType,Button,Dialog}
import com.sap.scala.facades.openui5.core.Icon


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.FacetFilter")
@js.native
class FacetFilter() extends Control {
  def addList(oList: FacetFilterList): this.type = js.native
  def attachConfirm(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachReset(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyLists(): this.type = js.native
  def detachConfirm(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachReset(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireConfirm(mParameters: Object): this.type = js.native
  def fireReset(mParameters: Object): this.type = js.native
  def getLists(): js.Array[FacetFilterList] = js.native
  def getLiveSearch(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getShowPersonalization(): Boolean = js.native
  def getShowPopoverOKButton(): Boolean = js.native
  def getShowReset(): Boolean = js.native
  def getShowSummaryBar(): Boolean = js.native
  def getType(): FacetFilterType = js.native
  def indexOfList(oList: FacetFilterList): Int = js.native
  def insertList(oList: FacetFilterList, iIndex: Int): this.type = js.native
  def openFilterDialog(): this.type = js.native
  def removeAllLists(): js.Array[FacetFilterList] = js.native
  def removeList(vList: Int | String | FacetFilterList): FacetFilterList = js.native
  def setLiveSearch(bLiveSearch: Boolean): this.type = js.native
  def setShowPersonalization(bShowPersonalization: Boolean): this.type = js.native
  def setShowPopoverOKButton(bShowPopoverOKButton: Boolean): this.type = js.native
  def setShowReset(bShowReset: Boolean): this.type = js.native
  def setShowSummaryBar(bShowSummaryBar: Boolean): this.type = js.native
  def setType(sType: FacetFilterType): this.type = js.native
}
     