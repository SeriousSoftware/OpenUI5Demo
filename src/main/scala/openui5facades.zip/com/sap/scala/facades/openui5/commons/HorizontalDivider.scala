
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize
import com.sap.scala.facades.openui5.commons.{HorizontalDividerHeight,HorizontalDividerType}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.HorizontalDivider")
@js.native
class HorizontalDivider() extends Control {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getHeight(): HorizontalDividerHeight = js.native
  def getMetadata(): Metadata = js.native
  def getType(): HorizontalDividerType = js.native
  def getWidth(): CSSSize = js.native
  def setHeight(sHeight: HorizontalDividerHeight): this.type = js.native
  def setType(sType: HorizontalDividerType): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     