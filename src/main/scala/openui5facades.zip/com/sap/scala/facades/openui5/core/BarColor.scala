package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait BarColor extends js.Object

object BarColor{
  @JSGlobal("sap.ui.core.BarColor.CRITICAL")
  @js.native
  object CRITICAL extends BarColor

  @JSGlobal("sap.ui.core.BarColor.NEGATIVE")
  @js.native
  object NEGATIVE extends BarColor

  @JSGlobal("sap.ui.core.BarColor.NEUTRAL")
  @js.native
  object NEUTRAL extends BarColor

  @JSGlobal("sap.ui.core.BarColor.POSITIVE")
  @js.native
  object POSITIVE extends BarColor
}

/* copy to Enum.scala
sealed trait BarColor{
  private[ui] def toFacade: sap.ui.core.BarColor
}

object BarColor {
  def fromFacade(s: ui.core.BarColor): BarColor = s match {
    case ui.core.BarColor.CRITICAL => BarColor.CRITICAL
    case ui.core.BarColor.NEGATIVE => BarColor.NEGATIVE
    case ui.core.BarColor.NEUTRAL => BarColor.NEUTRAL
    case ui.core.BarColor.POSITIVE => BarColor.POSITIVE
   case _ =>
     throw new UnsupportedOperationException(s"Unknown BarColor: $s")
  }
  
  object CRITICAL extends BarColor {
    override private[ui] def toFacade: ui.core.BarColor = ui.core.BarColor.CRITICAL
  }

  object NEGATIVE extends BarColor {
    override private[ui] def toFacade: ui.core.BarColor = ui.core.BarColor.NEGATIVE
  }

  object NEUTRAL extends BarColor {
    override private[ui] def toFacade: ui.core.BarColor = ui.core.BarColor.NEUTRAL
  }

  object POSITIVE extends BarColor {
    override private[ui] def toFacade: ui.core.BarColor = ui.core.BarColor.POSITIVE
  }

}
*/
