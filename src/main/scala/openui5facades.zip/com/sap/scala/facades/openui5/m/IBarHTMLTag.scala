package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait IBarHTMLTag extends js.Object

object IBarHTMLTag{
  @JSGlobal("sap.m.IBarHTMLTag.Div")
  @js.native
  object Div extends IBarHTMLTag

  @JSGlobal("sap.m.IBarHTMLTag.Footer")
  @js.native
  object Footer extends IBarHTMLTag

  @JSGlobal("sap.m.IBarHTMLTag.Header")
  @js.native
  object Header extends IBarHTMLTag
}

/* copy to Enum.scala
sealed trait IBarHTMLTag{
  private[ui] def toFacade: sap.m.IBarHTMLTag
}

object IBarHTMLTag {
  def fromFacade(s: m.IBarHTMLTag): IBarHTMLTag = s match {
    case m.IBarHTMLTag.Div => IBarHTMLTag.Div
    case m.IBarHTMLTag.Footer => IBarHTMLTag.Footer
    case m.IBarHTMLTag.Header => IBarHTMLTag.Header
   case _ =>
     throw new UnsupportedOperationException(s"Unknown IBarHTMLTag: $s")
  }
  
  object Div extends IBarHTMLTag {
    override private[ui] def toFacade: m.IBarHTMLTag = m.IBarHTMLTag.Div
  }

  object Footer extends IBarHTMLTag {
    override private[ui] def toFacade: m.IBarHTMLTag = m.IBarHTMLTag.Footer
  }

  object Header extends IBarHTMLTag {
    override private[ui] def toFacade: m.IBarHTMLTag = m.IBarHTMLTag.Header
  }

}
*/
