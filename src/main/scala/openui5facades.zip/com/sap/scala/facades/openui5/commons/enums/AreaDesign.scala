package com.sap.scala.facades.openui5.commons.enums

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait AreaDesign extends js.Object

object AreaDesign{
  @JSGlobal("sap.ui.commons.enums.AreaDesign.Fill")
  @js.native
  object Fill extends AreaDesign

  @JSGlobal("sap.ui.commons.enums.AreaDesign.Plain")
  @js.native
  object Plain extends AreaDesign

  @JSGlobal("sap.ui.commons.enums.AreaDesign.Transparent")
  @js.native
  object Transparent extends AreaDesign
}

/* copy to Enum.scala
sealed trait AreaDesign{
  private[ui] def toFacade: sap.ui.commons.enums.AreaDesign
}

object AreaDesign {
  def fromFacade(s: ui.commons.enums.AreaDesign): AreaDesign = s match {
    case ui.commons.enums.AreaDesign.Fill => AreaDesign.Fill
    case ui.commons.enums.AreaDesign.Plain => AreaDesign.Plain
    case ui.commons.enums.AreaDesign.Transparent => AreaDesign.Transparent
   case _ =>
     throw new UnsupportedOperationException(s"Unknown AreaDesign: $s")
  }
  
  object Fill extends AreaDesign {
    override private[ui] def toFacade: ui.commons.enums.AreaDesign = ui.commons.enums.AreaDesign.Fill
  }

  object Plain extends AreaDesign {
    override private[ui] def toFacade: ui.commons.enums.AreaDesign = ui.commons.enums.AreaDesign.Plain
  }

  object Transparent extends AreaDesign {
    override private[ui] def toFacade: ui.commons.enums.AreaDesign = ui.commons.enums.AreaDesign.Transparent
  }

}
*/
