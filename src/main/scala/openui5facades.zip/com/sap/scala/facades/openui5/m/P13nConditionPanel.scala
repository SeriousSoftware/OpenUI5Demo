
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.P13nConditionOperation
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nConditionPanel")
@js.native
class P13nConditionPanel() extends Control {
  def addCondition(oCondition: Object): Unit = js.native
  def addKeyField(oKeyField: Object): Unit = js.native
  def addOperation(oOperation: P13nConditionOperation, sType: String): Unit = js.native
  def attachDataChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachDataChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireDataChange(mParameters: Object): this.type = js.native
  def getAlwaysShowAddIcon(): Boolean = js.native
  def getAutoAddNewRow(): Boolean = js.native
  def getAutoReduceKeyFieldItems(): Boolean = js.native
//  def getConditions(): /*TODO Type: 'object[]' not found.*/ = js.native
  def getContainerQuery(): Boolean = js.native
  def getDisableFirstRemoveIcon(): Boolean = js.native
  def getDisplayFormat(): String = js.native
  def getExclude(): Boolean = js.native
//  def getKeyFields(): /*TODO Type: 'object[]' not found.*/ = js.native
  def getLayoutMode(): String = js.native
  def getMaxConditions(): String = js.native
  def getMetadata(): Metadata = js.native
  def getOperations(sType: String): js.Array[P13nConditionOperation] = js.native
  def getShowLabel(): Boolean = js.native
  def getUsePrevConditionSetting(): Boolean = js.native
  def getValidationExecutor(): Object = js.native
  def insertCondition(oCondition: Object, index: Int): Unit = js.native
  def removeAllConditions(): Unit = js.native
  def removeAllKeyFields(): Unit = js.native
  def removeAllOperations(sType: String): Unit = js.native
  def removeCondition(vCondition: Object): Unit = js.native
  def removeInvalidConditions(): Unit = js.native
  def removeValidationErrors(): Unit = js.native
  def setAutoAddNewRow(bAutoAddNewRow: Boolean): this.type = js.native
  def setAutoReduceKeyFieldItems(bAutoReduceKeyFieldItems: Boolean): this.type = js.native
//  def setConditions(aConditions: /*TODO Type: 'object[]' not found.*/): Unit = js.native
  def setDisableFirstRemoveIcon(bDisableFirstRemoveIcon: Boolean): this.type = js.native
  def setDisplayFormat(sDisplayFormat: String): this.type = js.native
  def setExclude(bExclude: Boolean): this.type = js.native
//  def setKeyFields(aKeyFields: /*TODO Type: 'array' not found.*/): Unit = js.native
  def setMaxConditions(sMaxConditions: String): this.type = js.native
  def setOperations(aOperations: js.Array[P13nConditionOperation], sType: String): Unit = js.native
  def setShowLabel(bShowLabel: Boolean): this.type = js.native
  def setUsePrevConditionSetting(bUsePrevConditionSetting: Boolean): this.type = js.native
  def setValidationExecutor(oValidationExecutor: Object): this.type = js.native
}
     