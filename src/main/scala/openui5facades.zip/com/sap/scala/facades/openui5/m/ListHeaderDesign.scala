package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ListHeaderDesign extends js.Object

object ListHeaderDesign{
  @JSGlobal("sap.m.ListHeaderDesign.Plain")
  @js.native
  object Plain extends ListHeaderDesign

  @JSGlobal("sap.m.ListHeaderDesign.Standard")
  @js.native
  object Standard extends ListHeaderDesign
}

/* copy to Enum.scala
sealed trait ListHeaderDesign{
  private[ui] def toFacade: sap.m.ListHeaderDesign
}

object ListHeaderDesign {
  def fromFacade(s: m.ListHeaderDesign): ListHeaderDesign = s match {
    case m.ListHeaderDesign.Plain => ListHeaderDesign.Plain
    case m.ListHeaderDesign.Standard => ListHeaderDesign.Standard
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ListHeaderDesign: $s")
  }
  
  object Plain extends ListHeaderDesign {
    override private[ui] def toFacade: m.ListHeaderDesign = m.ListHeaderDesign.Plain
  }

  object Standard extends ListHeaderDesign {
    override private[ui] def toFacade: m.ListHeaderDesign = m.ListHeaderDesign.Standard
  }

}
*/
