
package com.sap.scala.facades.openui5.fl.descriptorRelated.api




import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.fl.descriptorRelated.api.DescriptorChange")
@js.native
class DescriptorChange()  {
  def getJson(): Object = js.native
//  def setPackage(sPackage: String): /*TODO Type: 'Promise' not found.*/ = js.native
//  def setTransportRequest(sTransportRequest: String): /*TODO Type: 'Promise' not found.*/ = js.native
//  def submit(): /*TODO Type: 'Promise' not found.*/ = js.native
}
     