
package com.sap.scala.facades.openui5.demokit

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.demokit.Tag")
@js.native
class Tag() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getText(): String = js.native
  def getWeight(): Int = js.native
  def setText(sText: String): this.type = js.native
  def setWeight(iWeight: Int): this.type = js.native
}
     