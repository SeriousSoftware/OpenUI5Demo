package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait P13nPanelType extends js.Object

object P13nPanelType{
  @JSGlobal("sap.m.P13nPanelType.columns")
  @js.native
  object columns extends P13nPanelType

  @JSGlobal("sap.m.P13nPanelType.dimeasure")
  @js.native
  object dimeasure extends P13nPanelType

  @JSGlobal("sap.m.P13nPanelType.filter")
  @js.native
  object filter extends P13nPanelType

  @JSGlobal("sap.m.P13nPanelType.group")
  @js.native
  object group extends P13nPanelType

  @JSGlobal("sap.m.P13nPanelType.sort")
  @js.native
  object sort extends P13nPanelType
}

/* copy to Enum.scala
sealed trait P13nPanelType{
  private[ui] def toFacade: sap.m.P13nPanelType
}

object P13nPanelType {
  def fromFacade(s: m.P13nPanelType): P13nPanelType = s match {
    case m.P13nPanelType.columns => P13nPanelType.columns
    case m.P13nPanelType.dimeasure => P13nPanelType.dimeasure
    case m.P13nPanelType.filter => P13nPanelType.filter
    case m.P13nPanelType.group => P13nPanelType.group
    case m.P13nPanelType.sort => P13nPanelType.sort
   case _ =>
     throw new UnsupportedOperationException(s"Unknown P13nPanelType: $s")
  }
  
  object columns extends P13nPanelType {
    override private[ui] def toFacade: m.P13nPanelType = m.P13nPanelType.columns
  }

  object dimeasure extends P13nPanelType {
    override private[ui] def toFacade: m.P13nPanelType = m.P13nPanelType.dimeasure
  }

  object filter extends P13nPanelType {
    override private[ui] def toFacade: m.P13nPanelType = m.P13nPanelType.filter
  }

  object group extends P13nPanelType {
    override private[ui] def toFacade: m.P13nPanelType = m.P13nPanelType.group
  }

  object sort extends P13nPanelType {
    override private[ui] def toFacade: m.P13nPanelType = m.P13nPanelType.sort
  }

}
*/
