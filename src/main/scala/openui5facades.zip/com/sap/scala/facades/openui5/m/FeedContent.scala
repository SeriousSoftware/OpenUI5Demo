
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{Size,ValueColor,Text}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.FeedContent")
@js.native
class FeedContent() extends Control {
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePress(mParameters: Object): this.type = js.native
  def getContentText(): String = js.native
  def getMetadata(): Metadata = js.native
  def getSize(): Size = js.native
  def getSubheader(): String = js.native
  def getTruncateValueTo(): Int = js.native
  def getValue(): String = js.native
  def getValueColor(): ValueColor = js.native
  def setContentText(sContentText: String): this.type = js.native
  def setSize(sSize: Size): this.type = js.native
  def setSubheader(sSubheader: String): this.type = js.native
  def setTruncateValueTo(iTruncateValueTo: Int): this.type = js.native
  def setValue(sValue: String): this.type = js.native
  def setValueColor(sValueColor: ValueColor): this.type = js.native
}
     