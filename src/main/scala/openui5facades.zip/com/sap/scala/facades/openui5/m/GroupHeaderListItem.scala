
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.TextDirection


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.GroupHeaderListItem")
@js.native
class GroupHeaderListItem() extends ListItemBase {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getCount(): String = js.native
  def getMetadata(): Metadata = js.native
  def getTitle(): String = js.native
  def getTitleTextDirection(): TextDirection = js.native
  def getUpperCase(): Boolean = js.native
  def setCount(sCount: String): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setTitleTextDirection(sTitleTextDirection: TextDirection): this.type = js.native
  def setUpperCase(bUpperCase: Boolean): this.type = js.native
}
     