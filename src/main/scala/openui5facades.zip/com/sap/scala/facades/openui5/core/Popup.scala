
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{Element,Control,OpenState}
import com.sap.scala.facades.openui5.core.Popup.Dock


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.Popup")
@js.native
class Popup() extends ManagedObject {
  def attachClosed(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachOpened(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def close(iDuration: Int): Unit = js.native
  def destroy(): Unit = js.native
  def detachClosed(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachOpened(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def exit(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireClosed(mParameters: Object): this.type = js.native
  def fireOpened(mParameters: Object): this.type = js.native
  def getAutoClose(): Boolean = js.native
//  def getContent(): Control | /*TODO Type: 'DOMRef' not found.*/ = js.native
  def getFollowOf(): Boolean | js.Function1[Event[EventProps], Unit] = js.native
//  def getLastZIndex(): /*TODO Type: 'Number' not found.*/ = js.native
//  def getLastZIndex(): /*TODO Type: 'Number' not found.*/ = js.native
  def getMetadata(): Metadata = js.native
  def getModal(): Unit = js.native
//  def getNextZIndex(): /*TODO Type: 'Number' not found.*/ = js.native
//  def getNextZIndex(): /*TODO Type: 'Number' not found.*/ = js.native
  def getOpenState(): OpenState = js.native
  def isOpen(): Boolean = js.native
//  def open(iDuration: Int, my: Dock, at: Dock, of: String | Element | /*TODO Type: 'DOMRef' not found.*/ | /*TODO Type: 'jQuery' not found.*/ | /*TODO Type: 'jQuery.Event' not found.*/, offset: String, collision: String, followOf: Boolean): Unit = js.native
  def setAnimations(fnOpen: js.Function1[Event[EventProps], Unit], fnClose: js.Function1[Event[EventProps], Unit]): this.type = js.native
  def setAutoClose(bAutoClose: Boolean): this.type = js.native
//  def setAutoCloseAreas(aAutoCloseAreas: /*TODO Type: 'DomRef[]' not found.*/ | js.Array[Element] | /*TODO Type: 'string[]' not found.*/): this.type = js.native
//  def setContent(oContent: Control | /*TODO Type: 'DOMRef' not found.*/): this.type = js.native
  def setDurations(iOpenDuration: Int, iCloseDuration: Int): this.type = js.native
//  def setFollowOf(followOf: Boolean | js.Function1[Event[EventProps], Unit] | /*TODO Type: 'null' not found.*/): Unit = js.native
  def setInitialFocusId(sId: String): Unit = js.native
//  def setInitialZIndex(iInitialZIndex: /*TODO Type: 'Number' not found.*/): Unit = js.native
  def setModal(bModal: Boolean, sModalCSSClass: String): this.type = js.native
//  def setPosition(my: Dock, at: Dock | /*TODO Type: 'Object' not found.*/, of: String | Element | /*TODO Type: 'DOMRef' not found.*/ | /*TODO Type: 'jQuery' not found.*/ | /*TODO Type: 'jQuery.Event' not found.*/, offset: String, collision: String): this.type = js.native
  def setShadow(bShowShadow: Boolean): this.type = js.native
}
     