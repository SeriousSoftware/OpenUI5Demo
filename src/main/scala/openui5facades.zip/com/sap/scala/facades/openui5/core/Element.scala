
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.{Metadata,ManagedObject}
import com.sap.scala.facades.openui5.model.Binding
import com.sap.scala.facades.openui5.core.{CustomData,Element,LayoutData,TooltipBase}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.Element")
@js.native
class Element() extends ManagedObject {
//  def $(sSuffix: String): /*TODO Type: 'jQuery' not found.*/ = js.native
//  def _attachMediaContainerWidthChange(fnFunction: /*TODO Type: 'undefined' not found.*/, oListener: /*TODO Type: 'undefined' not found.*/, sName: /*TODO Type: 'undefined' not found.*/): Unit = js.native
//  def _detachMediaContainerWidthChange(fnFunction: /*TODO Type: 'undefined' not found.*/, oListener: /*TODO Type: 'undefined' not found.*/, sName: /*TODO Type: 'undefined' not found.*/): Unit = js.native
//  def _getCurrentMediaContainerRange(sName: /*TODO Type: 'undefined' not found.*/): /*TODO Type: 'map' not found.*/ = js.native
//  def _getMediaContainerWidth(): /*TODO Type: '*' not found.*/ = js.native
  def addCustomData(oCustomData: CustomData): this.type = js.native
  def addDependent(oDependent: this.type): this.type = js.native
  def addEventDelegate(oDelegate: Object, oThis: Object): this.type = js.native
  def applyFocusInfo(oFocusInfo: Object): Unit = js.native
  def bindElement(vPath: String | Object, mParameters: Object): this.type = js.native
//  def clone(sIdSuffix: String, aLocalIds: /*TODO Type: 'string[]' not found.*/): ManagedObject = js.native
  def create(vData: this.type | Object, oKeyInfo: Object): Unit = js.native
  def data(): Unit = js.native
  def defineClass(sClassName: String, oStaticInfo: Object, fnMetaImpl: js.Function1[Event[EventProps], Unit]): Object = js.native
  def destroy(bSuppressInvalidate: Boolean): Unit = js.native
  def destroyCustomData(): this.type = js.native
  def destroyDependents(): this.type = js.native
  def destroyLayoutData(): this.type = js.native
  def destroyTooltip(): this.type = js.native
  def enhanceAccessibilityState(oElement: this.type, mAriaProps: Object): Object = js.native
  def exit(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def findElements(bRecursive: Boolean): js.Array[Element] = js.native
  def fireEvent(sEventId: String, mParameters: Object): this.type = js.native
  def focus(): Unit = js.native
  def getCustomData(): js.Array[CustomData] = js.native
  def getDependents(): js.Array[Element] = js.native
//  def getDomRef(sSuffix: String): /*TODO Type: 'Element' not found.*/ = js.native
  def getElementBinding(sModelName: String): Binding = js.native
//  def getFocusDomRef(): /*TODO Type: 'Element' not found.*/ = js.native
  def getFocusInfo(): Object = js.native
  def getInterface(): Unit = js.native
  def getLayoutData(): LayoutData = js.native
  def getMetadata(): Object = js.native
  def getMetadata(): Metadata = js.native
  def getTooltip(): String | TooltipBase = js.native
  def getTooltip_AsString(): String = js.native
  def getTooltip_Text(): String = js.native
  def indexOfCustomData(oCustomData: CustomData): Int = js.native
  def indexOfDependent(oDependent: this.type): Int = js.native
  def init(): Unit = js.native
  def insertCustomData(oCustomData: CustomData, iIndex: Int): this.type = js.native
  def insertDependent(oDependent: this.type, iIndex: Int): this.type = js.native
//  def prop(sPropertyName: String, oValue: /*TODO Type: 'any' not found.*/): /*TODO Type: 'any' not found.*/ | this.type = js.native
  def removeAllCustomData(): js.Array[CustomData] = js.native
  def removeAllDependents(): js.Array[Element] = js.native
  def removeCustomData(vCustomData: Int | String | CustomData): CustomData = js.native
  def removeDependent(vDependent: Int | String | this.type): this.type = js.native
  def removeEventDelegate(oDelegate: Object): this.type = js.native
  def rerender(): Unit = js.native
  def setLayoutData(oLayoutData: LayoutData): Unit = js.native
  def setTooltip(vTooltip: String | TooltipBase): Unit = js.native
  def toString(): String = js.native
  def unbindElement(sModelName: String): ManagedObject = js.native
}
     