
package com.sap.scala.facades.openui5.core.message

import com.sap.scala.facades.openui5.base.{Metadata,ManagedObject}
import com.sap.scala.facades.openui5.core.message.{Message,MessageProcessor}
import com.sap.scala.facades.openui5.model.message.MessageModel


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.message.MessageManager")
@js.native
class MessageManager() extends EventProvider {
  def addMessages(vMessages: Message | js.Array[Message]): Unit = js.native
  def destroy(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMessageModel(): MessageModel = js.native
  def getMetadata(): Metadata = js.native
  def registerMessageProcessor(oProcessor: MessageProcessor): Unit = js.native
  def registerObject(oObject: ManagedObject, bHandleValidation: Boolean): Unit = js.native
  def removeAllMessages(): Unit = js.native
  def removeMessages(vMessages: Message | js.Array[Message]): Unit = js.native
  def unregisterMessageProcessor(oProcessor: MessageProcessor): Unit = js.native
  def unregisterObject(oObject: ManagedObject): Unit = js.native
}
     