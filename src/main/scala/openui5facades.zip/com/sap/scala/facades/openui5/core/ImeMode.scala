package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ImeMode extends js.Object

object ImeMode{
  @JSGlobal("sap.ui.core.ImeMode.Active")
  @js.native
  object Active extends ImeMode

  @JSGlobal("sap.ui.core.ImeMode.Auto")
  @js.native
  object Auto extends ImeMode

  @JSGlobal("sap.ui.core.ImeMode.Disabled")
  @js.native
  object Disabled extends ImeMode

  @JSGlobal("sap.ui.core.ImeMode.Inactive")
  @js.native
  object Inactive extends ImeMode
}

/* copy to Enum.scala
sealed trait ImeMode{
  private[ui] def toFacade: sap.ui.core.ImeMode
}

object ImeMode {
  def fromFacade(s: ui.core.ImeMode): ImeMode = s match {
    case ui.core.ImeMode.Active => ImeMode.Active
    case ui.core.ImeMode.Auto => ImeMode.Auto
    case ui.core.ImeMode.Disabled => ImeMode.Disabled
    case ui.core.ImeMode.Inactive => ImeMode.Inactive
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ImeMode: $s")
  }
  
  object Active extends ImeMode {
    override private[ui] def toFacade: ui.core.ImeMode = ui.core.ImeMode.Active
  }

  object Auto extends ImeMode {
    override private[ui] def toFacade: ui.core.ImeMode = ui.core.ImeMode.Auto
  }

  object Disabled extends ImeMode {
    override private[ui] def toFacade: ui.core.ImeMode = ui.core.ImeMode.Disabled
  }

  object Inactive extends ImeMode {
    override private[ui] def toFacade: ui.core.ImeMode = ui.core.ImeMode.Inactive
  }

}
*/
