package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait TreeSelectionMode extends js.Object

object TreeSelectionMode{
  @JSGlobal("sap.ui.commons.TreeSelectionMode.Legacy")
  @js.native
  object Legacy extends TreeSelectionMode

  @JSGlobal("sap.ui.commons.TreeSelectionMode.Multi")
  @js.native
  object Multi extends TreeSelectionMode

  @JSGlobal("sap.ui.commons.TreeSelectionMode.None")
  @js.native
  object None extends TreeSelectionMode

  @JSGlobal("sap.ui.commons.TreeSelectionMode.Single")
  @js.native
  object Single extends TreeSelectionMode
}

/* copy to Enum.scala
sealed trait TreeSelectionMode{
  private[ui] def toFacade: sap.ui.commons.TreeSelectionMode
}

object TreeSelectionMode {
  def fromFacade(s: ui.commons.TreeSelectionMode): TreeSelectionMode = s match {
    case ui.commons.TreeSelectionMode.Legacy => TreeSelectionMode.Legacy
    case ui.commons.TreeSelectionMode.Multi => TreeSelectionMode.Multi
    case ui.commons.TreeSelectionMode.None => TreeSelectionMode.None
    case ui.commons.TreeSelectionMode.Single => TreeSelectionMode.Single
   case _ =>
     throw new UnsupportedOperationException(s"Unknown TreeSelectionMode: $s")
  }
  
  object Legacy extends TreeSelectionMode {
    override private[ui] def toFacade: ui.commons.TreeSelectionMode = ui.commons.TreeSelectionMode.Legacy
  }

  object Multi extends TreeSelectionMode {
    override private[ui] def toFacade: ui.commons.TreeSelectionMode = ui.commons.TreeSelectionMode.Multi
  }

  object None extends TreeSelectionMode {
    override private[ui] def toFacade: ui.commons.TreeSelectionMode = ui.commons.TreeSelectionMode.None
  }

  object Single extends TreeSelectionMode {
    override private[ui] def toFacade: ui.commons.TreeSelectionMode = ui.commons.TreeSelectionMode.Single
  }

}
*/
