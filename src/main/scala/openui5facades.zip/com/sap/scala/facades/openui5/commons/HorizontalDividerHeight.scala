package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait HorizontalDividerHeight extends js.Object

object HorizontalDividerHeight{
  @JSGlobal("sap.ui.commons.HorizontalDividerHeight.Large")
  @js.native
  object Large extends HorizontalDividerHeight

  @JSGlobal("sap.ui.commons.HorizontalDividerHeight.Medium")
  @js.native
  object Medium extends HorizontalDividerHeight

  @JSGlobal("sap.ui.commons.HorizontalDividerHeight.Ruleheight")
  @js.native
  object Ruleheight extends HorizontalDividerHeight

  @JSGlobal("sap.ui.commons.HorizontalDividerHeight.Small")
  @js.native
  object Small extends HorizontalDividerHeight
}

/* copy to Enum.scala
sealed trait HorizontalDividerHeight{
  private[ui] def toFacade: sap.ui.commons.HorizontalDividerHeight
}

object HorizontalDividerHeight {
  def fromFacade(s: ui.commons.HorizontalDividerHeight): HorizontalDividerHeight = s match {
    case ui.commons.HorizontalDividerHeight.Large => HorizontalDividerHeight.Large
    case ui.commons.HorizontalDividerHeight.Medium => HorizontalDividerHeight.Medium
    case ui.commons.HorizontalDividerHeight.Ruleheight => HorizontalDividerHeight.Ruleheight
    case ui.commons.HorizontalDividerHeight.Small => HorizontalDividerHeight.Small
   case _ =>
     throw new UnsupportedOperationException(s"Unknown HorizontalDividerHeight: $s")
  }
  
  object Large extends HorizontalDividerHeight {
    override private[ui] def toFacade: ui.commons.HorizontalDividerHeight = ui.commons.HorizontalDividerHeight.Large
  }

  object Medium extends HorizontalDividerHeight {
    override private[ui] def toFacade: ui.commons.HorizontalDividerHeight = ui.commons.HorizontalDividerHeight.Medium
  }

  object Ruleheight extends HorizontalDividerHeight {
    override private[ui] def toFacade: ui.commons.HorizontalDividerHeight = ui.commons.HorizontalDividerHeight.Ruleheight
  }

  object Small extends HorizontalDividerHeight {
    override private[ui] def toFacade: ui.commons.HorizontalDividerHeight = ui.commons.HorizontalDividerHeight.Small
  }

}
*/
