
package com.sap.scala.facades.openui5.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{Control,ID}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.layout.ResponsiveFlowLayout")
@js.native
class ResponsiveFlowLayout() extends Control {
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def addContent(oContent: Control): Unit = js.native
  def destroyContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getContent(): js.Array[Control] = js.native
  def getMetadata(): Metadata = js.native
  def getResponsive(): Boolean = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): Unit = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def removeContent(oContent: Int | String | Control): Control = js.native
  def setResponsive(bResponsive: Boolean): this.type = js.native
}
     