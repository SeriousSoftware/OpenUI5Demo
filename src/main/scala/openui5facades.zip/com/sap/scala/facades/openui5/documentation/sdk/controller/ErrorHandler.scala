
package com.sap.scala.facades.openui5.documentation.sdk.controller

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.documentation.sdk.controller.ErrorHandler")
@js.native
class ErrorHandler()  {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
}
     