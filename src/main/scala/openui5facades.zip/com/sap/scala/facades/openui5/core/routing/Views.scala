
package com.sap.scala.facades.openui5.core.routing

import com.sap.scala.facades.openui5.core.mvc.View
import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.routing.Views")
@js.native
class Views() extends EventProvider {
  def attachCreated(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachCreated(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireCreated(mArguments: Object): this.type = js.native
  def getMetadata(): Metadata = js.native
//  def getView(oOptions: Object): /*TODO Type: 'Promise' not found.*/ = js.native
//  def setView(sViewName: String, oView: View | /*TODO Type: 'null' not found.*/ | /*TODO Type: 'undefined' not found.*/): this.type = js.native
}
     