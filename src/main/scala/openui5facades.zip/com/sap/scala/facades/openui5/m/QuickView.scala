
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.PlacementType
import com.sap.scala.facades.openui5.core.{CSSSize,Control}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.QuickView")
@js.native
class QuickView() extends QuickViewBase {
  def attachAfterClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachAfterOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachAfterClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachAfterOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterClose(mParameters: Object): this.type = js.native
  def fireAfterOpen(mParameters: Object): this.type = js.native
  def fireBeforeClose(mParameters: Object): this.type = js.native
  def fireBeforeOpen(mParameters: Object): this.type = js.native
  def getMetadata(): Metadata = js.native
  def getPlacement(): PlacementType = js.native
  def getWidth(): CSSSize = js.native
  def openBy(oControl: Control): this.type = js.native
  def setPlacement(sPlacement: PlacementType): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     