package com.sap.scala.facades.openui5.core.format.NumberFormat

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait RoundingMode extends js.Object

object RoundingMode{
  @JSGlobal("sap.ui.core.format.NumberFormat.RoundingMode.AWAY_FROM_ZERO")
  @js.native
  object AWAY_FROM_ZERO extends RoundingMode

  @JSGlobal("sap.ui.core.format.NumberFormat.RoundingMode.CEILING")
  @js.native
  object CEILING extends RoundingMode

  @JSGlobal("sap.ui.core.format.NumberFormat.RoundingMode.FLOOR")
  @js.native
  object FLOOR extends RoundingMode

  @JSGlobal("sap.ui.core.format.NumberFormat.RoundingMode.HALF_AWAY_FROM_ZERO")
  @js.native
  object HALF_AWAY_FROM_ZERO extends RoundingMode

  @JSGlobal("sap.ui.core.format.NumberFormat.RoundingMode.HALF_CEILING")
  @js.native
  object HALF_CEILING extends RoundingMode

  @JSGlobal("sap.ui.core.format.NumberFormat.RoundingMode.HALF_FLOOR")
  @js.native
  object HALF_FLOOR extends RoundingMode

  @JSGlobal("sap.ui.core.format.NumberFormat.RoundingMode.HALF_TOWARDS_ZERO")
  @js.native
  object HALF_TOWARDS_ZERO extends RoundingMode

  @JSGlobal("sap.ui.core.format.NumberFormat.RoundingMode.TOWARDS_ZERO")
  @js.native
  object TOWARDS_ZERO extends RoundingMode
}

/* copy to Enum.scala
sealed trait RoundingMode{
  private[ui] def toFacade: sap.ui.core.format.NumberFormat.RoundingMode
}

object RoundingMode {
  def fromFacade(s: ui.core.format.NumberFormat.RoundingMode): RoundingMode = s match {
    case ui.core.format.NumberFormat.RoundingMode.AWAY_FROM_ZERO => RoundingMode.AWAY_FROM_ZERO
    case ui.core.format.NumberFormat.RoundingMode.CEILING => RoundingMode.CEILING
    case ui.core.format.NumberFormat.RoundingMode.FLOOR => RoundingMode.FLOOR
    case ui.core.format.NumberFormat.RoundingMode.HALF_AWAY_FROM_ZERO => RoundingMode.HALF_AWAY_FROM_ZERO
    case ui.core.format.NumberFormat.RoundingMode.HALF_CEILING => RoundingMode.HALF_CEILING
    case ui.core.format.NumberFormat.RoundingMode.HALF_FLOOR => RoundingMode.HALF_FLOOR
    case ui.core.format.NumberFormat.RoundingMode.HALF_TOWARDS_ZERO => RoundingMode.HALF_TOWARDS_ZERO
    case ui.core.format.NumberFormat.RoundingMode.TOWARDS_ZERO => RoundingMode.TOWARDS_ZERO
   case _ =>
     throw new UnsupportedOperationException(s"Unknown RoundingMode: $s")
  }
  
  object AWAY_FROM_ZERO extends RoundingMode {
    override private[ui] def toFacade: ui.core.format.NumberFormat.RoundingMode = ui.core.format.NumberFormat.RoundingMode.AWAY_FROM_ZERO
  }

  object CEILING extends RoundingMode {
    override private[ui] def toFacade: ui.core.format.NumberFormat.RoundingMode = ui.core.format.NumberFormat.RoundingMode.CEILING
  }

  object FLOOR extends RoundingMode {
    override private[ui] def toFacade: ui.core.format.NumberFormat.RoundingMode = ui.core.format.NumberFormat.RoundingMode.FLOOR
  }

  object HALF_AWAY_FROM_ZERO extends RoundingMode {
    override private[ui] def toFacade: ui.core.format.NumberFormat.RoundingMode = ui.core.format.NumberFormat.RoundingMode.HALF_AWAY_FROM_ZERO
  }

  object HALF_CEILING extends RoundingMode {
    override private[ui] def toFacade: ui.core.format.NumberFormat.RoundingMode = ui.core.format.NumberFormat.RoundingMode.HALF_CEILING
  }

  object HALF_FLOOR extends RoundingMode {
    override private[ui] def toFacade: ui.core.format.NumberFormat.RoundingMode = ui.core.format.NumberFormat.RoundingMode.HALF_FLOOR
  }

  object HALF_TOWARDS_ZERO extends RoundingMode {
    override private[ui] def toFacade: ui.core.format.NumberFormat.RoundingMode = ui.core.format.NumberFormat.RoundingMode.HALF_TOWARDS_ZERO
  }

  object TOWARDS_ZERO extends RoundingMode {
    override private[ui] def toFacade: ui.core.format.NumberFormat.RoundingMode = ui.core.format.NumberFormat.RoundingMode.TOWARDS_ZERO
  }

}
*/
