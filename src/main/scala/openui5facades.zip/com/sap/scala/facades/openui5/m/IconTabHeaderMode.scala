package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait IconTabHeaderMode extends js.Object

object IconTabHeaderMode{

}

/* copy to Enum.scala
sealed trait IconTabHeaderMode{
  private[ui] def toFacade: sap.m.IconTabHeaderMode
}

object IconTabHeaderMode {
  def fromFacade(s: m.IconTabHeaderMode): IconTabHeaderMode = s match {

   case _ =>
     throw new UnsupportedOperationException(s"Unknown IconTabHeaderMode: $s")
  }
  

}
*/
