package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait DialogType extends js.Object

object DialogType{
  @JSGlobal("sap.m.DialogType.Message")
  @js.native
  object Message extends DialogType

  @JSGlobal("sap.m.DialogType.Standard")
  @js.native
  object Standard extends DialogType
}

/* copy to Enum.scala
sealed trait DialogType{
  private[ui] def toFacade: sap.m.DialogType
}

object DialogType {
  def fromFacade(s: m.DialogType): DialogType = s match {
    case m.DialogType.Message => DialogType.Message
    case m.DialogType.Standard => DialogType.Standard
   case _ =>
     throw new UnsupportedOperationException(s"Unknown DialogType: $s")
  }
  
  object Message extends DialogType {
    override private[ui] def toFacade: m.DialogType = m.DialogType.Message
  }

  object Standard extends DialogType {
    override private[ui] def toFacade: m.DialogType = m.DialogType.Standard
  }

}
*/
