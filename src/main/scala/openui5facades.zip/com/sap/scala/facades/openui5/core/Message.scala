
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{URI,MessageType}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.Message")
@js.native
class Message() extends Element {
  def compareByType(oOther: this.type): Int = js.native
  def compareByType(oMessage1: this.type, oMessage2: this.type): Int = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getDefaultIcon(sSize: String): URI = js.native
  def getIcon(): URI = js.native
  def getLevel(): MessageType = js.native
  def getMetadata(): Metadata = js.native
  def getReadOnly(): Boolean = js.native
  def getText(): String = js.native
  def getTimestamp(): String = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setLevel(sLevel: MessageType): this.type = js.native
  def setReadOnly(bReadOnly: Boolean): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTimestamp(sTimestamp: String): this.type = js.native
}
     