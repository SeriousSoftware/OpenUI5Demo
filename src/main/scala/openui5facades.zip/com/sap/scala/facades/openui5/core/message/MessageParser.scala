
package com.sap.scala.facades.openui5.core.message

import com.sap.scala.facades.openui5.core.message.MessageProcessor
import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.message.MessageParser")
@js.native
class MessageParser() extends Object {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getProcessor(): MessageProcessor = js.native
  def parse(): Unit = js.native
  def setProcessor(oProcessor: MessageProcessor): this.type = js.native
}
     