
package com.sap.scala.facades.openui5.core.search

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.search.SearchProvider")
@js.native
class SearchProvider() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getIcon(): String = js.native
  def getMetadata(): Metadata = js.native
  def setIcon(sIcon: String): this.type = js.native
  def suggest(sValue: String, fnCallback: js.Function1[Event[EventProps], Unit]): Unit = js.native
}
     