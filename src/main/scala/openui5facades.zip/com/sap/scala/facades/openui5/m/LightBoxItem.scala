
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{Image,Text}
import com.sap.scala.facades.openui5.core.URI


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.LightBoxItem")
@js.native
class LightBoxItem() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAlt(): String = js.native
  def getImageSrc(): URI = js.native
  def getMetadata(): Metadata = js.native
  def getSubtitle(): String = js.native
  def getTitle(): String = js.native
  def setAlt(sAlt: String): this.type = js.native
  def setImageSrc(sImageSrc: URI): this.type = js.native
  def setSubtitle(sSubtitle: String): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
}
     