
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize
import com.sap.scala.facades.openui5.commons.{ToolbarDesign,ToolbarItem}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Toolbar")
@js.native
class Toolbar() extends Control {
  def addItem(oItem: ToolbarItem): this.type = js.native
  def addRightItem(oRightItem: ToolbarItem): this.type = js.native
  def destroyItems(): this.type = js.native
  def destroyRightItems(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getDesign(): ToolbarDesign = js.native
  def getItems(): js.Array[ToolbarItem] = js.native
  def getMetadata(): Metadata = js.native
  def getRightItems(): js.Array[ToolbarItem] = js.native
  def getStandalone(): Boolean = js.native
  def getWidth(): CSSSize = js.native
  def indexOfItem(oItem: ToolbarItem): Int = js.native
  def indexOfRightItem(oRightItem: ToolbarItem): Int = js.native
  def insertItem(oItem: ToolbarItem, iIndex: Int): this.type = js.native
  def insertRightItem(oRightItem: ToolbarItem, iIndex: Int): this.type = js.native
  def removeAllItems(): js.Array[ToolbarItem] = js.native
  def removeAllRightItems(): js.Array[ToolbarItem] = js.native
  def removeItem(vItem: Int | String | ToolbarItem): ToolbarItem = js.native
  def removeRightItem(vRightItem: Int | String | ToolbarItem): ToolbarItem = js.native
  def setDesign(sDesign: ToolbarDesign): this.type = js.native
  def setStandalone(bStandalone: Boolean): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     