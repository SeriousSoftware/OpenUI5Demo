package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait IconColor extends js.Object

object IconColor{
  @JSGlobal("sap.ui.core.IconColor.Critical")
  @js.native
  object Critical extends IconColor

  @JSGlobal("sap.ui.core.IconColor.Default")
  @js.native
  object Default extends IconColor

  @JSGlobal("sap.ui.core.IconColor.Negative")
  @js.native
  object Negative extends IconColor

  @JSGlobal("sap.ui.core.IconColor.Neutral")
  @js.native
  object Neutral extends IconColor

  @JSGlobal("sap.ui.core.IconColor.Positive")
  @js.native
  object Positive extends IconColor
}

/* copy to Enum.scala
sealed trait IconColor{
  private[ui] def toFacade: sap.ui.core.IconColor
}

object IconColor {
  def fromFacade(s: ui.core.IconColor): IconColor = s match {
    case ui.core.IconColor.Critical => IconColor.Critical
    case ui.core.IconColor.Default => IconColor.Default
    case ui.core.IconColor.Negative => IconColor.Negative
    case ui.core.IconColor.Neutral => IconColor.Neutral
    case ui.core.IconColor.Positive => IconColor.Positive
   case _ =>
     throw new UnsupportedOperationException(s"Unknown IconColor: $s")
  }
  
  object Critical extends IconColor {
    override private[ui] def toFacade: ui.core.IconColor = ui.core.IconColor.Critical
  }

  object Default extends IconColor {
    override private[ui] def toFacade: ui.core.IconColor = ui.core.IconColor.Default
  }

  object Negative extends IconColor {
    override private[ui] def toFacade: ui.core.IconColor = ui.core.IconColor.Negative
  }

  object Neutral extends IconColor {
    override private[ui] def toFacade: ui.core.IconColor = ui.core.IconColor.Neutral
  }

  object Positive extends IconColor {
    override private[ui] def toFacade: ui.core.IconColor = ui.core.IconColor.Positive
  }

}
*/
