
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.core.mvc.HTMLView


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.DeclarativeSupport")
@js.native
class DeclarativeSupport()  {
//  def compile(oElement: /*TODO Type: 'Element' not found.*/, oView: HTMLView, isRecursive: Boolean): Unit = js.native
}
     