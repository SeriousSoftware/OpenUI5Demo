package com.sap.scala.facades.openui5.commons.enums

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait BorderDesign extends js.Object

object BorderDesign{
  @JSGlobal("sap.ui.commons.enums.BorderDesign.Box")
  @js.native
  object Box extends BorderDesign

  @JSGlobal("sap.ui.commons.enums.BorderDesign.None")
  @js.native
  object None extends BorderDesign
}

/* copy to Enum.scala
sealed trait BorderDesign{
  private[ui] def toFacade: sap.ui.commons.enums.BorderDesign
}

object BorderDesign {
  def fromFacade(s: ui.commons.enums.BorderDesign): BorderDesign = s match {
    case ui.commons.enums.BorderDesign.Box => BorderDesign.Box
    case ui.commons.enums.BorderDesign.None => BorderDesign.None
   case _ =>
     throw new UnsupportedOperationException(s"Unknown BorderDesign: $s")
  }
  
  object Box extends BorderDesign {
    override private[ui] def toFacade: ui.commons.enums.BorderDesign = ui.commons.enums.BorderDesign.Box
  }

  object None extends BorderDesign {
    override private[ui] def toFacade: ui.commons.enums.BorderDesign = ui.commons.enums.BorderDesign.None
  }

}
*/
