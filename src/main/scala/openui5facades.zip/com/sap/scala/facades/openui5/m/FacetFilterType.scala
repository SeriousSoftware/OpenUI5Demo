package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait FacetFilterType extends js.Object

object FacetFilterType{
  @JSGlobal("sap.m.FacetFilterType.Light")
  @js.native
  object Light extends FacetFilterType

  @JSGlobal("sap.m.FacetFilterType.Simple")
  @js.native
  object Simple extends FacetFilterType
}

/* copy to Enum.scala
sealed trait FacetFilterType{
  private[ui] def toFacade: sap.m.FacetFilterType
}

object FacetFilterType {
  def fromFacade(s: m.FacetFilterType): FacetFilterType = s match {
    case m.FacetFilterType.Light => FacetFilterType.Light
    case m.FacetFilterType.Simple => FacetFilterType.Simple
   case _ =>
     throw new UnsupportedOperationException(s"Unknown FacetFilterType: $s")
  }
  
  object Light extends FacetFilterType {
    override private[ui] def toFacade: m.FacetFilterType = m.FacetFilterType.Light
  }

  object Simple extends FacetFilterType {
    override private[ui] def toFacade: m.FacetFilterType = m.FacetFilterType.Simple
  }

}
*/
