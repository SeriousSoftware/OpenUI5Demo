package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait InputTextFormatMode extends js.Object

object InputTextFormatMode{
  @JSGlobal("sap.m.InputTextFormatMode.Key")
  @js.native
  object Key extends InputTextFormatMode

  @JSGlobal("sap.m.InputTextFormatMode.KeyValue")
  @js.native
  object KeyValue extends InputTextFormatMode

  @JSGlobal("sap.m.InputTextFormatMode.Value")
  @js.native
  object Value extends InputTextFormatMode

  @JSGlobal("sap.m.InputTextFormatMode.ValueKey")
  @js.native
  object ValueKey extends InputTextFormatMode
}

/* copy to Enum.scala
sealed trait InputTextFormatMode{
  private[ui] def toFacade: sap.m.InputTextFormatMode
}

object InputTextFormatMode {
  def fromFacade(s: m.InputTextFormatMode): InputTextFormatMode = s match {
    case m.InputTextFormatMode.Key => InputTextFormatMode.Key
    case m.InputTextFormatMode.KeyValue => InputTextFormatMode.KeyValue
    case m.InputTextFormatMode.Value => InputTextFormatMode.Value
    case m.InputTextFormatMode.ValueKey => InputTextFormatMode.ValueKey
   case _ =>
     throw new UnsupportedOperationException(s"Unknown InputTextFormatMode: $s")
  }
  
  object Key extends InputTextFormatMode {
    override private[ui] def toFacade: m.InputTextFormatMode = m.InputTextFormatMode.Key
  }

  object KeyValue extends InputTextFormatMode {
    override private[ui] def toFacade: m.InputTextFormatMode = m.InputTextFormatMode.KeyValue
  }

  object Value extends InputTextFormatMode {
    override private[ui] def toFacade: m.InputTextFormatMode = m.InputTextFormatMode.Value
  }

  object ValueKey extends InputTextFormatMode {
    override private[ui] def toFacade: m.InputTextFormatMode = m.InputTextFormatMode.ValueKey
  }

}
*/
