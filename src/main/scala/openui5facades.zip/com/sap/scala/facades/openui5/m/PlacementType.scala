package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait PlacementType extends js.Object

object PlacementType{
  @JSGlobal("sap.m.PlacementType.Auto")
  @js.native
  object Auto extends PlacementType

  @JSGlobal("sap.m.PlacementType.Bottom")
  @js.native
  object Bottom extends PlacementType

  @JSGlobal("sap.m.PlacementType.Horizontal")
  @js.native
  object Horizontal extends PlacementType

  @JSGlobal("sap.m.PlacementType.HorizontalPreferedLeft")
  @js.native
  object HorizontalPreferedLeft extends PlacementType

  @JSGlobal("sap.m.PlacementType.HorizontalPreferedRight")
  @js.native
  object HorizontalPreferedRight extends PlacementType

  @JSGlobal("sap.m.PlacementType.HorizontalPreferredLeft")
  @js.native
  object HorizontalPreferredLeft extends PlacementType

  @JSGlobal("sap.m.PlacementType.HorizontalPreferredRight")
  @js.native
  object HorizontalPreferredRight extends PlacementType

  @JSGlobal("sap.m.PlacementType.Left")
  @js.native
  object Left extends PlacementType

  @JSGlobal("sap.m.PlacementType.PreferredBottomOrFlip")
  @js.native
  object PreferredBottomOrFlip extends PlacementType

  @JSGlobal("sap.m.PlacementType.PreferredLeftOrFlip")
  @js.native
  object PreferredLeftOrFlip extends PlacementType

  @JSGlobal("sap.m.PlacementType.PreferredRightOrFlip")
  @js.native
  object PreferredRightOrFlip extends PlacementType

  @JSGlobal("sap.m.PlacementType.PreferredTopOrFlip")
  @js.native
  object PreferredTopOrFlip extends PlacementType

  @JSGlobal("sap.m.PlacementType.Right")
  @js.native
  object Right extends PlacementType

  @JSGlobal("sap.m.PlacementType.Top")
  @js.native
  object Top extends PlacementType

  @JSGlobal("sap.m.PlacementType.Vertical")
  @js.native
  object Vertical extends PlacementType

  @JSGlobal("sap.m.PlacementType.VerticalPreferedBottom")
  @js.native
  object VerticalPreferedBottom extends PlacementType

  @JSGlobal("sap.m.PlacementType.VerticalPreferedTop")
  @js.native
  object VerticalPreferedTop extends PlacementType

  @JSGlobal("sap.m.PlacementType.VerticalPreferredBottom")
  @js.native
  object VerticalPreferredBottom extends PlacementType

  @JSGlobal("sap.m.PlacementType.VerticalPreferredTop")
  @js.native
  object VerticalPreferredTop extends PlacementType
}

/* copy to Enum.scala
sealed trait PlacementType{
  private[ui] def toFacade: sap.m.PlacementType
}

object PlacementType {
  def fromFacade(s: m.PlacementType): PlacementType = s match {
    case m.PlacementType.Auto => PlacementType.Auto
    case m.PlacementType.Bottom => PlacementType.Bottom
    case m.PlacementType.Horizontal => PlacementType.Horizontal
    case m.PlacementType.HorizontalPreferedLeft => PlacementType.HorizontalPreferedLeft
    case m.PlacementType.HorizontalPreferedRight => PlacementType.HorizontalPreferedRight
    case m.PlacementType.HorizontalPreferredLeft => PlacementType.HorizontalPreferredLeft
    case m.PlacementType.HorizontalPreferredRight => PlacementType.HorizontalPreferredRight
    case m.PlacementType.Left => PlacementType.Left
    case m.PlacementType.PreferredBottomOrFlip => PlacementType.PreferredBottomOrFlip
    case m.PlacementType.PreferredLeftOrFlip => PlacementType.PreferredLeftOrFlip
    case m.PlacementType.PreferredRightOrFlip => PlacementType.PreferredRightOrFlip
    case m.PlacementType.PreferredTopOrFlip => PlacementType.PreferredTopOrFlip
    case m.PlacementType.Right => PlacementType.Right
    case m.PlacementType.Top => PlacementType.Top
    case m.PlacementType.Vertical => PlacementType.Vertical
    case m.PlacementType.VerticalPreferedBottom => PlacementType.VerticalPreferedBottom
    case m.PlacementType.VerticalPreferedTop => PlacementType.VerticalPreferedTop
    case m.PlacementType.VerticalPreferredBottom => PlacementType.VerticalPreferredBottom
    case m.PlacementType.VerticalPreferredTop => PlacementType.VerticalPreferredTop
   case _ =>
     throw new UnsupportedOperationException(s"Unknown PlacementType: $s")
  }
  
  object Auto extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.Auto
  }

  object Bottom extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.Bottom
  }

  object Horizontal extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.Horizontal
  }

  object HorizontalPreferedLeft extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.HorizontalPreferedLeft
  }

  object HorizontalPreferedRight extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.HorizontalPreferedRight
  }

  object HorizontalPreferredLeft extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.HorizontalPreferredLeft
  }

  object HorizontalPreferredRight extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.HorizontalPreferredRight
  }

  object Left extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.Left
  }

  object PreferredBottomOrFlip extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.PreferredBottomOrFlip
  }

  object PreferredLeftOrFlip extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.PreferredLeftOrFlip
  }

  object PreferredRightOrFlip extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.PreferredRightOrFlip
  }

  object PreferredTopOrFlip extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.PreferredTopOrFlip
  }

  object Right extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.Right
  }

  object Top extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.Top
  }

  object Vertical extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.Vertical
  }

  object VerticalPreferedBottom extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.VerticalPreferedBottom
  }

  object VerticalPreferedTop extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.VerticalPreferedTop
  }

  object VerticalPreferredBottom extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.VerticalPreferredBottom
  }

  object VerticalPreferredTop extends PlacementType {
    override private[ui] def toFacade: m.PlacementType = m.PlacementType.VerticalPreferredTop
  }

}
*/
