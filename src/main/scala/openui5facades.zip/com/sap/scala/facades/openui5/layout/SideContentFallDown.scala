package com.sap.scala.facades.openui5.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait SideContentFallDown extends js.Object

object SideContentFallDown{
  @JSGlobal("sap.ui.layout.SideContentFallDown.BelowL")
  @js.native
  object BelowL extends SideContentFallDown

  @JSGlobal("sap.ui.layout.SideContentFallDown.BelowM")
  @js.native
  object BelowM extends SideContentFallDown

  @JSGlobal("sap.ui.layout.SideContentFallDown.BelowXL")
  @js.native
  object BelowXL extends SideContentFallDown

  @JSGlobal("sap.ui.layout.SideContentFallDown.OnMinimumWidth")
  @js.native
  object OnMinimumWidth extends SideContentFallDown
}

/* copy to Enum.scala
sealed trait SideContentFallDown{
  private[ui] def toFacade: sap.ui.layout.SideContentFallDown
}

object SideContentFallDown {
  def fromFacade(s: ui.layout.SideContentFallDown): SideContentFallDown = s match {
    case ui.layout.SideContentFallDown.BelowL => SideContentFallDown.BelowL
    case ui.layout.SideContentFallDown.BelowM => SideContentFallDown.BelowM
    case ui.layout.SideContentFallDown.BelowXL => SideContentFallDown.BelowXL
    case ui.layout.SideContentFallDown.OnMinimumWidth => SideContentFallDown.OnMinimumWidth
   case _ =>
     throw new UnsupportedOperationException(s"Unknown SideContentFallDown: $s")
  }
  
  object BelowL extends SideContentFallDown {
    override private[ui] def toFacade: ui.layout.SideContentFallDown = ui.layout.SideContentFallDown.BelowL
  }

  object BelowM extends SideContentFallDown {
    override private[ui] def toFacade: ui.layout.SideContentFallDown = ui.layout.SideContentFallDown.BelowM
  }

  object BelowXL extends SideContentFallDown {
    override private[ui] def toFacade: ui.layout.SideContentFallDown = ui.layout.SideContentFallDown.BelowXL
  }

  object OnMinimumWidth extends SideContentFallDown {
    override private[ui] def toFacade: ui.layout.SideContentFallDown = ui.layout.SideContentFallDown.OnMinimumWidth
  }

}
*/
