package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Orientation extends js.Object

object Orientation{
  @JSGlobal("sap.ui.core.Orientation.Horizontal")
  @js.native
  object Horizontal extends Orientation

  @JSGlobal("sap.ui.core.Orientation.Vertical")
  @js.native
  object Vertical extends Orientation
}

/* copy to Enum.scala
sealed trait Orientation{
  private[ui] def toFacade: sap.ui.core.Orientation
}

object Orientation {
  def fromFacade(s: ui.core.Orientation): Orientation = s match {
    case ui.core.Orientation.Horizontal => Orientation.Horizontal
    case ui.core.Orientation.Vertical => Orientation.Vertical
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Orientation: $s")
  }
  
  object Horizontal extends Orientation {
    override private[ui] def toFacade: ui.core.Orientation = ui.core.Orientation.Horizontal
  }

  object Vertical extends Orientation {
    override private[ui] def toFacade: ui.core.Orientation = ui.core.Orientation.Vertical
  }

}
*/
