
package com.sap.scala.facades.openui5.core.search

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.URI


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.search.OpenSearchProvider")
@js.native
class OpenSearchProvider() extends SearchProvider {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getSuggestType(): String = js.native
  def getSuggestUrl(): URI = js.native
  def setSuggestType(sSuggestType: String): this.type = js.native
  def setSuggestUrl(sSuggestUrl: URI): this.type = js.native
  def suggest(sValue: String, fCallback: js.Function1[Event[EventProps], Unit]): Unit = js.native
}
     