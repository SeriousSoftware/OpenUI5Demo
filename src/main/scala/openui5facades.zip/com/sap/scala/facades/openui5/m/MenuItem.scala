
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.MenuItem


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.MenuItem")
@js.native
class MenuItem() extends Item {
  def addItem(oItem: this.type): this.type = js.native
  def attachAggregationChanged(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachPropertyChanged(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindItems(oBindingInfo: Object): this.type = js.native
  def destroyItems(): this.type = js.native
  def detachAggregationChanged(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPropertyChanged(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAggregationChanged(mParameters: Object): this.type = js.native
  def firePress(mParameters: Object): this.type = js.native
  def firePropertyChanged(mParameters: Object): this.type = js.native
  def getIcon(): String = js.native
  def getItems(): js.Array[MenuItem] = js.native
  def getMetadata(): Metadata = js.native
  def getStartsSection(): Boolean = js.native
  def getVisible(): Boolean = js.native
  def indexOfItem(oItem: this.type): Int = js.native
  def insertItem(oItem: this.type, iIndex: Int): this.type = js.native
  def removeAllItems(): js.Array[MenuItem] = js.native
  def removeItem(vItem: Int | String | this.type): this.type = js.native
  def setIcon(sIcon: String): this.type = js.native
  def setStartsSection(bStartsSection: Boolean): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
  def unbindItems(): this.type = js.native
}
     