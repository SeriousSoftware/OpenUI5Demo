
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.Button


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.PagingButton")
@js.native
class PagingButton() extends Control {
  def attachPositionChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPositionChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePositionChange(mParameters: Object): this.type = js.native
  def getCount(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getNextButtonTooltip(): String = js.native
  def getPosition(): Int = js.native
  def getPreviousButtonTooltip(): String = js.native
}
     