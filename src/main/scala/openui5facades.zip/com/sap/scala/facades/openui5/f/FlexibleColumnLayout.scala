
package com.sap.scala.facades.openui5.f

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{NavContainer,Button}
import com.sap.scala.facades.openui5.core.{Control,ID}
import com.sap.scala.facades.openui5.f.LayoutType


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.f.FlexibleColumnLayout")
@js.native
class FlexibleColumnLayout() extends Control {
  def addBeginColumnPage(oBeginColumnPage: Control): this.type = js.native
  def addEndColumnPage(oEndColumnPage: Control): this.type = js.native
  def addMidColumnPage(oMidColumnPage: Control): this.type = js.native
  def attachAfterBeginColumnNavigate(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachAfterEndColumnNavigate(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachAfterMidColumnNavigate(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeginColumnNavigate(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachEndColumnNavigate(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachMidColumnNavigate(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachStateChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def backToPage(sPageId: String, oBackData: Object, oTransitionParameters: Object): this.type = js.native
  def backToTopBeginColumn(oBackData: Object, oTransitionParameter: Object): Control = js.native
  def backToTopEndColumn(oBackData: Object, oTransitionParameter: Object): Control = js.native
  def backToTopMidColumn(oBackData: Object, oTransitionParameter: Object): Control = js.native
  def destroyBeginColumnPages(): this.type = js.native
  def destroyEndColumnPages(): this.type = js.native
  def destroyMidColumnPages(): this.type = js.native
  def detachAfterBeginColumnNavigate(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachAfterEndColumnNavigate(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachAfterMidColumnNavigate(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeginColumnNavigate(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachEndColumnNavigate(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachMidColumnNavigate(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachStateChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterBeginColumnNavigate(mParameters: Object): this.type = js.native
  def fireAfterEndColumnNavigate(mParameters: Object): this.type = js.native
  def fireAfterMidColumnNavigate(mParameters: Object): this.type = js.native
  def fireBeginColumnNavigate(mParameters: Object): Boolean = js.native
  def fireEndColumnNavigate(mParameters: Object): Boolean = js.native
  def fireMidColumnNavigate(mParameters: Object): Boolean = js.native
  def fireStateChange(mParameters: Object): this.type = js.native
  def getBeginColumnPages(): js.Array[Control] = js.native
  def getCurrentBeginColumnPage(): Control = js.native
  def getCurrentEndColumnPage(): Control = js.native
  def getCurrentMidColumnPage(): Control = js.native
  def getDefaultTransitionNameBeginColumn(): String = js.native
  def getDefaultTransitionNameEndColumn(): String = js.native
  def getDefaultTransitionNameMidColumn(): String = js.native
  def getEndColumnPages(): js.Array[Control] = js.native
  def getInitialBeginColumnPage(): ID = js.native
  def getInitialEndColumnPage(): ID = js.native
  def getInitialMidColumnPage(): ID = js.native
  def getLayout(): LayoutType = js.native
//  def getMaxColumnsCount(): /*TODO Type: 'number' not found.*/ = js.native
  def getMetadata(): Metadata = js.native
  def getMidColumnPages(): js.Array[Control] = js.native
  def indexOfBeginColumnPage(oBeginColumnPage: Control): Int = js.native
  def indexOfEndColumnPage(oEndColumnPage: Control): Int = js.native
  def indexOfMidColumnPage(oMidColumnPage: Control): Int = js.native
  def insertBeginColumnPage(oBeginColumnPage: Control, iIndex: Int): this.type = js.native
  def insertEndColumnPage(oEndColumnPage: Control, iIndex: Int): this.type = js.native
  def insertMidColumnPage(oMidColumnPage: Control, iIndex: Int): this.type = js.native
  def removeAllBeginColumnPages(): js.Array[Control] = js.native
  def removeAllEndColumnPages(): js.Array[Control] = js.native
  def removeAllMidColumnPages(): js.Array[Control] = js.native
  def removeBeginColumnPage(vBeginColumnPage: Int | String | Control): Control = js.native
  def removeEndColumnPage(vEndColumnPage: Int | String | Control): Control = js.native
  def removeMidColumnPage(vMidColumnPage: Int | String | Control): Control = js.native
  def setDefaultTransitionNameBeginColumn(sDefaultTransitionNameBeginColumn: String): this.type = js.native
  def setDefaultTransitionNameEndColumn(sDefaultTransitionNameEndColumn: String): this.type = js.native
  def setDefaultTransitionNameMidColumn(sDefaultTransitionNameMidColumn: String): this.type = js.native
  def setInitialBeginColumnPage(oInitialBeginColumnPage: ID | Control): this.type = js.native
  def setInitialEndColumnPage(oInitialEndColumnPage: ID | Control): this.type = js.native
  def setInitialMidColumnPage(oInitialMidColumnPage: ID | Control): this.type = js.native
  def setLayout(sLayout: LayoutType): this.type = js.native
  def to(sPageId: String, sTransitionName: String, oData: Object, oTransitionParameters: Object): this.type = js.native
  def toBeginColumnPage(sPageId: String, sTransitionName: String, oData: Object, oTransitionParameters: Object): this.type = js.native
  def toEndColumnPage(sPageId: String, sTransitionName: String, oData: Object, oTransitionParameters: Object): this.type = js.native
  def toMidColumnPage(sPageId: String, sTransitionName: String, oData: Object, oTransitionParameters: Object): this.type = js.native
}
     