
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.ID
import com.sap.scala.facades.openui5.commons.Button


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.SegmentedButton")
@js.native
class SegmentedButton() extends Control {
  def _rerenderButtons(): Unit = js.native
  def addButton(oButton: Button): this.type = js.native
  def attachSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyButtons(): this.type = js.native
  def detachSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireSelect(mParameters: Object): this.type = js.native
  def getButtons(): js.Array[Button] = js.native
  def getEnabled(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getSelectedButton(): ID = js.native
  def indexOfButton(oButton: Button): Int = js.native
  def insertButton(oButton: Button, iIndex: Int): this.type = js.native
  def removeAllButtons(): js.Array[Button] = js.native
  def removeButton(vButton: Int | String | Button): Button = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setSelectedButton(oSelectedButton: ID | Button): this.type = js.native
}
     