package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ImageMode extends js.Object

object ImageMode{
  @JSGlobal("sap.m.ImageMode.Background")
  @js.native
  object Background extends ImageMode

  @JSGlobal("sap.m.ImageMode.Image")
  @js.native
  object Image extends ImageMode
}

/* copy to Enum.scala
sealed trait ImageMode{
  private[ui] def toFacade: sap.m.ImageMode
}

object ImageMode {
  def fromFacade(s: m.ImageMode): ImageMode = s match {
    case m.ImageMode.Background => ImageMode.Background
    case m.ImageMode.Image => ImageMode.Image
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ImageMode: $s")
  }
  
  object Background extends ImageMode {
    override private[ui] def toFacade: m.ImageMode = m.ImageMode.Background
  }

  object Image extends ImageMode {
    override private[ui] def toFacade: m.ImageMode = m.ImageMode.Image
  }

}
*/
