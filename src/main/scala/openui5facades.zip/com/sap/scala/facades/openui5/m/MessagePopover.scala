
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{MessagePopoverItem,MessageItem,Button,VerticalPlacementType}
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.MessagePopover")
@js.native
class MessagePopover() extends Control {
  def addItem(vItem: MessageItem | MessagePopoverItem): this.type = js.native
  def attachAfterClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachAfterOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachItemSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachListSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachLongtextLoaded(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachUrlValidated(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def close(): this.type = js.native
  def destroyHeaderButton(): this.type = js.native
  def destroyItems(): this.type = js.native
  def detachAfterClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachAfterOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachItemSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachListSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachLongtextLoaded(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachUrlValidated(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterClose(mParameters: Object): this.type = js.native
  def fireAfterOpen(mParameters: Object): this.type = js.native
  def fireBeforeClose(mParameters: Object): this.type = js.native
  def fireBeforeOpen(mParameters: Object): this.type = js.native
  def fireItemSelect(mParameters: Object): this.type = js.native
  def fireListSelect(mParameters: Object): this.type = js.native
  def fireLongtextLoaded(mParameters: Object): this.type = js.native
  def fireUrlValidated(mParameters: Object): this.type = js.native
//  def getAsyncDescriptionHandler(): /*TODO Type: 'any' not found.*/ = js.native
//  def getAsyncURLHandler(): /*TODO Type: 'any' not found.*/ = js.native
  def getHeaderButton(): Button = js.native
  def getInitiallyExpanded(): Boolean = js.native
  def getItems(): Unit = js.native
  def getMetadata(): Metadata = js.native
  def getPlacement(): VerticalPlacementType = js.native
  def indexOfItem(vItem: MessageItem | MessagePopoverItem): Int = js.native
  def insertItem(vItem: MessageItem | MessagePopoverItem, iIndex: Int): this.type = js.native
  def isOpen(): Boolean = js.native
  def openBy(oControl: Control): this.type = js.native
  def removeAllItems(): Unit = js.native
  def removeItem(vItem: Int | String | MessageItem | MessagePopoverItem): MessageItem | MessagePopoverItem = js.native
//  def setAsyncDescriptionHandler(oAsyncDescriptionHandler: /*TODO Type: 'any' not found.*/): this.type = js.native
//  def setAsyncURLHandler(oAsyncURLHandler: /*TODO Type: 'any' not found.*/): this.type = js.native
  def setDefaultHandlers(mDefaultHandlers: Object): Unit = js.native
  def setHeaderButton(oHeaderButton: Button): this.type = js.native
  def setInitiallyExpanded(bInitiallyExpanded: Boolean): this.type = js.native
  def toggle(oControl: Control): this.type = js.native
}
     