
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{Image,OverflowToolbar,Text,Button}
import com.sap.scala.facades.openui5.core.{URI,Control,Priority}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.NotificationListBase")
@js.native
class NotificationListBase() extends ListItemBase {
  def _getAuthorImage(): Image | Control = js.native
  def _getAuthorName(): Text = js.native
  def _getDateTimeText(): Text = js.native
  def _getHeaderTitle(): Text = js.native
  def _getToolbar(): OverflowToolbar = js.native
  def addButton(oButton: Button): this.type = js.native
  def attachClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyButtons(): this.type = js.native
  def detachClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireClose(mParameters: Object): this.type = js.native
  def getAuthorName(): String = js.native
  def getAuthorPicture(): URI = js.native
  def getButtons(): js.Array[Button] = js.native
  def getDatetime(): String = js.native
  def getMetadata(): Metadata = js.native
  def getPriority(): Priority = js.native
  def getShowButtons(): Boolean = js.native
  def getShowCloseButton(): Boolean = js.native
  def getTitle(): String = js.native
  def indexOfButton(oButton: Button): Int = js.native
  def insertButton(oButton: Button, iIndex: Int): this.type = js.native
  def removeAllButtons(): js.Array[Button] = js.native
  def removeButton(vButton: Int | String | Button): Button = js.native
  def setAuthorName(sAuthorName: String): this.type = js.native
  def setAuthorPicture(sAuthorPicture: URI): this.type = js.native
  def setDatetime(sDatetime: String): this.type = js.native
  def setPriority(sPriority: Priority): this.type = js.native
  def setShowButtons(bShowButtons: Boolean): this.type = js.native
  def setShowCloseButton(bShowCloseButton: Boolean): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
}
     