
package com.sap.scala.facades.openui5.core.service

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.service.ServiceFactory")
@js.native
class ServiceFactory() extends Object {
//  def createInstance(oServiceContext: Object): /*TODO Type: 'Promise' not found.*/ = js.native
  def destroy(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
}
     