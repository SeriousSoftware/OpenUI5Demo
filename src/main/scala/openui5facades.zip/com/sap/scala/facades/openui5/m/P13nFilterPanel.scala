
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{P13nFilterItem,P13nConditionOperation}
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nFilterPanel")
@js.native
class P13nFilterPanel() extends P13nPanel {
  def addFilterItem(oFilterItem: P13nFilterItem): this.type = js.native
  def attachAddFilterItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachRemoveFilterItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachUpdateFilterItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindFilterItems(oBindingInfo: Object): this.type = js.native
  def destroyFilterItems(): this.type = js.native
  def detachAddFilterItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachRemoveFilterItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachUpdateFilterItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAddFilterItem(mParameters: Object): this.type = js.native
  def fireRemoveFilterItem(mParameters: Object): this.type = js.native
  def fireUpdateFilterItem(mParameters: Object): this.type = js.native
  def getConditions(): Unit = js.native
  def getContainerQuery(): Boolean = js.native
  def getExcludeOperations(the: String): js.Array[P13nConditionOperation] = js.native
  def getFilterItems(): js.Array[P13nFilterItem] = js.native
  def getIncludeOperations(the: String): P13nConditionOperation = js.native
  def getLayoutMode(): String = js.native
  def getMaxExcludes(): String = js.native
  def getMaxIncludes(): String = js.native
  def getMetadata(): Metadata = js.native
  def indexOfFilterItem(oFilterItem: P13nFilterItem): Int = js.native
  def insertFilterItem(oFilterItem: P13nFilterItem, iIndex: Int): this.type = js.native
  def removeAllFilterItems(): js.Array[P13nFilterItem] = js.native
  def removeFilterItem(vFilterItem: Int | String | P13nFilterItem): P13nFilterItem = js.native
  def removeInvalidConditions(): Unit = js.native
  def removeValidationErrors(): Unit = js.native
//  def setConditions(aConditions: /*TODO Type: 'object[]' not found.*/): this.type = js.native
  def setContainerQuery(bContainerQuery: Boolean): this.type = js.native
  def setExcludeOperations(array: js.Array[P13nConditionOperation], the: String): Unit = js.native
  def setIncludeOperations(array: js.Array[P13nConditionOperation], the: String): Unit = js.native
  def setLayoutMode(sLayoutMode: String): this.type = js.native
  def setMaxExcludes(sMaxExcludes: String): this.type = js.native
  def setMaxIncludes(sMaxIncludes: String): this.type = js.native
  def unbindFilterItems(): this.type = js.native
  def validateConditions(): Boolean = js.native
}
     