package com.sap.scala.facades.openui5.core.routing

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait HistoryDirection extends js.Object

object HistoryDirection{
  @JSGlobal("sap.ui.core.routing.HistoryDirection.Backwards")
  @js.native
  object Backwards extends HistoryDirection

  @JSGlobal("sap.ui.core.routing.HistoryDirection.Forwards")
  @js.native
  object Forwards extends HistoryDirection

  @JSGlobal("sap.ui.core.routing.HistoryDirection.NewEntry")
  @js.native
  object NewEntry extends HistoryDirection

  @JSGlobal("sap.ui.core.routing.HistoryDirection.Unknown")
  @js.native
  object Unknown extends HistoryDirection
}

/* copy to Enum.scala
sealed trait HistoryDirection{
  private[ui] def toFacade: sap.ui.core.routing.HistoryDirection
}

object HistoryDirection {
  def fromFacade(s: ui.core.routing.HistoryDirection): HistoryDirection = s match {
    case ui.core.routing.HistoryDirection.Backwards => HistoryDirection.Backwards
    case ui.core.routing.HistoryDirection.Forwards => HistoryDirection.Forwards
    case ui.core.routing.HistoryDirection.NewEntry => HistoryDirection.NewEntry
    case ui.core.routing.HistoryDirection.Unknown => HistoryDirection.Unknown
   case _ =>
     throw new UnsupportedOperationException(s"Unknown HistoryDirection: $s")
  }
  
  object Backwards extends HistoryDirection {
    override private[ui] def toFacade: ui.core.routing.HistoryDirection = ui.core.routing.HistoryDirection.Backwards
  }

  object Forwards extends HistoryDirection {
    override private[ui] def toFacade: ui.core.routing.HistoryDirection = ui.core.routing.HistoryDirection.Forwards
  }

  object NewEntry extends HistoryDirection {
    override private[ui] def toFacade: ui.core.routing.HistoryDirection = ui.core.routing.HistoryDirection.NewEntry
  }

  object Unknown extends HistoryDirection {
    override private[ui] def toFacade: ui.core.routing.HistoryDirection = ui.core.routing.HistoryDirection.Unknown
  }

}
*/
