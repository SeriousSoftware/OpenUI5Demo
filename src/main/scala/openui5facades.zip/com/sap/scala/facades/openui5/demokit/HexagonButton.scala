
package com.sap.scala.facades.openui5.demokit

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.demokit.HexagonButton")
@js.native
class HexagonButton() extends Control {
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePress(mParameters: Object): this.type = js.native
  def getColor(): String = js.native
  def getEnabled(): Boolean = js.native
  def getIcon(): String = js.native
  def getImagePosition(): String = js.native
  def getMetadata(): Metadata = js.native
  def getPosition(): String = js.native
  def setColor(sColor: String): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setIcon(sIcon: String): this.type = js.native
  def setImagePosition(sImagePosition: String): this.type = js.native
  def setPosition(sPosition: String): this.type = js.native
}
     