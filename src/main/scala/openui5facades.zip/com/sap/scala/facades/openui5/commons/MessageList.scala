
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.commons.Message


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.MessageList")
@js.native
class MessageList() extends Control {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAnchorId(): String = js.native
  def getMaxListed(): String = js.native
  def getMetadata(): Metadata = js.native
  def getVisible(): Boolean = js.native
  def setAnchorId(sAnchorId: String): this.type = js.native
  def setMaxListed(sMaxListed: String): this.type = js.native
  def setMessages(aMessages: js.Array[Message]): Unit = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     