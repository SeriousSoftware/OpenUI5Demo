
package com.sap.scala.facades.openui5.f.routing

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.f.routing.TargetHandler


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.f.routing.Router")
@js.native
class Router() extends Router {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getTargetHandler(): TargetHandler = js.native
}
     