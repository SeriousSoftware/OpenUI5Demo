package com.sap.scala.facades.openui5.core.mvc.XMLView

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait PreprocessorType extends js.Object

object PreprocessorType{
  @JSGlobal("sap.ui.core.mvc.XMLView.PreprocessorType.CONTROLS")
  @js.native
  object CONTROLS extends PreprocessorType

  @JSGlobal("sap.ui.core.mvc.XMLView.PreprocessorType.VIEWXML")
  @js.native
  object VIEWXML extends PreprocessorType

  @JSGlobal("sap.ui.core.mvc.XMLView.PreprocessorType.XML")
  @js.native
  object XML extends PreprocessorType
}

/* copy to Enum.scala
sealed trait PreprocessorType{
  private[ui] def toFacade: sap.ui.core.mvc.XMLView.PreprocessorType
}

object PreprocessorType {
  def fromFacade(s: ui.core.mvc.XMLView.PreprocessorType): PreprocessorType = s match {
    case ui.core.mvc.XMLView.PreprocessorType.CONTROLS => PreprocessorType.CONTROLS
    case ui.core.mvc.XMLView.PreprocessorType.VIEWXML => PreprocessorType.VIEWXML
    case ui.core.mvc.XMLView.PreprocessorType.XML => PreprocessorType.XML
   case _ =>
     throw new UnsupportedOperationException(s"Unknown PreprocessorType: $s")
  }
  
  object CONTROLS extends PreprocessorType {
    override private[ui] def toFacade: ui.core.mvc.XMLView.PreprocessorType = ui.core.mvc.XMLView.PreprocessorType.CONTROLS
  }

  object VIEWXML extends PreprocessorType {
    override private[ui] def toFacade: ui.core.mvc.XMLView.PreprocessorType = ui.core.mvc.XMLView.PreprocessorType.VIEWXML
  }

  object XML extends PreprocessorType {
    override private[ui] def toFacade: ui.core.mvc.XMLView.PreprocessorType = ui.core.mvc.XMLView.PreprocessorType.XML
  }

}
*/
