
package com.sap.scala.facades.openui5.demokit

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.demokit.UI5EntityCueCardStyle


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.demokit.UI5EntityCueCard")
@js.native
class UI5EntityCueCard() extends Control {
  def attachNavigate(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachNavigate(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireNavigate(mParameters: Object): Boolean = js.native
  def getCollapsible(): Boolean = js.native
  def getEntityName(): String = js.native
  def getExpanded(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getNavigable(): Boolean = js.native
  def getStyle(): UI5EntityCueCardStyle = js.native
  def setCollapsible(bCollapsible: Boolean): this.type = js.native
  def setEntityName(sEntityName: String): this.type = js.native
  def setExpanded(bExpanded: Boolean): this.type = js.native
  def setNavigable(bNavigable: Boolean): this.type = js.native
  def setStyle(sStyle: UI5EntityCueCardStyle): this.type = js.native
}
     