package com.sap.scala.facades.openui5.core.ws

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ReadyState extends js.Object

object ReadyState{
  @JSGlobal("sap.ui.core.ws.ReadyState.CLOSED")
  @js.native
  object CLOSED extends ReadyState

  @JSGlobal("sap.ui.core.ws.ReadyState.CLOSING")
  @js.native
  object CLOSING extends ReadyState

  @JSGlobal("sap.ui.core.ws.ReadyState.CONNECTING")
  @js.native
  object CONNECTING extends ReadyState

  @JSGlobal("sap.ui.core.ws.ReadyState.OPEN")
  @js.native
  object OPEN extends ReadyState
}

/* copy to Enum.scala
sealed trait ReadyState{
  private[ui] def toFacade: sap.ui.core.ws.ReadyState
}

object ReadyState {
  def fromFacade(s: ui.core.ws.ReadyState): ReadyState = s match {
    case ui.core.ws.ReadyState.CLOSED => ReadyState.CLOSED
    case ui.core.ws.ReadyState.CLOSING => ReadyState.CLOSING
    case ui.core.ws.ReadyState.CONNECTING => ReadyState.CONNECTING
    case ui.core.ws.ReadyState.OPEN => ReadyState.OPEN
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ReadyState: $s")
  }
  
  object CLOSED extends ReadyState {
    override private[ui] def toFacade: ui.core.ws.ReadyState = ui.core.ws.ReadyState.CLOSED
  }

  object CLOSING extends ReadyState {
    override private[ui] def toFacade: ui.core.ws.ReadyState = ui.core.ws.ReadyState.CLOSING
  }

  object CONNECTING extends ReadyState {
    override private[ui] def toFacade: ui.core.ws.ReadyState = ui.core.ws.ReadyState.CONNECTING
  }

  object OPEN extends ReadyState {
    override private[ui] def toFacade: ui.core.ws.ReadyState = ui.core.ws.ReadyState.OPEN
  }

}
*/
