
package com.sap.scala.facades.openui5.core.tmpl

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.mvc.View
import com.sap.scala.facades.openui5.core.tmpl.TemplateControl


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.tmpl.Template")
@js.native
class Template() extends ManagedObject {
  def byId(sId: String): this.type = js.native
  def createControl(sId: String, oContext: Object, oView: View): TemplateControl = js.native
  def declareControl(sControl: String): js.Function1[Event[EventProps], Unit] = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getContent(): String = js.native
  def getInterface(): Unit = js.native
  def getMetadata(): Metadata = js.native
  def parsePath(sPath: String): Object = js.native
//  def placeAt(oRef: String | /*TODO Type: 'DomRef' not found.*/, oContext: Object, vPosition: String | Int, bInline: Boolean): TemplateControl = js.native
  def setContent(sContent: String): this.type = js.native
}
     