
package com.sap.scala.facades.openui5.app

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.model.Model
import com.sap.scala.facades.openui5.core.{Control,UIComponent}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.app.Application")
@js.native
class Application() extends Component {
  def createRootComponent(): UIComponent = js.native
  def destroy(): Unit = js.native
  def destroyRootComponent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
//  def getConfig(): /*TODO Type: 'any' not found.*/ = js.native
  def getMetadata(): Metadata = js.native
  def getRoot(): String = js.native
  def getRootComponent(): UIComponent = js.native
  def getView(): Control = js.native
  def main(): Unit = js.native
  def onBeforeExit(): String = js.native
//  def onError(sMessage: String, sFile: String, iLine: /*TODO Type: 'number' not found.*/): Unit = js.native
  def onExit(): Unit = js.native
  def setConfig(vConfig: String | Object | Model): Unit = js.native
  def setRoot(sRoot: String): this.type = js.native
  def setRootComponent(oRootComponent: UIComponent): this.type = js.native
}
     