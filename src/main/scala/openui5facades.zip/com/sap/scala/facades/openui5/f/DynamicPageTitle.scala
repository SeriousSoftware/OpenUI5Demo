
package com.sap.scala.facades.openui5.f

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.f.DynamicPageTitle")
@js.native
class DynamicPageTitle() extends Control {
  def addAction(oAction: Control): this.type = js.native
  def addExpandedContent(oExpandedContent: Control): this.type = js.native
  def addSnappedContent(oSnappedContent: Control): this.type = js.native
  def destroyActions(): this.type = js.native
  def destroyExpandedContent(): this.type = js.native
  def destroyHeading(): this.type = js.native
  def destroySnappedContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getActions(): js.Array[Control] = js.native
  def getExpandedContent(): js.Array[Control] = js.native
  def getHeading(): Control = js.native
  def getMetadata(): Metadata = js.native
  def getSnappedContent(): js.Array[Control] = js.native
  def indexOfAction(oAction: Control): Int = js.native
  def indexOfExpandedContent(oExpandedContent: Control): Int = js.native
  def indexOfSnappedContent(oSnappedContent: Control): Int = js.native
  def insertAction(oAction: Control, iIndex: Int): this.type = js.native
  def insertExpandedContent(oExpandedContent: Control, iIndex: Int): this.type = js.native
  def insertSnappedContent(oSnappedContent: Control, iIndex: Int): this.type = js.native
  def removeAction(vAction: Int | String | Control): Control = js.native
  def removeAllActions(): js.Array[Control] = js.native
  def removeAllExpandedContent(): js.Array[Control] = js.native
  def removeAllSnappedContent(): js.Array[Control] = js.native
  def removeExpandedContent(vExpandedContent: Int | String | Control): Control = js.native
  def removeSnappedContent(vSnappedContent: Int | String | Control): Control = js.native
  def setHeading(oHeading: Control): this.type = js.native
}
     