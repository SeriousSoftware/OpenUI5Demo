
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize
import com.sap.scala.facades.openui5.commons.MenuBarDesign
import com.sap.scala.facades.openui5.unified.MenuItem


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.MenuBar")
@js.native
class MenuBar() extends Control {
  def addItem(oItem: MenuItem): this.type = js.native
  def destroyItems(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getDesign(): MenuBarDesign = js.native
  def getEnabled(): Boolean = js.native
  def getItems(): js.Array[MenuItem] = js.native
  def getMetadata(): Metadata = js.native
  def getWidth(): CSSSize = js.native
  def indexOfItem(oItem: MenuItem): Int = js.native
  def insertItem(oItem: MenuItem, iIndex: Int): this.type = js.native
  def removeAllItems(): js.Array[MenuItem] = js.native
  def removeItem(vItem: Int | String | MenuItem): MenuItem = js.native
  def setDesign(sDesign: MenuBarDesign): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     