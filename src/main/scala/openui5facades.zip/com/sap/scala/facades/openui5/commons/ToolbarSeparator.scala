
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.commons.ToolbarSeparatorDesign


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.ToolbarSeparator")
@js.native
class ToolbarSeparator() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getDesign(): ToolbarSeparatorDesign = js.native
  def getDisplayVisualSeparator(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def setDesign(sDesign: ToolbarSeparatorDesign): this.type = js.native
  def setDisplayVisualSeparator(bDisplayVisualSeparator: Boolean): this.type = js.native
}
     