
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{MessageStrip,Text}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.NotificationListItem")
@js.native
class NotificationListItem() extends NotificationListBase {
  def destroyProcessingMessage(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getDescription(): String = js.native
  def getHideShowMoreButton(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getProcessingMessage(): MessageStrip = js.native
  def getTruncate(): Boolean = js.native
  def setDescription(sDescription: String): this.type = js.native
  def setHideShowMoreButton(bHideShowMoreButton: Boolean): this.type = js.native
  def setProcessingMessage(oProcessingMessage: MessageStrip): this.type = js.native
  def setTruncate(bTruncate: Boolean): this.type = js.native
}
     