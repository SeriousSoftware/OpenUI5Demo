
package com.sap.scala.facades.openui5.commons.form

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.commons.form.SimpleFormLayout


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.form.SimpleForm")
@js.native
class SimpleForm() extends SimpleForm {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getLayout(): SimpleFormLayout = js.native
  def getMetadata(): Metadata = js.native
  def setLayout(oLayout: SimpleFormLayout): this.type = js.native
}
     