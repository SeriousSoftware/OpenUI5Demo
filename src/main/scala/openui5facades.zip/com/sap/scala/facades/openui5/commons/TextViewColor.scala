package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait TextViewColor extends js.Object

object TextViewColor{
  @JSGlobal("sap.ui.commons.TextViewColor.Critical")
  @js.native
  object Critical extends TextViewColor

  @JSGlobal("sap.ui.commons.TextViewColor.Default")
  @js.native
  object Default extends TextViewColor

  @JSGlobal("sap.ui.commons.TextViewColor.Negative")
  @js.native
  object Negative extends TextViewColor

  @JSGlobal("sap.ui.commons.TextViewColor.Positive")
  @js.native
  object Positive extends TextViewColor
}

/* copy to Enum.scala
sealed trait TextViewColor{
  private[ui] def toFacade: sap.ui.commons.TextViewColor
}

object TextViewColor {
  def fromFacade(s: ui.commons.TextViewColor): TextViewColor = s match {
    case ui.commons.TextViewColor.Critical => TextViewColor.Critical
    case ui.commons.TextViewColor.Default => TextViewColor.Default
    case ui.commons.TextViewColor.Negative => TextViewColor.Negative
    case ui.commons.TextViewColor.Positive => TextViewColor.Positive
   case _ =>
     throw new UnsupportedOperationException(s"Unknown TextViewColor: $s")
  }
  
  object Critical extends TextViewColor {
    override private[ui] def toFacade: ui.commons.TextViewColor = ui.commons.TextViewColor.Critical
  }

  object Default extends TextViewColor {
    override private[ui] def toFacade: ui.commons.TextViewColor = ui.commons.TextViewColor.Default
  }

  object Negative extends TextViewColor {
    override private[ui] def toFacade: ui.commons.TextViewColor = ui.commons.TextViewColor.Negative
  }

  object Positive extends TextViewColor {
    override private[ui] def toFacade: ui.commons.TextViewColor = ui.commons.TextViewColor.Positive
  }

}
*/
