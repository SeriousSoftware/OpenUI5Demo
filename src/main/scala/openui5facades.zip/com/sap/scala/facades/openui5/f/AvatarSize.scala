package com.sap.scala.facades.openui5.f

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait AvatarSize extends js.Object

object AvatarSize{
  @JSGlobal("sap.f.AvatarSize.Custom")
  @js.native
  object Custom extends AvatarSize

  @JSGlobal("sap.f.AvatarSize.L")
  @js.native
  object L extends AvatarSize

  @JSGlobal("sap.f.AvatarSize.M")
  @js.native
  object M extends AvatarSize

  @JSGlobal("sap.f.AvatarSize.S")
  @js.native
  object S extends AvatarSize

  @JSGlobal("sap.f.AvatarSize.XL")
  @js.native
  object XL extends AvatarSize

  @JSGlobal("sap.f.AvatarSize.XS")
  @js.native
  object XS extends AvatarSize
}

/* copy to Enum.scala
sealed trait AvatarSize{
  private[ui] def toFacade: sap.f.AvatarSize
}

object AvatarSize {
  def fromFacade(s: f.AvatarSize): AvatarSize = s match {
    case f.AvatarSize.Custom => AvatarSize.Custom
    case f.AvatarSize.L => AvatarSize.L
    case f.AvatarSize.M => AvatarSize.M
    case f.AvatarSize.S => AvatarSize.S
    case f.AvatarSize.XL => AvatarSize.XL
    case f.AvatarSize.XS => AvatarSize.XS
   case _ =>
     throw new UnsupportedOperationException(s"Unknown AvatarSize: $s")
  }
  
  object Custom extends AvatarSize {
    override private[ui] def toFacade: f.AvatarSize = f.AvatarSize.Custom
  }

  object L extends AvatarSize {
    override private[ui] def toFacade: f.AvatarSize = f.AvatarSize.L
  }

  object M extends AvatarSize {
    override private[ui] def toFacade: f.AvatarSize = f.AvatarSize.M
  }

  object S extends AvatarSize {
    override private[ui] def toFacade: f.AvatarSize = f.AvatarSize.S
  }

  object XL extends AvatarSize {
    override private[ui] def toFacade: f.AvatarSize = f.AvatarSize.XL
  }

  object XS extends AvatarSize {
    override private[ui] def toFacade: f.AvatarSize = f.AvatarSize.XS
  }

}
*/
