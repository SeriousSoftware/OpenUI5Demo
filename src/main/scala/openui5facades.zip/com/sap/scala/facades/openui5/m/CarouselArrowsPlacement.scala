package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait CarouselArrowsPlacement extends js.Object

object CarouselArrowsPlacement{
  @JSGlobal("sap.m.CarouselArrowsPlacement.Content")
  @js.native
  object Content extends CarouselArrowsPlacement

  @JSGlobal("sap.m.CarouselArrowsPlacement.PageIndicator")
  @js.native
  object PageIndicator extends CarouselArrowsPlacement
}

/* copy to Enum.scala
sealed trait CarouselArrowsPlacement{
  private[ui] def toFacade: sap.m.CarouselArrowsPlacement
}

object CarouselArrowsPlacement {
  def fromFacade(s: m.CarouselArrowsPlacement): CarouselArrowsPlacement = s match {
    case m.CarouselArrowsPlacement.Content => CarouselArrowsPlacement.Content
    case m.CarouselArrowsPlacement.PageIndicator => CarouselArrowsPlacement.PageIndicator
   case _ =>
     throw new UnsupportedOperationException(s"Unknown CarouselArrowsPlacement: $s")
  }
  
  object Content extends CarouselArrowsPlacement {
    override private[ui] def toFacade: m.CarouselArrowsPlacement = m.CarouselArrowsPlacement.Content
  }

  object PageIndicator extends CarouselArrowsPlacement {
    override private[ui] def toFacade: m.CarouselArrowsPlacement = m.CarouselArrowsPlacement.PageIndicator
  }

}
*/
