
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.ListItem")
@js.native
class ListItem() extends Item {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAdditionalText(): String = js.native
  def getIcon(): String = js.native
  def getMetadata(): Metadata = js.native
  def setAdditionalText(sAdditionalText: String): this.type = js.native
  def setIcon(sIcon: String): this.type = js.native
}
     