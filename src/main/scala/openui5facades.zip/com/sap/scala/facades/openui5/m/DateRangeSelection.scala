
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.DateRangeSelection")
@js.native
class DateRangeSelection() extends DatePicker {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
//  def fireChange(mArguments: /*TODO Type: 'Map' not found.*/): this.type = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getDateValue(): Object = js.native
  def getDelimiter(): String = js.native
  def getFrom(): Object = js.native
  def getMetadata(): Metadata = js.native
  def getSecondDateValue(): Object = js.native
  def getTo(): Object = js.native
  def getValue(): String = js.native
  def getValueFormat(): String = js.native
  def init(): Unit = js.native
  def setDateValue(oDateValue: Object): this.type = js.native
  def setDelimiter(sDelimiter: String): this.type = js.native
  def setFrom(oFrom: Object): this.type = js.native
  def setSecondDateValue(oSecondDateValue: Object): this.type = js.native
  def setTo(oTo: Object): this.type = js.native
  def setValue(sValue: String): this.type = js.native
  def setValueFormat(sValueFormat: String): this.type = js.native
}
     