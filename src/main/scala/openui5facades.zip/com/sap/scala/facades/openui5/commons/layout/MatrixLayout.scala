
package com.sap.scala.facades.openui5.commons.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control}
import com.sap.scala.facades.openui5.commons.layout.{MatrixLayoutCell,MatrixLayoutRow}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.layout.MatrixLayout")
@js.native
class MatrixLayout() extends Control {
  def addRow(oRow: MatrixLayoutRow): this.type = js.native
  def createRow(rowContent: Control | MatrixLayoutCell | String): this.type = js.native
  def destroyRows(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getColumns(): Int = js.native
  def getHeight(): CSSSize = js.native
  def getLayoutFixed(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getRows(): js.Array[MatrixLayoutRow] = js.native
  def getWidth(): CSSSize = js.native
  def getWidths(): js.Array[CSSSize] = js.native
  def indexOfRow(oRow: MatrixLayoutRow): Int = js.native
  def insertRow(oRow: MatrixLayoutRow, iIndex: Int): this.type = js.native
  def removeAllRows(): js.Array[MatrixLayoutRow] = js.native
  def removeRow(vRow: Int | String | MatrixLayoutRow): MatrixLayoutRow = js.native
  def setColumns(iColumns: Int): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setLayoutFixed(bLayoutFixed: Boolean): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
  def setWidths(sWidths: js.Array[CSSSize]): this.type = js.native
}
     