
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.URI


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.DropdownBox")
@js.native
class DropdownBox() extends ComboBox {
  def attachSearchHelp(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def clearHistory(): Unit = js.native
  def detachSearchHelp(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireSearchHelp(mParameters: Object): this.type = js.native
  def getMaxHistoryItems(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getSearchHelpAdditionalText(): String = js.native
  def getSearchHelpEnabled(): Boolean = js.native
  def getSearchHelpIcon(): URI = js.native
  def getSearchHelpText(): String = js.native
  def getTooltip_AsString(): String = js.native
//  def onAfterRendering(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onclick(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onfocusin(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onkeydown(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onkeypress(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onkeyup(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onpaste(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsapdelete(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsaphome(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsapleft(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsapright(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsapshow(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onselect(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
  def setMaxHistoryItems(iMaxHistoryItems: Int): this.type = js.native
  def setSearchHelpAdditionalText(sSearchHelpAdditionalText: String): this.type = js.native
  def setSearchHelpEnabled(bEnabled: Boolean, sText: String, sAdditionalText: String, sIcon: String): this.type = js.native
  def setSearchHelpIcon(sSearchHelpIcon: URI): this.type = js.native
  def setSearchHelpText(sSearchHelpText: String): this.type = js.native
}
     