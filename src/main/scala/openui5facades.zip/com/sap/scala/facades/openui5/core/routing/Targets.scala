
package com.sap.scala.facades.openui5.core.routing

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.routing.{Target,Views}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.routing.Targets")
@js.native
class Targets() extends EventProvider {
  def addTarget(sName: String, oTarget: Object): this.type = js.native
  def attachDisplay(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachTitleChanged(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroy(): this.type = js.native
  def detachDisplay(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachTitleChanged(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
//  def display(vTargets: String | /*TODO Type: 'string[]' not found.*/, oData: Object, sTitleTarget: String): this.type | /*TODO Type: 'Promise' not found.*/ = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireDisplay(mArguments: Object): this.type = js.native
  def getMetadata(): Metadata = js.native
//  def getTarget(vName: String | /*TODO Type: 'string[]' not found.*/): Target | /*TODO Type: 'undefined' not found.*/ | js.Array[Target] = js.native
  def getViews(): Views = js.native
}
     