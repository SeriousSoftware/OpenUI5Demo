
package com.sap.scala.facades.openui5.commons.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize
import com.sap.scala.facades.openui5.commons.layout.MatrixLayoutCell


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.layout.MatrixLayoutRow")
@js.native
class MatrixLayoutRow() extends Element {
  def addCell(oCell: MatrixLayoutCell): this.type = js.native
  def addStyleClass(sStyleClass: String): this.type = js.native
  def destroyCells(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getCells(): js.Array[MatrixLayoutCell] = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def hasStyleClass(sStyleClass: String): Boolean = js.native
  def indexOfCell(oCell: MatrixLayoutCell): Int = js.native
  def insertCell(oCell: MatrixLayoutCell, iIndex: Int): this.type = js.native
  def removeAllCells(): js.Array[MatrixLayoutCell] = js.native
  def removeCell(vCell: Int | String | MatrixLayoutCell): MatrixLayoutCell = js.native
  def removeStyleClass(sStyleClass: String): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
}
     