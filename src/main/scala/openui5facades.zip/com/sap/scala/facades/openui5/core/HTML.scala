
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.HTML")
@js.native
class HTML() extends Control {
  def attachAfterRendering(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachAfterRendering(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterRendering(mParameters: Object): this.type = js.native
  def getContent(): String = js.native
//  def getDomRef(sSuffix: String): /*TODO Type: 'Element' not found.*/ = js.native
  def getMetadata(): Metadata = js.native
  def getPreferDOM(): Boolean = js.native
  def getSanitizeContent(): Boolean = js.native
  def getVisible(): Boolean = js.native
  def setContent(sContent: String): this.type = js.native
//  def setDOMContent(oDom: /*TODO Type: 'Element' not found.*/): this.type = js.native
  def setPreferDOM(bPreferDOM: Boolean): this.type = js.native
  def setSanitizeContent(bSanitizeContent: Boolean): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     