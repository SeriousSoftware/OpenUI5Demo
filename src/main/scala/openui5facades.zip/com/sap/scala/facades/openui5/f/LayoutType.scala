package com.sap.scala.facades.openui5.f

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait LayoutType extends js.Object

object LayoutType{
  @JSGlobal("sap.f.LayoutType.EndColumnFullScreen")
  @js.native
  object EndColumnFullScreen extends LayoutType

  @JSGlobal("sap.f.LayoutType.MidColumnFullScreen")
  @js.native
  object MidColumnFullScreen extends LayoutType

  @JSGlobal("sap.f.LayoutType.OneColumn")
  @js.native
  object OneColumn extends LayoutType

  @JSGlobal("sap.f.LayoutType.ThreeColumnsBeginExpandedEndHidden")
  @js.native
  object ThreeColumnsBeginExpandedEndHidden extends LayoutType

  @JSGlobal("sap.f.LayoutType.ThreeColumnsEndExpanded")
  @js.native
  object ThreeColumnsEndExpanded extends LayoutType

  @JSGlobal("sap.f.LayoutType.ThreeColumnsMidExpanded")
  @js.native
  object ThreeColumnsMidExpanded extends LayoutType

  @JSGlobal("sap.f.LayoutType.ThreeColumnsMidExpandedEndHidden")
  @js.native
  object ThreeColumnsMidExpandedEndHidden extends LayoutType

  @JSGlobal("sap.f.LayoutType.TwoColumnsBeginExpanded")
  @js.native
  object TwoColumnsBeginExpanded extends LayoutType

  @JSGlobal("sap.f.LayoutType.TwoColumnsMidExpanded")
  @js.native
  object TwoColumnsMidExpanded extends LayoutType
}

/* copy to Enum.scala
sealed trait LayoutType{
  private[ui] def toFacade: sap.f.LayoutType
}

object LayoutType {
  def fromFacade(s: f.LayoutType): LayoutType = s match {
    case f.LayoutType.EndColumnFullScreen => LayoutType.EndColumnFullScreen
    case f.LayoutType.MidColumnFullScreen => LayoutType.MidColumnFullScreen
    case f.LayoutType.OneColumn => LayoutType.OneColumn
    case f.LayoutType.ThreeColumnsBeginExpandedEndHidden => LayoutType.ThreeColumnsBeginExpandedEndHidden
    case f.LayoutType.ThreeColumnsEndExpanded => LayoutType.ThreeColumnsEndExpanded
    case f.LayoutType.ThreeColumnsMidExpanded => LayoutType.ThreeColumnsMidExpanded
    case f.LayoutType.ThreeColumnsMidExpandedEndHidden => LayoutType.ThreeColumnsMidExpandedEndHidden
    case f.LayoutType.TwoColumnsBeginExpanded => LayoutType.TwoColumnsBeginExpanded
    case f.LayoutType.TwoColumnsMidExpanded => LayoutType.TwoColumnsMidExpanded
   case _ =>
     throw new UnsupportedOperationException(s"Unknown LayoutType: $s")
  }
  
  object EndColumnFullScreen extends LayoutType {
    override private[ui] def toFacade: f.LayoutType = f.LayoutType.EndColumnFullScreen
  }

  object MidColumnFullScreen extends LayoutType {
    override private[ui] def toFacade: f.LayoutType = f.LayoutType.MidColumnFullScreen
  }

  object OneColumn extends LayoutType {
    override private[ui] def toFacade: f.LayoutType = f.LayoutType.OneColumn
  }

  object ThreeColumnsBeginExpandedEndHidden extends LayoutType {
    override private[ui] def toFacade: f.LayoutType = f.LayoutType.ThreeColumnsBeginExpandedEndHidden
  }

  object ThreeColumnsEndExpanded extends LayoutType {
    override private[ui] def toFacade: f.LayoutType = f.LayoutType.ThreeColumnsEndExpanded
  }

  object ThreeColumnsMidExpanded extends LayoutType {
    override private[ui] def toFacade: f.LayoutType = f.LayoutType.ThreeColumnsMidExpanded
  }

  object ThreeColumnsMidExpandedEndHidden extends LayoutType {
    override private[ui] def toFacade: f.LayoutType = f.LayoutType.ThreeColumnsMidExpandedEndHidden
  }

  object TwoColumnsBeginExpanded extends LayoutType {
    override private[ui] def toFacade: f.LayoutType = f.LayoutType.TwoColumnsBeginExpanded
  }

  object TwoColumnsMidExpanded extends LayoutType {
    override private[ui] def toFacade: f.LayoutType = f.LayoutType.TwoColumnsMidExpanded
  }

}
*/
