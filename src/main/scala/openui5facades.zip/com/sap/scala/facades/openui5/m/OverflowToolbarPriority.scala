package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait OverflowToolbarPriority extends js.Object

object OverflowToolbarPriority{
  @JSGlobal("sap.m.OverflowToolbarPriority.Always")
  @js.native
  object Always extends OverflowToolbarPriority

  @JSGlobal("sap.m.OverflowToolbarPriority.AlwaysOverflow")
  @js.native
  object AlwaysOverflow extends OverflowToolbarPriority

  @JSGlobal("sap.m.OverflowToolbarPriority.Disappear")
  @js.native
  object Disappear extends OverflowToolbarPriority

  @JSGlobal("sap.m.OverflowToolbarPriority.High")
  @js.native
  object High extends OverflowToolbarPriority

  @JSGlobal("sap.m.OverflowToolbarPriority.Low")
  @js.native
  object Low extends OverflowToolbarPriority

  @JSGlobal("sap.m.OverflowToolbarPriority.Never")
  @js.native
  object Never extends OverflowToolbarPriority

  @JSGlobal("sap.m.OverflowToolbarPriority.NeverOverflow")
  @js.native
  object NeverOverflow extends OverflowToolbarPriority
}

/* copy to Enum.scala
sealed trait OverflowToolbarPriority{
  private[ui] def toFacade: sap.m.OverflowToolbarPriority
}

object OverflowToolbarPriority {
  def fromFacade(s: m.OverflowToolbarPriority): OverflowToolbarPriority = s match {
    case m.OverflowToolbarPriority.Always => OverflowToolbarPriority.Always
    case m.OverflowToolbarPriority.AlwaysOverflow => OverflowToolbarPriority.AlwaysOverflow
    case m.OverflowToolbarPriority.Disappear => OverflowToolbarPriority.Disappear
    case m.OverflowToolbarPriority.High => OverflowToolbarPriority.High
    case m.OverflowToolbarPriority.Low => OverflowToolbarPriority.Low
    case m.OverflowToolbarPriority.Never => OverflowToolbarPriority.Never
    case m.OverflowToolbarPriority.NeverOverflow => OverflowToolbarPriority.NeverOverflow
   case _ =>
     throw new UnsupportedOperationException(s"Unknown OverflowToolbarPriority: $s")
  }
  
  object Always extends OverflowToolbarPriority {
    override private[ui] def toFacade: m.OverflowToolbarPriority = m.OverflowToolbarPriority.Always
  }

  object AlwaysOverflow extends OverflowToolbarPriority {
    override private[ui] def toFacade: m.OverflowToolbarPriority = m.OverflowToolbarPriority.AlwaysOverflow
  }

  object Disappear extends OverflowToolbarPriority {
    override private[ui] def toFacade: m.OverflowToolbarPriority = m.OverflowToolbarPriority.Disappear
  }

  object High extends OverflowToolbarPriority {
    override private[ui] def toFacade: m.OverflowToolbarPriority = m.OverflowToolbarPriority.High
  }

  object Low extends OverflowToolbarPriority {
    override private[ui] def toFacade: m.OverflowToolbarPriority = m.OverflowToolbarPriority.Low
  }

  object Never extends OverflowToolbarPriority {
    override private[ui] def toFacade: m.OverflowToolbarPriority = m.OverflowToolbarPriority.Never
  }

  object NeverOverflow extends OverflowToolbarPriority {
    override private[ui] def toFacade: m.OverflowToolbarPriority = m.OverflowToolbarPriority.NeverOverflow
  }

}
*/
