
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.OverflowToolbarPriority


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.OverflowToolbarLayoutData")
@js.native
class OverflowToolbarLayoutData() extends ToolbarLayoutData {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getCloseOverflowOnInteraction(): Boolean = js.native
  def getGroup(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getMoveToOverflow(): Boolean = js.native
  def getPriority(): OverflowToolbarPriority = js.native
  def getStayInOverflow(): Boolean = js.native
  def setCloseOverflowOnInteraction(bCloseOverflowOnInteraction: Boolean): this.type = js.native
  def setGroup(iGroup: Int): this.type = js.native
  def setMoveToOverflow(bMoveToOverflow: Boolean): this.type = js.native
  def setPriority(sPriority: OverflowToolbarPriority): this.type = js.native
  def setStayInOverflow(bStayInOverflow: Boolean): this.type = js.native
}
     