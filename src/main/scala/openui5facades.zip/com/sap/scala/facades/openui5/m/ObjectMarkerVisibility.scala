package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ObjectMarkerVisibility extends js.Object

object ObjectMarkerVisibility{
  @JSGlobal("sap.m.ObjectMarkerVisibility.IconAndText")
  @js.native
  object IconAndText extends ObjectMarkerVisibility

  @JSGlobal("sap.m.ObjectMarkerVisibility.IconOnly")
  @js.native
  object IconOnly extends ObjectMarkerVisibility

  @JSGlobal("sap.m.ObjectMarkerVisibility.TextOnly")
  @js.native
  object TextOnly extends ObjectMarkerVisibility
}

/* copy to Enum.scala
sealed trait ObjectMarkerVisibility{
  private[ui] def toFacade: sap.m.ObjectMarkerVisibility
}

object ObjectMarkerVisibility {
  def fromFacade(s: m.ObjectMarkerVisibility): ObjectMarkerVisibility = s match {
    case m.ObjectMarkerVisibility.IconAndText => ObjectMarkerVisibility.IconAndText
    case m.ObjectMarkerVisibility.IconOnly => ObjectMarkerVisibility.IconOnly
    case m.ObjectMarkerVisibility.TextOnly => ObjectMarkerVisibility.TextOnly
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ObjectMarkerVisibility: $s")
  }
  
  object IconAndText extends ObjectMarkerVisibility {
    override private[ui] def toFacade: m.ObjectMarkerVisibility = m.ObjectMarkerVisibility.IconAndText
  }

  object IconOnly extends ObjectMarkerVisibility {
    override private[ui] def toFacade: m.ObjectMarkerVisibility = m.ObjectMarkerVisibility.IconOnly
  }

  object TextOnly extends ObjectMarkerVisibility {
    override private[ui] def toFacade: m.ObjectMarkerVisibility = m.ObjectMarkerVisibility.TextOnly
  }

}
*/
