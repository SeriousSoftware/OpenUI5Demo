package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait FlexWrap extends js.Object

object FlexWrap{
  @JSGlobal("sap.m.FlexWrap.NoWrap")
  @js.native
  object NoWrap extends FlexWrap

  @JSGlobal("sap.m.FlexWrap.Wrap")
  @js.native
  object Wrap extends FlexWrap

  @JSGlobal("sap.m.FlexWrap.WrapReverse")
  @js.native
  object WrapReverse extends FlexWrap
}

/* copy to Enum.scala
sealed trait FlexWrap{
  private[ui] def toFacade: sap.m.FlexWrap
}

object FlexWrap {
  def fromFacade(s: m.FlexWrap): FlexWrap = s match {
    case m.FlexWrap.NoWrap => FlexWrap.NoWrap
    case m.FlexWrap.Wrap => FlexWrap.Wrap
    case m.FlexWrap.WrapReverse => FlexWrap.WrapReverse
   case _ =>
     throw new UnsupportedOperationException(s"Unknown FlexWrap: $s")
  }
  
  object NoWrap extends FlexWrap {
    override private[ui] def toFacade: m.FlexWrap = m.FlexWrap.NoWrap
  }

  object Wrap extends FlexWrap {
    override private[ui] def toFacade: m.FlexWrap = m.FlexWrap.Wrap
  }

  object WrapReverse extends FlexWrap {
    override private[ui] def toFacade: m.FlexWrap = m.FlexWrap.WrapReverse
  }

}
*/
