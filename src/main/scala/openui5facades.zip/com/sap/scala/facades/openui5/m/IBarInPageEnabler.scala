
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.core.{Control,RenderManager}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.IBarInPageEnabler")
@js.native
class IBarInPageEnabler()  {
  def addChildClassTo(oControl: Control): Unit = js.native
  def renderTooltip(oRM: RenderManager, oControl: Control): Unit = js.native
}
     