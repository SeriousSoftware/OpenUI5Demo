
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nFilterItem")
@js.native
class P13nFilterItem() extends Item {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getColumnKey(): String = js.native
  def getExclude(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getOperation(): String = js.native
  def getValue1(): String = js.native
  def getValue2(): String = js.native
  def setColumnKey(sColumnKey: String): this.type = js.native
  def setExclude(bExclude: Boolean): this.type = js.native
  def setOperation(sOperation: String): this.type = js.native
  def setValue1(sValue1: String): this.type = js.native
  def setValue2(sValue2: String): this.type = js.native
}
     