package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ButtonType extends js.Object

object ButtonType{
  @JSGlobal("sap.m.ButtonType.Accept")
  @js.native
  object Accept extends ButtonType

  @JSGlobal("sap.m.ButtonType.Back")
  @js.native
  object Back extends ButtonType

  @JSGlobal("sap.m.ButtonType.Default")
  @js.native
  object Default extends ButtonType

  @JSGlobal("sap.m.ButtonType.Emphasized")
  @js.native
  object Emphasized extends ButtonType

  @JSGlobal("sap.m.ButtonType.Reject")
  @js.native
  object Reject extends ButtonType

  @JSGlobal("sap.m.ButtonType.Transparent")
  @js.native
  object Transparent extends ButtonType

  @JSGlobal("sap.m.ButtonType.Unstyled")
  @js.native
  object Unstyled extends ButtonType

  @JSGlobal("sap.m.ButtonType.Up")
  @js.native
  object Up extends ButtonType
}

/* copy to Enum.scala
sealed trait ButtonType{
  private[ui] def toFacade: sap.m.ButtonType
}

object ButtonType {
  def fromFacade(s: m.ButtonType): ButtonType = s match {
    case m.ButtonType.Accept => ButtonType.Accept
    case m.ButtonType.Back => ButtonType.Back
    case m.ButtonType.Default => ButtonType.Default
    case m.ButtonType.Emphasized => ButtonType.Emphasized
    case m.ButtonType.Reject => ButtonType.Reject
    case m.ButtonType.Transparent => ButtonType.Transparent
    case m.ButtonType.Unstyled => ButtonType.Unstyled
    case m.ButtonType.Up => ButtonType.Up
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ButtonType: $s")
  }
  
  object Accept extends ButtonType {
    override private[ui] def toFacade: m.ButtonType = m.ButtonType.Accept
  }

  object Back extends ButtonType {
    override private[ui] def toFacade: m.ButtonType = m.ButtonType.Back
  }

  object Default extends ButtonType {
    override private[ui] def toFacade: m.ButtonType = m.ButtonType.Default
  }

  object Emphasized extends ButtonType {
    override private[ui] def toFacade: m.ButtonType = m.ButtonType.Emphasized
  }

  object Reject extends ButtonType {
    override private[ui] def toFacade: m.ButtonType = m.ButtonType.Reject
  }

  object Transparent extends ButtonType {
    override private[ui] def toFacade: m.ButtonType = m.ButtonType.Transparent
  }

  object Unstyled extends ButtonType {
    override private[ui] def toFacade: m.ButtonType = m.ButtonType.Unstyled
  }

  object Up extends ButtonType {
    override private[ui] def toFacade: m.ButtonType = m.ButtonType.Up
  }

}
*/
