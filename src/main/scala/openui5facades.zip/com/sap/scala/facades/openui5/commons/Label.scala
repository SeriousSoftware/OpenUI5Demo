
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,URI,Control,TextAlign,ID,TextDirection}
import com.sap.scala.facades.openui5.commons.LabelDesign


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Label")
@js.native
class Label() extends Control {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getDesign(): LabelDesign = js.native
  def getIcon(): URI = js.native
  def getLabelFor(): ID = js.native
  def getMetadata(): Metadata = js.native
  def getRequired(): Boolean = js.native
  def getRequiredAtBegin(): Boolean = js.native
  def getText(): String = js.native
  def getTextAlign(): TextAlign = js.native
  def getTextDirection(): TextDirection = js.native
  def getWidth(): CSSSize = js.native
  def getWrapping(): Boolean = js.native
  def setDesign(sDesign: LabelDesign): this.type = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setLabelFor(oLabelFor: ID | Control): this.type = js.native
  def setRequired(bRequired: Boolean): this.type = js.native
  def setRequiredAtBegin(bRequiredAtBegin: Boolean): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTextAlign(sTextAlign: TextAlign): this.type = js.native
  def setTextDirection(sTextDirection: TextDirection): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
  def setWrapping(bWrapping: Boolean): this.type = js.native
}
     