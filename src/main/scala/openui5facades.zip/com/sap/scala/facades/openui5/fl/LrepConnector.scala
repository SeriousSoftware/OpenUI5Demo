
package com.sap.scala.facades.openui5.fl




import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.fl.LrepConnector")
@js.native
class LrepConnector()  {
  def attachSentRequest(fCallback: js.Function1[Event[EventProps], Unit]): Unit = js.native
//  def create(oPayload: /*TODO Type: 'Object' not found.*/, sChangelist: /*TODO Type: 'String' not found.*/, bIsVariant: /*TODO Type: 'Boolean' not found.*/): /*TODO Type: 'Object' not found.*/ = js.native
//  def deleteChange(mParameters: /*TODO Type: 'String' not found.*/, bIsVariant: /*TODO Type: 'Boolean' not found.*/): /*TODO Type: 'Object' not found.*/ = js.native
//  def deleteFile(sNamespace: /*TODO Type: 'String' not found.*/, sName: /*TODO Type: 'String' not found.*/, sType: /*TODO Type: 'String' not found.*/, sLayer: /*TODO Type: 'String' not found.*/, sChangelist: /*TODO Type: 'String' not found.*/): /*TODO Type: 'Object' not found.*/ = js.native
  def detachSentRequest(fCallback: js.Function1[Event[EventProps], Unit]): Unit = js.native
//  def getFileAttributes(sNamespace: /*TODO Type: 'String' not found.*/, sName: /*TODO Type: 'String' not found.*/, sType: /*TODO Type: 'String' not found.*/, sLayer: /*TODO Type: 'String' not found.*/): /*TODO Type: 'Object' not found.*/ = js.native
//  def getStaticResource(sNamespace: /*TODO Type: 'String' not found.*/, sName: /*TODO Type: 'String' not found.*/, sType: /*TODO Type: 'String' not found.*/, bIsRuntime: /*TODO Type: 'Boolean' not found.*/): /*TODO Type: 'Object' not found.*/ = js.native
//  def listContent(sNamespace: /*TODO Type: 'String' not found.*/, sLayer: /*TODO Type: 'String' not found.*/): /*TODO Type: 'Object' not found.*/ = js.native
//  def loadChanges(oComponent: Object, mPropertyBag: /*TODO Type: 'map' not found.*/): /*TODO Type: 'Promise' not found.*/ = js.native
//  def loadSettings(): /*TODO Type: 'Promise' not found.*/ = js.native
//  def send(sUri: /*TODO Type: 'String' not found.*/, sMethod: /*TODO Type: 'String' not found.*/, oData: /*TODO Type: 'Object' not found.*/, mOptions: /*TODO Type: 'Object' not found.*/): /*TODO Type: 'Promise' not found.*/ = js.native
//  def setRequestUrlPrefix(sRequestUrlPrefix: /*TODO Type: 'String' not found.*/): Unit = js.native
//  def update(oPayload: /*TODO Type: 'Object' not found.*/, sChangeName: /*TODO Type: 'String' not found.*/, sChangelist: /*TODO Type: 'String' not found.*/, bIsVariant: /*TODO Type: 'Boolean' not found.*/): /*TODO Type: 'Object' not found.*/ = js.native
//  def upsert(sNamespace: /*TODO Type: 'String' not found.*/, sName: /*TODO Type: 'String' not found.*/, sType: /*TODO Type: 'String' not found.*/, sLayer: /*TODO Type: 'String' not found.*/, sContent: /*TODO Type: 'String' not found.*/, sContentType: /*TODO Type: 'String' not found.*/, sChangelist: /*TODO Type: 'String' not found.*/): /*TODO Type: 'Object' not found.*/ = js.native
}
     