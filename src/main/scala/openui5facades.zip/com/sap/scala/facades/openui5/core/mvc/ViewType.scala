package com.sap.scala.facades.openui5.core.mvc

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ViewType extends js.Object

object ViewType{
  @JSGlobal("sap.ui.core.mvc.ViewType.HTML")
  @js.native
  object HTML extends ViewType

  @JSGlobal("sap.ui.core.mvc.ViewType.JS")
  @js.native
  object JS extends ViewType

  @JSGlobal("sap.ui.core.mvc.ViewType.JSON")
  @js.native
  object JSON extends ViewType

  @JSGlobal("sap.ui.core.mvc.ViewType.Template")
  @js.native
  object Template extends ViewType

  @JSGlobal("sap.ui.core.mvc.ViewType.XML")
  @js.native
  object XML extends ViewType
}

/* copy to Enum.scala
sealed trait ViewType{
  private[ui] def toFacade: sap.ui.core.mvc.ViewType
}

object ViewType {
  def fromFacade(s: ui.core.mvc.ViewType): ViewType = s match {
    case ui.core.mvc.ViewType.HTML => ViewType.HTML
    case ui.core.mvc.ViewType.JS => ViewType.JS
    case ui.core.mvc.ViewType.JSON => ViewType.JSON
    case ui.core.mvc.ViewType.Template => ViewType.Template
    case ui.core.mvc.ViewType.XML => ViewType.XML
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ViewType: $s")
  }
  
  object HTML extends ViewType {
    override private[ui] def toFacade: ui.core.mvc.ViewType = ui.core.mvc.ViewType.HTML
  }

  object JS extends ViewType {
    override private[ui] def toFacade: ui.core.mvc.ViewType = ui.core.mvc.ViewType.JS
  }

  object JSON extends ViewType {
    override private[ui] def toFacade: ui.core.mvc.ViewType = ui.core.mvc.ViewType.JSON
  }

  object Template extends ViewType {
    override private[ui] def toFacade: ui.core.mvc.ViewType = ui.core.mvc.ViewType.Template
  }

  object XML extends ViewType {
    override private[ui] def toFacade: ui.core.mvc.ViewType = ui.core.mvc.ViewType.XML
  }

}
*/
