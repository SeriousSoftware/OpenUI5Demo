package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait FlexAlignItems extends js.Object

object FlexAlignItems{
  @JSGlobal("sap.m.FlexAlignItems.Baseline")
  @js.native
  object Baseline extends FlexAlignItems

  @JSGlobal("sap.m.FlexAlignItems.Center")
  @js.native
  object Center extends FlexAlignItems

  @JSGlobal("sap.m.FlexAlignItems.End")
  @js.native
  object End extends FlexAlignItems

  @JSGlobal("sap.m.FlexAlignItems.Inherit")
  @js.native
  object Inherit extends FlexAlignItems

  @JSGlobal("sap.m.FlexAlignItems.Start")
  @js.native
  object Start extends FlexAlignItems

  @JSGlobal("sap.m.FlexAlignItems.Stretch")
  @js.native
  object Stretch extends FlexAlignItems
}

/* copy to Enum.scala
sealed trait FlexAlignItems{
  private[ui] def toFacade: sap.m.FlexAlignItems
}

object FlexAlignItems {
  def fromFacade(s: m.FlexAlignItems): FlexAlignItems = s match {
    case m.FlexAlignItems.Baseline => FlexAlignItems.Baseline
    case m.FlexAlignItems.Center => FlexAlignItems.Center
    case m.FlexAlignItems.End => FlexAlignItems.End
    case m.FlexAlignItems.Inherit => FlexAlignItems.Inherit
    case m.FlexAlignItems.Start => FlexAlignItems.Start
    case m.FlexAlignItems.Stretch => FlexAlignItems.Stretch
   case _ =>
     throw new UnsupportedOperationException(s"Unknown FlexAlignItems: $s")
  }
  
  object Baseline extends FlexAlignItems {
    override private[ui] def toFacade: m.FlexAlignItems = m.FlexAlignItems.Baseline
  }

  object Center extends FlexAlignItems {
    override private[ui] def toFacade: m.FlexAlignItems = m.FlexAlignItems.Center
  }

  object End extends FlexAlignItems {
    override private[ui] def toFacade: m.FlexAlignItems = m.FlexAlignItems.End
  }

  object Inherit extends FlexAlignItems {
    override private[ui] def toFacade: m.FlexAlignItems = m.FlexAlignItems.Inherit
  }

  object Start extends FlexAlignItems {
    override private[ui] def toFacade: m.FlexAlignItems = m.FlexAlignItems.Start
  }

  object Stretch extends FlexAlignItems {
    override private[ui] def toFacade: m.FlexAlignItems = m.FlexAlignItems.Stretch
  }

}
*/
