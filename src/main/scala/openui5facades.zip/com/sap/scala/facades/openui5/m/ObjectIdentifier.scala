
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{Control,ID,TextDirection}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.ObjectIdentifier")
@js.native
class ObjectIdentifier() extends Control {
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def attachTitlePress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachTitlePress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireTitlePress(mParameters: Object): this.type = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getBadgeAttachments(): Boolean = js.native
  def getBadgeNotes(): Boolean = js.native
  def getBadgePeople(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getText(): String = js.native
  def getTextDirection(): TextDirection = js.native
  def getTitle(): String = js.native
  def getTitleActive(): Boolean = js.native
  def getVisible(): Boolean = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def setBadgeAttachments(bBadgeAttachments: Boolean): this.type = js.native
  def setBadgeNotes(bBadgeNotes: Boolean): this.type = js.native
  def setBadgePeople(bBadgePeople: Boolean): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTextDirection(sTextDirection: TextDirection): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setTitleActive(bValue: Boolean): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     