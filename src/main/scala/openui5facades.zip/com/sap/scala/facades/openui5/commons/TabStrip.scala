
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control,Icon}
import com.sap.scala.facades.openui5.commons.Tab


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.TabStrip")
@js.native
class TabStrip() extends Control {
  def addTab(oTab: Tab): this.type = js.native
  def attachClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def closeTab(iIndex: Int): Unit = js.native
  def createTab(sText: String, oContent: Control): Tab = js.native
  def destroyTabs(): this.type = js.native
  def detachClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireClose(mParameters: Object): this.type = js.native
  def fireSelect(mParameters: Object): this.type = js.native
  def getEnableTabReordering(): Boolean = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getSelectedIndex(): Int = js.native
  def getTabs(): js.Array[Tab] = js.native
  def getWidth(): CSSSize = js.native
  def indexOfTab(oTab: Tab): Int = js.native
  def insertTab(oTab: Tab, iIndex: Int): this.type = js.native
  def onBeforeRendering(): Unit = js.native
  def removeAllTabs(): js.Array[Tab] = js.native
  def removeTab(vTab: Int | String | Tab): Tab = js.native
  def setEnableTabReordering(bValue: Boolean): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setSelectedIndex(iSelectedIndex: Int): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     