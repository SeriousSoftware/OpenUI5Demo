
package com.sap.scala.facades.openui5.core.format

import com.sap.scala.facades.openui5.core.Locale


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.format.DateFormat")
@js.native
class DateFormat()  {
//  def format(vJSDate: /*TODO Type: 'Date' not found.*/ | /*TODO Type: 'Date[]' not found.*/, bUTC: Boolean): String = js.native
  def getDateInstance(oFormatOptions: Object, oLocale: Locale): this.type = js.native
  def getDateTimeInstance(oFormatOptions: Object, oLocale: Locale): this.type = js.native
  def getTimeInstance(oFormatOptions: Object, oLocale: Locale): this.type = js.native
//  def parse(sValue: String, bUTC: Boolean, bStrict: Boolean): /*TODO Type: 'Date' not found.*/ = js.native
}
     