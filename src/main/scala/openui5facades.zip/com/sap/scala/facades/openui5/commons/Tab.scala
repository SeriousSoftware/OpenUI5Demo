
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.Scrolling


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Tab")
@js.native
class Tab() extends Panel {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getClosable(): Boolean = js.native
  def getHorizontalScrolling(): Scrolling = js.native
  def getMetadata(): Metadata = js.native
  def getSelected(): Boolean = js.native
  def getVerticalScrolling(): Scrolling = js.native
  def setClosable(bClosable: Boolean): this.type = js.native
  def setHorizontalScrolling(sHorizontalScrolling: Scrolling): this.type = js.native
  def setSelected(bSelected: Boolean): this.type = js.native
  def setVerticalScrolling(sVerticalScrolling: Scrolling): this.type = js.native
}
     