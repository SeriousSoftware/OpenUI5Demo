
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.P13nPanel


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nDialog")
@js.native
class P13nDialog() extends Dialog {
  def addPanel(oPanel: P13nPanel): this.type = js.native
  def attachCancel(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachOk(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachReset(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindPanels(oBindingInfo: Object): this.type = js.native
  def destroyPanels(): this.type = js.native
  def detachCancel(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachOk(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachReset(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireCancel(mParameters: Object): this.type = js.native
  def fireOk(mParameters: Object): this.type = js.native
  def fireReset(mParameters: Object): this.type = js.native
  def getInitialVisiblePanelType(): String = js.native
  def getMetadata(): Metadata = js.native
  def getPanels(): js.Array[P13nPanel] = js.native
  def getShowReset(): Boolean = js.native
  def getShowResetEnabled(): Boolean = js.native
  def getValidationExecutor(): Object = js.native
//  def getVisiblePanel(): P13nPanel | /*TODO Type: 'null' not found.*/ = js.native
  def indexOfPanel(oPanel: P13nPanel): Int = js.native
  def insertPanel(oPanel: P13nPanel, iIndex: Int): this.type = js.native
  def removeAllPanels(): js.Array[P13nPanel] = js.native
  def removePanel(vPanel: Int | String | P13nPanel): P13nPanel = js.native
  def setInitialVisiblePanelType(sInitialVisiblePanelType: String): this.type = js.native
  def setShowReset(bShowReset: Boolean): this.type = js.native
  def setShowResetEnabled(bShowResetEnabled: Boolean): this.type = js.native
  def setValidationExecutor(oValidationExecutor: Object): this.type = js.native
  def unbindPanels(): this.type = js.native
}
     