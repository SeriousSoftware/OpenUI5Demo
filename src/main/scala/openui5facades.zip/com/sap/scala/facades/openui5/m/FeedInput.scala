
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{URI,TooltipBase}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.FeedInput")
@js.native
class FeedInput() extends Control {
  def attachPost(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPost(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePost(mParameters: Object): this.type = js.native
  def getAriaLabelForPicture(): String = js.native
  def getButtonTooltip(): TooltipBase = js.native
  def getEnabled(): Boolean = js.native
  def getIcon(): URI = js.native
  def getIconDensityAware(): Boolean = js.native
  def getMaxLength(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getPlaceholder(): String = js.native
  def getShowIcon(): Boolean = js.native
  def getValue(): String = js.native
  def setAriaLabelForPicture(sAriaLabelForPicture: String): this.type = js.native
  def setButtonTooltip(sButtonTooltip: TooltipBase): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setIconDensityAware(bIconDensityAware: Boolean): this.type = js.native
  def setMaxLength(iMaxLength: Int): this.type = js.native
  def setPlaceholder(sPlaceholder: String): this.type = js.native
  def setShowIcon(bShowIcon: Boolean): this.type = js.native
  def setValue(sValue: String): this.type = js.native
}
     