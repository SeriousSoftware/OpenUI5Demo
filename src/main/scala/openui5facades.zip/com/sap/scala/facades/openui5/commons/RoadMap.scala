
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize
import com.sap.scala.facades.openui5.commons.RoadMapStep


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.RoadMap")
@js.native
class RoadMap() extends Control {
  def addStep(oStep: RoadMapStep): this.type = js.native
  def attachStepExpanded(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachStepSelected(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroySteps(): this.type = js.native
  def detachStepExpanded(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachStepSelected(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireStepExpanded(mParameters: Object): this.type = js.native
  def fireStepSelected(mParameters: Object): this.type = js.native
  def getFirstVisibleStep(): String = js.native
  def getMetadata(): Metadata = js.native
  def getNumberOfVisibleSteps(): Int = js.native
  def getSelectedStep(): String = js.native
  def getSteps(): js.Array[RoadMapStep] = js.native
  def getWidth(): CSSSize = js.native
  def indexOfStep(oStep: RoadMapStep): Int = js.native
  def insertStep(oStep: RoadMapStep, iIndex: Int): this.type = js.native
  def removeAllSteps(): js.Array[RoadMapStep] = js.native
  def removeStep(vStep: Int | String | RoadMapStep): RoadMapStep = js.native
  def setFirstVisibleStep(sFirstVisibleStep: String): this.type = js.native
  def setNumberOfVisibleSteps(iNumberOfVisibleSteps: Int): this.type = js.native
  def setSelectedStep(sSelectedStep: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     