package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Scrolling extends js.Object

object Scrolling{
  @JSGlobal("sap.ui.core.Scrolling.Auto")
  @js.native
  object Auto extends Scrolling

  @JSGlobal("sap.ui.core.Scrolling.Hidden")
  @js.native
  object Hidden extends Scrolling

  @JSGlobal("sap.ui.core.Scrolling.None")
  @js.native
  object None extends Scrolling

  @JSGlobal("sap.ui.core.Scrolling.Scroll")
  @js.native
  object Scroll extends Scrolling
}

/* copy to Enum.scala
sealed trait Scrolling{
  private[ui] def toFacade: sap.ui.core.Scrolling
}

object Scrolling {
  def fromFacade(s: ui.core.Scrolling): Scrolling = s match {
    case ui.core.Scrolling.Auto => Scrolling.Auto
    case ui.core.Scrolling.Hidden => Scrolling.Hidden
    case ui.core.Scrolling.None => Scrolling.None
    case ui.core.Scrolling.Scroll => Scrolling.Scroll
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Scrolling: $s")
  }
  
  object Auto extends Scrolling {
    override private[ui] def toFacade: ui.core.Scrolling = ui.core.Scrolling.Auto
  }

  object Hidden extends Scrolling {
    override private[ui] def toFacade: ui.core.Scrolling = ui.core.Scrolling.Hidden
  }

  object None extends Scrolling {
    override private[ui] def toFacade: ui.core.Scrolling = ui.core.Scrolling.None
  }

  object Scroll extends Scrolling {
    override private[ui] def toFacade: ui.core.Scrolling = ui.core.Scrolling.Scroll
  }

}
*/
