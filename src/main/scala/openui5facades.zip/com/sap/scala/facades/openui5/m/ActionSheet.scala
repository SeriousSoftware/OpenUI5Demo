
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{PlacementType,Button}
import com.sap.scala.facades.openui5.core.InvisibleText


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.ActionSheet")
@js.native
class ActionSheet() extends Control {
  def addButton(oButton: Button): this.type = js.native
  def attachAfterClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachAfterOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachCancelButtonPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachCancelButtonTap(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def close(): Unit = js.native
  def destroyButtons(): this.type = js.native
  def detachAfterClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachAfterOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachCancelButtonPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachCancelButtonTap(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterClose(mParameters: Object): this.type = js.native
  def fireAfterOpen(mParameters: Object): this.type = js.native
  def fireBeforeClose(mParameters: Object): this.type = js.native
  def fireBeforeOpen(mParameters: Object): this.type = js.native
  def fireCancelButtonPress(mParameters: Object): this.type = js.native
  def fireCancelButtonTap(mParameters: Object): this.type = js.native
  def getButtons(): js.Array[Button] = js.native
  def getCancelButtonText(): String = js.native
  def getMetadata(): Metadata = js.native
  def getPlacement(): PlacementType = js.native
  def getPopupHiddenLabelId(): String = js.native
  def getShowCancelButton(): Boolean = js.native
  def getTitle(): String = js.native
  def indexOfButton(oButton: Button): Int = js.native
  def insertButton(oButton: Button, iIndex: Int): this.type = js.native
  def isOpen(): Boolean = js.native
  def openBy(oControl: Object): Unit = js.native
  def removeAllButtons(): js.Array[Button] = js.native
  def removeButton(vButton: Int | String | Button): Button = js.native
  def setCancelButtonText(sCancelButtonText: String): this.type = js.native
  def setPlacement(sPlacement: PlacementType): this.type = js.native
  def setShowCancelButton(bShowCancelButton: Boolean): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
}
     