
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,URI,Control,ID}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.BusyDialog")
@js.native
class BusyDialog() extends Control {
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def attachClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def close(): this.type = js.native
  def detachClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireClose(mParameters: Object): this.type = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getCancelButtonText(): String = js.native
  def getCustomIcon(): URI = js.native
  def getCustomIconDensityAware(): Boolean = js.native
  def getCustomIconHeight(): CSSSize = js.native
  def getCustomIconRotationSpeed(): Int = js.native
  def getCustomIconWidth(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getShowCancelButton(): Boolean = js.native
  def getText(): String = js.native
  def getTitle(): String = js.native
  def open(): this.type = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def setCancelButtonText(sCancelButtonText: String): this.type = js.native
  def setCustomIcon(sCustomIcon: URI): this.type = js.native
  def setCustomIconDensityAware(bCustomIconDensityAware: Boolean): this.type = js.native
  def setCustomIconHeight(sCustomIconHeight: CSSSize): this.type = js.native
  def setCustomIconRotationSpeed(iCustomIconRotationSpeed: Int): this.type = js.native
  def setCustomIconWidth(sCustomIconWidth: CSSSize): this.type = js.native
  def setShowCancelButton(bShowCancelButton: Boolean): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
}
     