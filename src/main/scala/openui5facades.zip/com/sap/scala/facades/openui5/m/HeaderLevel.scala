package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait HeaderLevel extends js.Object

object HeaderLevel{
  @JSGlobal("sap.m.HeaderLevel.H1")
  @js.native
  object H1 extends HeaderLevel

  @JSGlobal("sap.m.HeaderLevel.H2")
  @js.native
  object H2 extends HeaderLevel

  @JSGlobal("sap.m.HeaderLevel.H3")
  @js.native
  object H3 extends HeaderLevel

  @JSGlobal("sap.m.HeaderLevel.H4")
  @js.native
  object H4 extends HeaderLevel

  @JSGlobal("sap.m.HeaderLevel.H5")
  @js.native
  object H5 extends HeaderLevel

  @JSGlobal("sap.m.HeaderLevel.H6")
  @js.native
  object H6 extends HeaderLevel
}

/* copy to Enum.scala
sealed trait HeaderLevel{
  private[ui] def toFacade: sap.m.HeaderLevel
}

object HeaderLevel {
  def fromFacade(s: m.HeaderLevel): HeaderLevel = s match {
    case m.HeaderLevel.H1 => HeaderLevel.H1
    case m.HeaderLevel.H2 => HeaderLevel.H2
    case m.HeaderLevel.H3 => HeaderLevel.H3
    case m.HeaderLevel.H4 => HeaderLevel.H4
    case m.HeaderLevel.H5 => HeaderLevel.H5
    case m.HeaderLevel.H6 => HeaderLevel.H6
   case _ =>
     throw new UnsupportedOperationException(s"Unknown HeaderLevel: $s")
  }
  
  object H1 extends HeaderLevel {
    override private[ui] def toFacade: m.HeaderLevel = m.HeaderLevel.H1
  }

  object H2 extends HeaderLevel {
    override private[ui] def toFacade: m.HeaderLevel = m.HeaderLevel.H2
  }

  object H3 extends HeaderLevel {
    override private[ui] def toFacade: m.HeaderLevel = m.HeaderLevel.H3
  }

  object H4 extends HeaderLevel {
    override private[ui] def toFacade: m.HeaderLevel = m.HeaderLevel.H4
  }

  object H5 extends HeaderLevel {
    override private[ui] def toFacade: m.HeaderLevel = m.HeaderLevel.H5
  }

  object H6 extends HeaderLevel {
    override private[ui] def toFacade: m.HeaderLevel = m.HeaderLevel.H6
  }

}
*/
