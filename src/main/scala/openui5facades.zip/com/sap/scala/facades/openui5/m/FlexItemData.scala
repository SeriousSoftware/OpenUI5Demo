
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{FlexAlignSelf,BackgroundDesign}
import com.sap.scala.facades.openui5.core.CSSSize


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.FlexItemData")
@js.native
class FlexItemData() extends LayoutData {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAlignSelf(): FlexAlignSelf = js.native
  def getBackgroundDesign(): BackgroundDesign = js.native
  def getBaseSize(): CSSSize = js.native
  def getGrowFactor(): Float = js.native
  def getMaxHeight(): CSSSize = js.native
  def getMaxWidth(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getMinHeight(): CSSSize = js.native
  def getMinWidth(): CSSSize = js.native
  def getOrder(): Int = js.native
  def getShrinkFactor(): Float = js.native
  def getStyleClass(): String = js.native
  def setAlignSelf(sAlignSelf: FlexAlignSelf): this.type = js.native
  def setBackgroundDesign(sBackgroundDesign: BackgroundDesign): this.type = js.native
  def setBaseSize(sBaseSize: CSSSize): this.type = js.native
  def setGrowFactor(fGrowFactor: Float): this.type = js.native
  def setMaxHeight(sMaxHeight: CSSSize): this.type = js.native
  def setMaxWidth(sMaxWidth: CSSSize): this.type = js.native
  def setMinHeight(sMinHeight: CSSSize): this.type = js.native
  def setMinWidth(sMinWidth: CSSSize): this.type = js.native
  def setOrder(iOrder: Int): this.type = js.native
  def setShrinkFactor(fShrinkFactor: Float): this.type = js.native
  def setStyleClass(sStyleClass: String): this.type = js.native
}
     