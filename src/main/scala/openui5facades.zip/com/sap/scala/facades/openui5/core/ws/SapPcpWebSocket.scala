
package com.sap.scala.facades.openui5.core.ws

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.ws.SapPcpWebSocket")
@js.native
class SapPcpWebSocket() extends WebSocket {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireMessage(mArguments: Object): this.type = js.native
  def getMetadata(): Metadata = js.native
//  def send(message: String | /*TODO Type: 'Blob' not found.*/ | /*TODO Type: 'ArrayBuffer' not found.*/, oPcpFields: Object): this.type = js.native
}
     