
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{IconTabFilterDesign,IconTabBarSelectList}
import com.sap.scala.facades.openui5.core.{URI,IconColor,Control,RenderManager}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.IconTabFilter")
@js.native
class IconTabFilter() extends Item {
  def addContent(oContent: Control): this.type = js.native
  def destroyContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getContent(): js.Array[Control] = js.native
  def getCount(): String = js.native
  def getDesign(): IconTabFilterDesign = js.native
  def getIcon(): URI = js.native
  def getIconColor(): IconColor = js.native
  def getIconDensityAware(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getShowAll(): Boolean = js.native
  def getVisible(): Boolean = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def render(rm: RenderManager): Unit = js.native
  def renderInSelectList(rm: RenderManager, selectList: IconTabBarSelectList): Unit = js.native
  def setCount(sCount: String): this.type = js.native
  def setDesign(sDesign: IconTabFilterDesign): this.type = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setIconColor(sIconColor: IconColor): this.type = js.native
  def setIconDensityAware(bIconDensityAware: Boolean): this.type = js.native
  def setShowAll(bShowAll: Boolean): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     