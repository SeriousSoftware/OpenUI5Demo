
package com.sap.scala.facades.openui5.base

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.base.ObjectPool")
@js.native
class ObjectPool() extends Object {
//  def borrowObject(any: /*TODO Type: 'any' not found.*/): Object = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def returnObject(oObject: Object): Unit = js.native
}
     