
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.ScrollBar")
@js.native
class ScrollBar() extends Control {
  def attachScroll(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bind(oOwnerDomRef: String): Unit = js.native
  def detachScroll(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireScroll(mParameters: Object): this.type = js.native
  def getContentSize(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getScrollPosition(): Int = js.native
  def getSize(): CSSSize = js.native
  def getSteps(): Int = js.native
  def getVertical(): Boolean = js.native
  def pageDown(): Unit = js.native
  def pageUp(): Unit = js.native
  def setContentSize(sContentSize: CSSSize): this.type = js.native
  def setScrollPosition(iScrollPosition: Int): this.type = js.native
  def setSize(sSize: CSSSize): this.type = js.native
  def setSteps(iSteps: Int): this.type = js.native
  def setVertical(bVertical: Boolean): this.type = js.native
  def unbind(oOwnerDomRef: String): Unit = js.native
}
     