
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.ActionListItem")
@js.native
class ActionListItem() extends ListItemBase {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getMode(): Unit = js.native
  def getText(): String = js.native
  def setText(sText: String): this.type = js.native
}
     