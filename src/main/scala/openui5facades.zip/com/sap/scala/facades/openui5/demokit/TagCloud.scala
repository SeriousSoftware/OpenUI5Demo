
package com.sap.scala.facades.openui5.demokit

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.demokit.Tag


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.demokit.TagCloud")
@js.native
class TagCloud() extends Control {
  def addTag(oTag: Tag): this.type = js.native
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyTags(): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePress(mParameters: Object): this.type = js.native
  def getMaxFontSize(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getMinFontSize(): Int = js.native
  def getTags(): js.Array[Tag] = js.native
  def indexOfTag(oTag: Tag): Int = js.native
  def insertTag(oTag: Tag, iIndex: Int): this.type = js.native
  def removeAllTags(): js.Array[Tag] = js.native
  def removeTag(vTag: Int | String | Tag): Tag = js.native
  def setMaxFontSize(iMaxFontSize: Int): this.type = js.native
  def setMinFontSize(iMinFontSize: Int): this.type = js.native
}
     