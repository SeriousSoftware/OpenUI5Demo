
package com.sap.scala.facades.openui5.commons.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control}
import com.sap.scala.facades.openui5.commons.layout.{BorderLayoutArea,BorderLayoutAreaTypes}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.layout.BorderLayout")
@js.native
class BorderLayout() extends Control {
  def addContent(oAreaId: BorderLayoutAreaTypes, oControls: Control): Unit = js.native
  def createArea(oAreaId: BorderLayoutAreaTypes, oControls: Control): BorderLayoutArea = js.native
  def destroyBegin(): this.type = js.native
  def destroyBottom(): this.type = js.native
  def destroyCenter(): this.type = js.native
  def destroyContent(oAreaId: BorderLayoutAreaTypes): Unit = js.native
  def destroyEnd(): this.type = js.native
  def destroyTop(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getArea(oAreaId: BorderLayoutAreaTypes, bCreate: Boolean): BorderLayoutAreaTypes = js.native
  def getAreaById(oAreaId: BorderLayoutAreaTypes): BorderLayoutArea = js.native
  def getAreaData(oAreaId: BorderLayoutAreaTypes): Object = js.native
  def getBegin(): BorderLayoutArea = js.native
  def getBottom(): BorderLayoutArea = js.native
  def getCenter(): BorderLayoutArea = js.native
  def getContent(oAreaId: BorderLayoutAreaTypes): js.Array[Control] = js.native
  def getEnd(): BorderLayoutArea = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getRtl(): Boolean = js.native
  def getTop(): BorderLayoutArea = js.native
  def getWidth(): CSSSize = js.native
  def indexOfContent(oAreaId: BorderLayoutAreaTypes, oContent: Control): Int = js.native
  def insertContent(oAreaId: BorderLayoutAreaTypes, iIndex: Int, oControl: Control): Unit = js.native
  def removeAllContent(oAreaId: BorderLayoutAreaTypes): Unit = js.native
  def removeContent(oAreaId: BorderLayoutAreaTypes, iIndex: Int): Unit = js.native
  def setAreaData(oAreaId: BorderLayoutAreaTypes, oData: Object): Unit = js.native
  def setBegin(oBegin: BorderLayoutArea): this.type = js.native
  def setBottom(oBottom: BorderLayoutArea): this.type = js.native
  def setCenter(oCenter: BorderLayoutArea): this.type = js.native
  def setEnd(oEnd: BorderLayoutArea): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setRtl(bRtl: Boolean): this.type = js.native
  def setTop(oTop: BorderLayoutArea): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     