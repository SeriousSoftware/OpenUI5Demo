
package com.sap.scala.facades.openui5.demokit

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.demokit.CodeViewer")
@js.native
class CodeViewer() extends Control {
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSave(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSave(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePress(mParameters: Object): this.type = js.native
  def fireSave(mParameters: Object): this.type = js.native
  def getEditable(): Boolean = js.native
  def getHeight(): CSSSize = js.native
  def getLineNumbering(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getSource(): String = js.native
  def getVisible(): Boolean = js.native
  def getWidth(): CSSSize = js.native
  def setEditable(bEditable: Boolean): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setLineNumbering(bLineNumbering: Boolean): this.type = js.native
  def setSource(sSource: String): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     