
package com.sap.scala.facades.openui5.core.routing

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.routing.Router


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.routing.Route")
@js.native
class Route() extends EventProvider {
  def attachBeforeMatched(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachMatched(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachPatternMatched(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroy(): this.type = js.native
  def detachBeforeMatched(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachMatched(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPatternMatched(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireBeforeMatched(mArguments: Object): Router = js.native
  def getMetadata(): Metadata = js.native
  def getPattern(): String = js.native
  def getURL(oParameters: Object): String = js.native
}
     