
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.P13nGroupItem
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nGroupPanel")
@js.native
class P13nGroupPanel() extends P13nPanel {
  def addGroupItem(oGroupItem: P13nGroupItem): this.type = js.native
  def attachAddGroupItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachRemoveGroupItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachUpdateGroupItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindGroupItems(oBindingInfo: Object): this.type = js.native
  def destroyGroupItems(): this.type = js.native
  def detachAddGroupItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachRemoveGroupItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachUpdateGroupItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAddGroupItem(mParameters: Object): this.type = js.native
  def fireRemoveGroupItem(mParameters: Object): this.type = js.native
  def fireUpdateGroupItem(mParameters: Object): this.type = js.native
  def getContainerQuery(): Boolean = js.native
  def getGroupItems(): js.Array[P13nGroupItem] = js.native
  def getLayoutMode(): String = js.native
  def getMaxGroups(): String = js.native
  def getMetadata(): Metadata = js.native
  def indexOfGroupItem(oGroupItem: P13nGroupItem): Int = js.native
  def insertGroupItem(oGroupItem: P13nGroupItem, iIndex: Int): this.type = js.native
  def removeAllGroupItems(): js.Array[P13nGroupItem] = js.native
  def removeGroupItem(vGroupItem: Int | String | P13nGroupItem): P13nGroupItem = js.native
  def removeInvalidConditions(): Unit = js.native
  def removeValidationErrors(): Unit = js.native
  def setContainerQuery(bContainerQuery: Boolean): this.type = js.native
  def setLayoutMode(sLayoutMode: String): this.type = js.native
  def setMaxGroups(sMaxGroups: String): this.type = js.native
//  def setOperations(aOperations: /*TODO Type: 'array' not found.*/): Unit = js.native
  def unbindGroupItems(): this.type = js.native
  def validateConditions(): Boolean = js.native
}
     