package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait FacetFilterListDataType extends js.Object

object FacetFilterListDataType{
  @JSGlobal("sap.m.FacetFilterListDataType.Boolean")
  @js.native
  object Boolean extends FacetFilterListDataType

  @JSGlobal("sap.m.FacetFilterListDataType.Date")
  @js.native
  object Date extends FacetFilterListDataType

  @JSGlobal("sap.m.FacetFilterListDataType.DateTime")
  @js.native
  object DateTime extends FacetFilterListDataType

  @JSGlobal("sap.m.FacetFilterListDataType.Float")
  @js.native
  object Float extends FacetFilterListDataType

  @JSGlobal("sap.m.FacetFilterListDataType.Integer")
  @js.native
  object Integer extends FacetFilterListDataType

  @JSGlobal("sap.m.FacetFilterListDataType.String")
  @js.native
  object String extends FacetFilterListDataType

  @JSGlobal("sap.m.FacetFilterListDataType.Time")
  @js.native
  object Time extends FacetFilterListDataType
}

/* copy to Enum.scala
sealed trait FacetFilterListDataType{
  private[ui] def toFacade: sap.m.FacetFilterListDataType
}

object FacetFilterListDataType {
  def fromFacade(s: m.FacetFilterListDataType): FacetFilterListDataType = s match {
    case m.FacetFilterListDataType.Boolean => FacetFilterListDataType.Boolean
    case m.FacetFilterListDataType.Date => FacetFilterListDataType.Date
    case m.FacetFilterListDataType.DateTime => FacetFilterListDataType.DateTime
    case m.FacetFilterListDataType.Float => FacetFilterListDataType.Float
    case m.FacetFilterListDataType.Integer => FacetFilterListDataType.Integer
    case m.FacetFilterListDataType.String => FacetFilterListDataType.String
    case m.FacetFilterListDataType.Time => FacetFilterListDataType.Time
   case _ =>
     throw new UnsupportedOperationException(s"Unknown FacetFilterListDataType: $s")
  }
  
  object Boolean extends FacetFilterListDataType {
    override private[ui] def toFacade: m.FacetFilterListDataType = m.FacetFilterListDataType.Boolean
  }

  object Date extends FacetFilterListDataType {
    override private[ui] def toFacade: m.FacetFilterListDataType = m.FacetFilterListDataType.Date
  }

  object DateTime extends FacetFilterListDataType {
    override private[ui] def toFacade: m.FacetFilterListDataType = m.FacetFilterListDataType.DateTime
  }

  object Float extends FacetFilterListDataType {
    override private[ui] def toFacade: m.FacetFilterListDataType = m.FacetFilterListDataType.Float
  }

  object Integer extends FacetFilterListDataType {
    override private[ui] def toFacade: m.FacetFilterListDataType = m.FacetFilterListDataType.Integer
  }

  object String extends FacetFilterListDataType {
    override private[ui] def toFacade: m.FacetFilterListDataType = m.FacetFilterListDataType.String
  }

  object Time extends FacetFilterListDataType {
    override private[ui] def toFacade: m.FacetFilterListDataType = m.FacetFilterListDataType.Time
  }

}
*/
