package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait OpenState extends js.Object

object OpenState{
  @JSGlobal("sap.ui.core.OpenState.CLOSED")
  @js.native
  object CLOSED extends OpenState

  @JSGlobal("sap.ui.core.OpenState.CLOSING")
  @js.native
  object CLOSING extends OpenState

  @JSGlobal("sap.ui.core.OpenState.OPEN")
  @js.native
  object OPEN extends OpenState

  @JSGlobal("sap.ui.core.OpenState.OPENING")
  @js.native
  object OPENING extends OpenState
}

/* copy to Enum.scala
sealed trait OpenState{
  private[ui] def toFacade: sap.ui.core.OpenState
}

object OpenState {
  def fromFacade(s: ui.core.OpenState): OpenState = s match {
    case ui.core.OpenState.CLOSED => OpenState.CLOSED
    case ui.core.OpenState.CLOSING => OpenState.CLOSING
    case ui.core.OpenState.OPEN => OpenState.OPEN
    case ui.core.OpenState.OPENING => OpenState.OPENING
   case _ =>
     throw new UnsupportedOperationException(s"Unknown OpenState: $s")
  }
  
  object CLOSED extends OpenState {
    override private[ui] def toFacade: ui.core.OpenState = ui.core.OpenState.CLOSED
  }

  object CLOSING extends OpenState {
    override private[ui] def toFacade: ui.core.OpenState = ui.core.OpenState.CLOSING
  }

  object OPEN extends OpenState {
    override private[ui] def toFacade: ui.core.OpenState = ui.core.OpenState.OPEN
  }

  object OPENING extends OpenState {
    override private[ui] def toFacade: ui.core.OpenState = ui.core.OpenState.OPENING
  }

}
*/
