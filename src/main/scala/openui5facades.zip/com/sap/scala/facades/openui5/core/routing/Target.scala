
package com.sap.scala.facades.openui5.core.routing

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.routing.Target")
@js.native
class Target() extends EventProvider {
  def _beforePlacingViewIntoContainer(mArguments: Object): Unit = js.native
  def attachDisplay(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroy(): this.type = js.native
  def detachDisplay(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
//  def display(vData: /*TODO Type: '*' not found.*/): /*TODO Type: 'Promise' not found.*/ = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireDisplay(mArguments: Object): this.type = js.native
  def getMetadata(): Metadata = js.native
}
     