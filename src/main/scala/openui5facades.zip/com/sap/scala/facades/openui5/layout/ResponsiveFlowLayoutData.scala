
package com.sap.scala.facades.openui5.layout

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.layout.ResponsiveFlowLayoutData")
@js.native
class ResponsiveFlowLayoutData() extends LayoutData {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getLinebreak(): Boolean = js.native
  def getLinebreakable(): Boolean = js.native
  def getMargin(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getMinWidth(): Int = js.native
  def getWeight(): Int = js.native
  def setLinebreak(bLinebreak: Boolean): this.type = js.native
  def setLinebreakable(bLinebreakable: Boolean): this.type = js.native
  def setMargin(bMargin: Boolean): this.type = js.native
  def setMinWidth(iMinWidth: Int): this.type = js.native
  def setWeight(iWeight: Int): this.type = js.native
}
     