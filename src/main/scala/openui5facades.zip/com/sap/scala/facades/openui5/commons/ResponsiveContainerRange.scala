
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control,ID}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.ResponsiveContainerRange")
@js.native
class ResponsiveContainerRange() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getContent(): ID = js.native
  def getHeight(): CSSSize = js.native
  def getKey(): String = js.native
  def getMetadata(): Metadata = js.native
  def getWidth(): CSSSize = js.native
  def setContent(oContent: ID | Control): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setKey(sKey: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     