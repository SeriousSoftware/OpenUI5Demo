
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{ListItem,ID}
import com.sap.scala.facades.openui5.commons.ListBox


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.ComboBox")
@js.native
class ComboBox() extends TextField {
//  def _checkChange(oEvent: /*TODO Type: 'jQuery.Event' not found.*/, bImmediate: Boolean): Unit = js.native
  def addItem(oItem: ListItem): this.type = js.native
  def bindItems(oBindingInfo: Object): this.type = js.native
  def destroyItems(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
//  def fireChange(mArguments: /*TODO Type: 'Map' not found.*/): this.type = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getDisplaySecondaryValues(): Boolean = js.native
//  def getF4ButtonDomRef(): /*TODO Type: 'Element' not found.*/ = js.native
  def getItems(): js.Array[ListItem] = js.native
  def getListBox(): ID = js.native
  def getMaxPopupItems(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getSelectedItemId(): String = js.native
  def getSelectedKey(): String = js.native
  def indexOfItem(oItem: ListItem): Int = js.native
  def insertItem(oItem: ListItem, iIndex: Int): this.type = js.native
//  def onsapenter(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsapescape(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsaphide(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsapnextmodifiers(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onsapshow(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
  def removeAllItems(): js.Array[ListItem] = js.native
  def removeItem(vItem: Int | String | ListItem): ListItem = js.native
  def setDisplaySecondaryValues(bDisplaySecondaryValues: Boolean): this.type = js.native
  def setListBox(oListBox: ID | ListBox): this.type = js.native
  def setMaxPopupItems(iMaxPopupItems: Int): this.type = js.native
  def setSelectedItemId(sSelectedItemId: String): this.type = js.native
  def setSelectedKey(sSelectedKey: String): this.type = js.native
  def unbindItems(): this.type = js.native
}
     