
package com.sap.scala.facades.openui5.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,ID}
import com.sap.scala.facades.openui5.layout.{SplitPane,PaneContainer,ResponsiveSplitterPage}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.layout.ResponsiveSplitter")
@js.native
class ResponsiveSplitter() extends Control {
  def destroyRootPaneContainer(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getDefaultPane(): ID = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getRootPaneContainer(): PaneContainer = js.native
  def getWidth(): CSSSize = js.native
  def setDefaultPane(oDefaultPane: ID | SplitPane): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setRootPaneContainer(oRootPaneContainer: PaneContainer): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     