
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.QuickViewGroupElementType


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.QuickViewGroupElement")
@js.native
class QuickViewGroupElement() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getEmailSubject(): String = js.native
  def getLabel(): String = js.native
  def getMetadata(): Metadata = js.native
  def getPageLinkId(): String = js.native
  def getTarget(): String = js.native
  def getType(): QuickViewGroupElementType = js.native
  def getUrl(): String = js.native
  def getValue(): String = js.native
  def getVisible(): Boolean = js.native
  def setEmailSubject(sEmailSubject: String): this.type = js.native
  def setLabel(sLabel: String): this.type = js.native
  def setPageLinkId(sPageLinkId: String): this.type = js.native
  def setTarget(sTarget: String): this.type = js.native
  def setType(sType: QuickViewGroupElementType): this.type = js.native
  def setUrl(sUrl: String): this.type = js.native
  def setValue(sValue: String): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     