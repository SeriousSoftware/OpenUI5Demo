
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.LocalBusyIndicator")
@js.native
class LocalBusyIndicator() extends Control {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getWidth(): CSSSize = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     