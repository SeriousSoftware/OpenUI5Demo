
package com.sap.scala.facades.openui5.commons.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control,Scrolling}
import com.sap.scala.facades.openui5.commons.layout.PositionContainer


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.layout.AbsoluteLayout")
@js.native
class AbsoluteLayout() extends Control {
  def addContent(oContent: Control, oPos: Object): this.type = js.native
  def addPosition(oPosition: PositionContainer): this.type = js.native
  def destroyContent(): this.type = js.native
  def destroyPositions(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getContent(): js.Array[Control] = js.native
  def getHeight(): CSSSize = js.native
  def getHorizontalScrolling(): Scrolling = js.native
  def getMetadata(): Metadata = js.native
  def getPositions(): js.Array[PositionContainer] = js.native
  def getVerticalScrolling(): Scrolling = js.native
  def getWidth(): CSSSize = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def indexOfPosition(oPosition: PositionContainer): Int = js.native
  def insertContent(oContent: Control, iIndex: Int, oPos: Object): this.type = js.native
  def insertPosition(oPosition: PositionContainer, iIndex: Int): this.type = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeAllPositions(): js.Array[PositionContainer] = js.native
  def removeContent(oContent: Object): Control = js.native
  def removePosition(vPosition: Int | String | PositionContainer): PositionContainer = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setHorizontalScrolling(sHorizontalScrolling: Scrolling): this.type = js.native
  def setPositionOfChild(oControl: Control, oPos: Object): Boolean = js.native
  def setVerticalScrolling(sVerticalScrolling: Scrolling): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     