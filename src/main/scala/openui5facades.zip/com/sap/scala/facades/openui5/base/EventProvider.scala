
package com.sap.scala.facades.openui5.base

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.base.EventProvider")
@js.native
class EventProvider() extends Object {
  def attachEvent(sEventId: String, oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachEventOnce(sEventId: String, oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroy(): Unit = js.native
  def detachEvent(sEventId: String, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireEvent(sEventId: String, mParameters: Object, bAllowPreventDefault: Boolean, bEnableEventBubbling: Boolean): this.type | Boolean = js.native
  def getEventingParent(): this.type = js.native
  def getMetadata(): Metadata = js.native
  def hasListeners(sEventId: String): Boolean = js.native
  def toString(): String = js.native
}
     