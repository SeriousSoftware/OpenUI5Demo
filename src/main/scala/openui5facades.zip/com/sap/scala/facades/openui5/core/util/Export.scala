
package com.sap.scala.facades.openui5.core.util

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.util.{ExportRow,ExportType,ExportColumn}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.util.Export")
@js.native
class Export() extends Control {
  def addColumn(oColumn: ExportColumn): this.type = js.native
  def addRow(oRow: ExportRow): this.type = js.native
  def bindColumns(oBindingInfo: Object): this.type = js.native
  def bindRows(oBindingInfo: Object): this.type = js.native
  def destroyColumns(): this.type = js.native
  def destroyExportType(): this.type = js.native
  def destroyRows(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
//  def generate(): /*TODO Type: 'Promise' not found.*/ = js.native
  def getColumns(): js.Array[ExportColumn] = js.native
  def getExportType(): ExportType = js.native
  def getMetadata(): Metadata = js.native
  def getRows(): js.Array[ExportRow] = js.native
  def indexOfColumn(oColumn: ExportColumn): Int = js.native
  def indexOfRow(oRow: ExportRow): Int = js.native
  def insertColumn(oColumn: ExportColumn, iIndex: Int): this.type = js.native
  def insertRow(oRow: ExportRow, iIndex: Int): this.type = js.native
  def removeAllColumns(): js.Array[ExportColumn] = js.native
  def removeAllRows(): js.Array[ExportRow] = js.native
  def removeColumn(vColumn: Int | String | ExportColumn): ExportColumn = js.native
  def removeRow(vRow: Int | String | ExportRow): ExportRow = js.native
//  def saveFile(sFileName: String): /*TODO Type: 'Promise' not found.*/ = js.native
  def setExportType(oExportType: ExportType): this.type = js.native
  def unbindColumns(): this.type = js.native
  def unbindRows(): this.type = js.native
}
     