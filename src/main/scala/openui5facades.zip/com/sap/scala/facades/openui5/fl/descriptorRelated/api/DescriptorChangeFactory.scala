
package com.sap.scala.facades.openui5.fl.descriptorRelated.api




import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.fl.descriptorRelated.api.DescriptorChangeFactory")
@js.native
class DescriptorChangeFactory()  {
//  def createNew(sReference: String, oInlineChange: Object, sLayer: String): /*TODO Type: 'Promise' not found.*/ = js.native
}
     