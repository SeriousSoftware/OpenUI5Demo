
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.{Metadata,Interface,EventProvider}
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.UIArea")
@js.native
class UIArea() extends ManagedObject {
  def addContent(oContent: Control): this.type = js.native
  def addDependent(oDependent: Control): this.type = js.native
  def destroyContent(): this.type = js.native
  def destroyDependents(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
//  def getBindingContext(): /*TODO Type: 'null' not found.*/ = js.native
  def getContent(): js.Array[Control] = js.native
  def getDependents(): js.Array[Control] = js.native
  def getEventingParent(): EventProvider = js.native
//  def getId(): String | /*TODO Type: 'null' not found.*/ = js.native
  def getMetadata(): Metadata = js.native
  def getRootControl(idx: Int): Control = js.native
//  def getRootNode(): /*TODO Type: 'Element' not found.*/ = js.native
  def getUIArea(): this.type = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def indexOfDependent(oDependent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def insertDependent(oDependent: Control, iIndex: Int): this.type = js.native
  def invalidate(): Unit = js.native
  def isActive(): Boolean = js.native
  def isInvalidateSuppressed(): Unit = js.native
  def isLocked(): Boolean = js.native
  def lock(): Unit = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeAllDependents(): js.Array[Control] = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def removeDependent(vDependent: Int | String | Control): Control = js.native
  def setRootControl(oRootControl: Interface | Control): Unit = js.native
  def setRootNode(oRootNode: Object): Unit = js.native
  def unlock(): Unit = js.native
}
     