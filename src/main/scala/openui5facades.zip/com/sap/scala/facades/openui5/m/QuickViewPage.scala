
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.QuickViewGroup


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.QuickViewPage")
@js.native
class QuickViewPage() extends Control {
  def addGroup(oGroup: QuickViewGroup): this.type = js.native
  def bindGroups(oBindingInfo: Object): this.type = js.native
  def destroyGroups(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getCrossAppNavCallback(): Object = js.native
  def getDescription(): String = js.native
  def getGroups(): js.Array[QuickViewGroup] = js.native
  def getHeader(): String = js.native
  def getIcon(): String = js.native
  def getMetadata(): Metadata = js.native
  def getPageId(): String = js.native
  def getTitle(): String = js.native
  def getTitleUrl(): String = js.native
  def indexOfGroup(oGroup: QuickViewGroup): Int = js.native
  def insertGroup(oGroup: QuickViewGroup, iIndex: Int): this.type = js.native
  def removeAllGroups(): js.Array[QuickViewGroup] = js.native
  def removeGroup(vGroup: Int | String | QuickViewGroup): QuickViewGroup = js.native
  def setCrossAppNavCallback(oCrossAppNavCallback: Object): this.type = js.native
  def setDescription(sDescription: String): this.type = js.native
  def setHeader(sHeader: String): this.type = js.native
  def setIcon(sIcon: String): this.type = js.native
  def setPageId(sPageId: String): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setTitleUrl(sTitleUrl: String): this.type = js.native
  def unbindGroups(): this.type = js.native
}
     