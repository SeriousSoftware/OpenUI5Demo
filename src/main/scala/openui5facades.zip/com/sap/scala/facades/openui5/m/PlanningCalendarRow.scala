
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.URI
import com.sap.scala.facades.openui5.unified.{CalendarAppointment,DateRange}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.PlanningCalendarRow")
@js.native
class PlanningCalendarRow() extends Element {
  def addAppointment(oAppointment: CalendarAppointment): this.type = js.native
  def addIntervalHeader(oIntervalHeader: CalendarAppointment): this.type = js.native
  def destroyAppointments(): this.type = js.native
  def destroyIntervalHeaders(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAppointments(): js.Array[CalendarAppointment] = js.native
  def getIcon(): URI = js.native
  def getIntervalHeaders(): js.Array[CalendarAppointment] = js.native
  def getKey(): String = js.native
  def getMetadata(): Metadata = js.native
//  def getNonWorkingDays(): /*TODO Type: 'int[]' not found.*/ = js.native
//  def getNonWorkingHours(): /*TODO Type: 'int[]' not found.*/ = js.native
  def getSelected(): Boolean = js.native
  def getText(): String = js.native
  def getTitle(): String = js.native
  def indexOfAppointment(oAppointment: CalendarAppointment): Int = js.native
  def indexOfIntervalHeader(oIntervalHeader: CalendarAppointment): Int = js.native
  def insertAppointment(oAppointment: CalendarAppointment, iIndex: Int): this.type = js.native
  def insertIntervalHeader(oIntervalHeader: CalendarAppointment, iIndex: Int): this.type = js.native
  def removeAllAppointments(): js.Array[CalendarAppointment] = js.native
  def removeAllIntervalHeaders(): js.Array[CalendarAppointment] = js.native
  def removeAppointment(vAppointment: Int | String | CalendarAppointment): CalendarAppointment = js.native
  def removeIntervalHeader(vIntervalHeader: Int | String | CalendarAppointment): CalendarAppointment = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setKey(sKey: String): this.type = js.native
//  def setNonWorkingDays(sNonWorkingDays: /*TODO Type: 'int[]' not found.*/): this.type = js.native
//  def setNonWorkingHours(sNonWorkingHours: /*TODO Type: 'int[]' not found.*/): this.type = js.native
  def setSelected(bSelected: Boolean): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
}
     