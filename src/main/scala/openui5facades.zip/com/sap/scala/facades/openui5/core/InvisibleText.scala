
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.InvisibleText")
@js.native
class InvisibleText() extends Control {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getText(): String = js.native
  def setBusy(): this.type = js.native
  def setBusyIndicatorDelay(): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTooltip(): this.type = js.native
  def setVisible(): this.type = js.native
  def toStatic(): this.type = js.native
}
     