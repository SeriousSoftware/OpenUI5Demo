
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.Manifest")
@js.native
class Manifest() extends Object {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getComponentName(): String = js.native
//  def getEntry(sKey: String): /*TODO Type: 'any' not found.*/ | /*TODO Type: 'null' not found.*/ = js.native
//  def getJson(): /*TODO Type: 'Object' not found.*/ = js.native
  def getMetadata(): Metadata = js.native
//  def getRawJson(): /*TODO Type: 'Object' not found.*/ = js.native
//  def load(mOptions: Object): this.type | /*TODO Type: 'Promise' not found.*/ = js.native
}
     