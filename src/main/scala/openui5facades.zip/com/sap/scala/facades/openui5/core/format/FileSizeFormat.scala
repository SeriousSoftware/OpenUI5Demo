
package com.sap.scala.facades.openui5.core.format

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.Locale


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.format.FileSizeFormat")
@js.native
class FileSizeFormat() extends Object {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
//  def format(oValue: /*TODO Type: 'number' not found.*/ | String): String = js.native
  def getInstance(oFormatOptions: Object, oLocale: Locale): this.type = js.native
  def getMetadata(): Metadata = js.native
//  def parse(sValue: String): /*TODO Type: 'number' not found.*/ = js.native
}
     