
package com.sap.scala.facades.openui5.f

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.IBar
import com.sap.scala.facades.openui5.core.{Control,ScrollBar}
import com.sap.scala.facades.openui5.f.{DynamicPageHeader,DynamicPageTitle}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.f.DynamicPage")
@js.native
class DynamicPage() extends Control {
  def destroyContent(): this.type = js.native
  def destroyFooter(): this.type = js.native
  def destroyHeader(): this.type = js.native
  def destroyTitle(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getContent(): Control = js.native
  def getFitContent(): Boolean = js.native
  def getFooter(): IBar = js.native
  def getHeader(): DynamicPageHeader = js.native
  def getHeaderExpanded(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getPreserveHeaderStateOnScroll(): Boolean = js.native
  def getShowFooter(): Boolean = js.native
  def getTitle(): DynamicPageTitle = js.native
  def getToggleHeaderOnTitleClick(): Boolean = js.native
  def setContent(oContent: Control): this.type = js.native
  def setFitContent(bFitContent: Boolean): this.type = js.native
  def setFooter(oFooter: IBar): this.type = js.native
  def setHeader(oHeader: DynamicPageHeader): this.type = js.native
  def setHeaderExpanded(bHeaderExpanded: Boolean): this.type = js.native
  def setPreserveHeaderStateOnScroll(bPreserveHeaderStateOnScroll: Boolean): this.type = js.native
  def setShowFooter(bShowFooter: Boolean): this.type = js.native
  def setTitle(oTitle: DynamicPageTitle): this.type = js.native
  def setToggleHeaderOnTitleClick(bToggleHeaderOnTitleClick: Boolean): this.type = js.native
}
     