
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{LightBoxItem,Text,Button,BusyIndicator}
import com.sap.scala.facades.openui5.core.{InvisibleText,Icon}
import com.sap.scala.facades.openui5.layout.VerticalLayout


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.LightBox")
@js.native
class LightBox()  {
  def addImageContent(oImageContent: LightBoxItem): this.type = js.native
  def bindImageContent(oBindingInfo: Object): this.type = js.native
  def close(): this.type = js.native
  def destroyImageContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getImageContent(): js.Array[LightBoxItem] = js.native
  def getMetadata(): Metadata = js.native
  def indexOfImageContent(oImageContent: LightBoxItem): Int = js.native
  def insertImageContent(oImageContent: LightBoxItem, iIndex: Int): this.type = js.native
  def open(): this.type = js.native
  def removeAllImageContent(): js.Array[LightBoxItem] = js.native
  def removeImageContent(vImageContent: Int | String | LightBoxItem): LightBoxItem = js.native
  def unbindImageContent(): this.type = js.native
}
     