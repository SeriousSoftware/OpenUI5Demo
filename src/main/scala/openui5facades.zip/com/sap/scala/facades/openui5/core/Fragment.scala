
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.Fragment")
@js.native
class Fragment() extends ManagedObject {
  def byId(sFragmentId: String, sId: String): Unit = js.native
  def createId(sFragmentId: String, sId: String): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getType(): String = js.native
  def registerType(sType: String, oFragmentImpl: Object): Unit = js.native
  def setType(sType: String): this.type = js.native
}
     