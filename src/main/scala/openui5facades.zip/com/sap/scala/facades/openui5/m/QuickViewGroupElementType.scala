package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait QuickViewGroupElementType extends js.Object

object QuickViewGroupElementType{
  @JSGlobal("sap.m.QuickViewGroupElementType.email")
  @js.native
  object email extends QuickViewGroupElementType

  @JSGlobal("sap.m.QuickViewGroupElementType.link")
  @js.native
  object link extends QuickViewGroupElementType

  @JSGlobal("sap.m.QuickViewGroupElementType.mobile")
  @js.native
  object mobile extends QuickViewGroupElementType

  @JSGlobal("sap.m.QuickViewGroupElementType.pageLink")
  @js.native
  object pageLink extends QuickViewGroupElementType

  @JSGlobal("sap.m.QuickViewGroupElementType.phone")
  @js.native
  object phone extends QuickViewGroupElementType

  @JSGlobal("sap.m.QuickViewGroupElementType.text")
  @js.native
  object text extends QuickViewGroupElementType
}

/* copy to Enum.scala
sealed trait QuickViewGroupElementType{
  private[ui] def toFacade: sap.m.QuickViewGroupElementType
}

object QuickViewGroupElementType {
  def fromFacade(s: m.QuickViewGroupElementType): QuickViewGroupElementType = s match {
    case m.QuickViewGroupElementType.email => QuickViewGroupElementType.email
    case m.QuickViewGroupElementType.link => QuickViewGroupElementType.link
    case m.QuickViewGroupElementType.mobile => QuickViewGroupElementType.mobile
    case m.QuickViewGroupElementType.pageLink => QuickViewGroupElementType.pageLink
    case m.QuickViewGroupElementType.phone => QuickViewGroupElementType.phone
    case m.QuickViewGroupElementType.text => QuickViewGroupElementType.text
   case _ =>
     throw new UnsupportedOperationException(s"Unknown QuickViewGroupElementType: $s")
  }
  
  object email extends QuickViewGroupElementType {
    override private[ui] def toFacade: m.QuickViewGroupElementType = m.QuickViewGroupElementType.email
  }

  object link extends QuickViewGroupElementType {
    override private[ui] def toFacade: m.QuickViewGroupElementType = m.QuickViewGroupElementType.link
  }

  object mobile extends QuickViewGroupElementType {
    override private[ui] def toFacade: m.QuickViewGroupElementType = m.QuickViewGroupElementType.mobile
  }

  object pageLink extends QuickViewGroupElementType {
    override private[ui] def toFacade: m.QuickViewGroupElementType = m.QuickViewGroupElementType.pageLink
  }

  object phone extends QuickViewGroupElementType {
    override private[ui] def toFacade: m.QuickViewGroupElementType = m.QuickViewGroupElementType.phone
  }

  object text extends QuickViewGroupElementType {
    override private[ui] def toFacade: m.QuickViewGroupElementType = m.QuickViewGroupElementType.text
  }

}
*/
