
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.NotificationListItem
import com.sap.scala.facades.openui5.core.InvisibleText


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.NotificationListGroup")
@js.native
class NotificationListGroup() extends NotificationListBase {
  def addItem(oItem: NotificationListItem): this.type = js.native
  def attachOnCollapse(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyItems(): this.type = js.native
  def detachOnCollapse(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireOnCollapse(mParameters: Object): this.type = js.native
  def getAutoPriority(): Boolean = js.native
  def getCollapsed(): Boolean = js.native
  def getEnableCollapseButtonWhenEmpty(): Boolean = js.native
  def getItems(): js.Array[NotificationListItem] = js.native
  def getMetadata(): Metadata = js.native
  def getShowEmptyGroup(): Boolean = js.native
  def indexOfItem(oItem: NotificationListItem): Int = js.native
  def insertItem(oItem: NotificationListItem, iIndex: Int): this.type = js.native
  def removeAllItems(): js.Array[NotificationListItem] = js.native
  def removeItem(vItem: Int | String | NotificationListItem): NotificationListItem = js.native
  def setAutoPriority(bAutoPriority: Boolean): this.type = js.native
  def setCollapsed(bCollapsed: Boolean): this.type = js.native
  def setEnableCollapseButtonWhenEmpty(bEnableCollapseButtonWhenEmpty: Boolean): this.type = js.native
  def setShowEmptyGroup(bShowEmptyGroup: Boolean): this.type = js.native
}
     