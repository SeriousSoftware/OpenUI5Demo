package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ColorPickerMode extends js.Object

object ColorPickerMode{

}

/* copy to Enum.scala
sealed trait ColorPickerMode{
  private[ui] def toFacade: sap.ui.commons.ColorPickerMode
}

object ColorPickerMode {
  def fromFacade(s: ui.commons.ColorPickerMode): ColorPickerMode = s match {

   case _ =>
     throw new UnsupportedOperationException(s"Unknown ColorPickerMode: $s")
  }
  

}
*/
