package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait FlexRendertype extends js.Object

object FlexRendertype{
  @JSGlobal("sap.m.FlexRendertype.Bare")
  @js.native
  object Bare extends FlexRendertype

  @JSGlobal("sap.m.FlexRendertype.Div")
  @js.native
  object Div extends FlexRendertype

  @JSGlobal("sap.m.FlexRendertype.List")
  @js.native
  object List extends FlexRendertype
}

/* copy to Enum.scala
sealed trait FlexRendertype{
  private[ui] def toFacade: sap.m.FlexRendertype
}

object FlexRendertype {
  def fromFacade(s: m.FlexRendertype): FlexRendertype = s match {
    case m.FlexRendertype.Bare => FlexRendertype.Bare
    case m.FlexRendertype.Div => FlexRendertype.Div
    case m.FlexRendertype.List => FlexRendertype.List
   case _ =>
     throw new UnsupportedOperationException(s"Unknown FlexRendertype: $s")
  }
  
  object Bare extends FlexRendertype {
    override private[ui] def toFacade: m.FlexRendertype = m.FlexRendertype.Bare
  }

  object Div extends FlexRendertype {
    override private[ui] def toFacade: m.FlexRendertype = m.FlexRendertype.Div
  }

  object List extends FlexRendertype {
    override private[ui] def toFacade: m.FlexRendertype = m.FlexRendertype.List
  }

}
*/
