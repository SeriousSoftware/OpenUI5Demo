package com.sap.scala.facades.openui5.commons.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait VAlign extends js.Object

object VAlign{
  @JSGlobal("sap.ui.commons.layout.VAlign.Bottom")
  @js.native
  object Bottom extends VAlign

  @JSGlobal("sap.ui.commons.layout.VAlign.Middle")
  @js.native
  object Middle extends VAlign

  @JSGlobal("sap.ui.commons.layout.VAlign.Top")
  @js.native
  object Top extends VAlign
}

/* copy to Enum.scala
sealed trait VAlign{
  private[ui] def toFacade: sap.ui.commons.layout.VAlign
}

object VAlign {
  def fromFacade(s: ui.commons.layout.VAlign): VAlign = s match {
    case ui.commons.layout.VAlign.Bottom => VAlign.Bottom
    case ui.commons.layout.VAlign.Middle => VAlign.Middle
    case ui.commons.layout.VAlign.Top => VAlign.Top
   case _ =>
     throw new UnsupportedOperationException(s"Unknown VAlign: $s")
  }
  
  object Bottom extends VAlign {
    override private[ui] def toFacade: ui.commons.layout.VAlign = ui.commons.layout.VAlign.Bottom
  }

  object Middle extends VAlign {
    override private[ui] def toFacade: ui.commons.layout.VAlign = ui.commons.layout.VAlign.Middle
  }

  object Top extends VAlign {
    override private[ui] def toFacade: ui.commons.layout.VAlign = ui.commons.layout.VAlign.Top
  }

}
*/
