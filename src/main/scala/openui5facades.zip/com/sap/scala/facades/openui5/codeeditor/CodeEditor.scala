
package com.sap.scala.facades.openui5.codeeditor

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.codeeditor.CodeEditor")
@js.native
class CodeEditor() extends Control {
  def _getEditorInstance(): Object = js.native
  def attachChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachLiveChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachLiveChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireChange(mParameters: Object): this.type = js.native
  def fireLiveChange(mParameters: Object): this.type = js.native
  def focus(): this.type = js.native
  def getColorTheme(): String = js.native
  def getCurrentValue(): String = js.native
  def getEditable(): Boolean = js.native
  def getHeight(): CSSSize = js.native
  def getLineNumbers(): Boolean = js.native
  def getMaxLines(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getSyntaxHints(): Boolean = js.native
  def getType(): String = js.native
  def getValue(): String = js.native
  def getValueSelection(): Boolean = js.native
  def getWidth(): CSSSize = js.native
  def setColorTheme(sTheme: String): this.type = js.native
  def setEditable(bValue: Boolean): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setLineNumbers(bValue: Boolean): this.type = js.native
  def setMaxLines(iMaxLines: Int): Unit = js.native
  def setSyntaxHints(bShow: Boolean): this.type = js.native
  def setType(sType: String): this.type = js.native
  def setValue(sValue: String): this.type = js.native
  def setValueSelection(bValueSelection: Boolean): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     