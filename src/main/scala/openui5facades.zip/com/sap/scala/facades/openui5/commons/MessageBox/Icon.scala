package com.sap.scala.facades.openui5.commons.MessageBox

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Icon extends js.Object

object Icon{
  @JSGlobal("sap.ui.commons.MessageBox.Icon.CRITICAL")
  @js.native
  object CRITICAL extends Icon

  @JSGlobal("sap.ui.commons.MessageBox.Icon.ERROR")
  @js.native
  object ERROR extends Icon

  @JSGlobal("sap.ui.commons.MessageBox.Icon.INFORMATION")
  @js.native
  object INFORMATION extends Icon

  @JSGlobal("sap.ui.commons.MessageBox.Icon.NONE")
  @js.native
  object NONE extends Icon

  @JSGlobal("sap.ui.commons.MessageBox.Icon.QUESTION")
  @js.native
  object QUESTION extends Icon

  @JSGlobal("sap.ui.commons.MessageBox.Icon.SUCCESS")
  @js.native
  object SUCCESS extends Icon

  @JSGlobal("sap.ui.commons.MessageBox.Icon.WARNING")
  @js.native
  object WARNING extends Icon
}

/* copy to Enum.scala
sealed trait Icon{
  private[ui] def toFacade: sap.ui.commons.MessageBox.Icon
}

object Icon {
  def fromFacade(s: ui.commons.MessageBox.Icon): Icon = s match {
    case ui.commons.MessageBox.Icon.CRITICAL => Icon.CRITICAL
    case ui.commons.MessageBox.Icon.ERROR => Icon.ERROR
    case ui.commons.MessageBox.Icon.INFORMATION => Icon.INFORMATION
    case ui.commons.MessageBox.Icon.NONE => Icon.NONE
    case ui.commons.MessageBox.Icon.QUESTION => Icon.QUESTION
    case ui.commons.MessageBox.Icon.SUCCESS => Icon.SUCCESS
    case ui.commons.MessageBox.Icon.WARNING => Icon.WARNING
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Icon: $s")
  }
  
  object CRITICAL extends Icon {
    override private[ui] def toFacade: ui.commons.MessageBox.Icon = ui.commons.MessageBox.Icon.CRITICAL
  }

  object ERROR extends Icon {
    override private[ui] def toFacade: ui.commons.MessageBox.Icon = ui.commons.MessageBox.Icon.ERROR
  }

  object INFORMATION extends Icon {
    override private[ui] def toFacade: ui.commons.MessageBox.Icon = ui.commons.MessageBox.Icon.INFORMATION
  }

  object NONE extends Icon {
    override private[ui] def toFacade: ui.commons.MessageBox.Icon = ui.commons.MessageBox.Icon.NONE
  }

  object QUESTION extends Icon {
    override private[ui] def toFacade: ui.commons.MessageBox.Icon = ui.commons.MessageBox.Icon.QUESTION
  }

  object SUCCESS extends Icon {
    override private[ui] def toFacade: ui.commons.MessageBox.Icon = ui.commons.MessageBox.Icon.SUCCESS
  }

  object WARNING extends Icon {
    override private[ui] def toFacade: ui.commons.MessageBox.Icon = ui.commons.MessageBox.Icon.WARNING
  }

}
*/
