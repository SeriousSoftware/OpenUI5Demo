
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,ValueState,Control,TextAlign,ID}
import com.sap.scala.facades.openui5.core.search.SearchProvider


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.SearchField")
@js.native
class SearchField() extends Control {
  def addAriaDescribedBy(vAriaDescribedBy: ID | Control): this.type = js.native
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def attachSearch(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSuggest(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def clearHistory(): Unit = js.native
  def destroySearchProvider(): this.type = js.native
  def detachSearch(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSuggest(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireSearch(mParameters: Object): this.type = js.native
  def fireSuggest(mParameters: Object): this.type = js.native
  def getAriaDescribedBy(): js.Array[ID] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getEditable(): Boolean = js.native
  def getEnableCache(): Boolean = js.native
  def getEnableClear(): Boolean = js.native
  def getEnabled(): Boolean = js.native
  def getEnableFilterMode(): Boolean = js.native
  def getEnableListSuggest(): Boolean = js.native
  def getMaxHistoryItems(): Int = js.native
  def getMaxLength(): Int = js.native
  def getMaxSuggestionItems(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getPlaceholder(): String = js.native
  def getSearchProvider(): SearchProvider = js.native
  def getShowExternalButton(): Boolean = js.native
  def getShowListExpander(): Boolean = js.native
  def getStartSuggestion(): Int = js.native
  def getTextAlign(): TextAlign = js.native
  def getValue(): String = js.native
  def getValueState(): ValueState = js.native
  def getVisibleItemCount(): Int = js.native
  def getWidth(): CSSSize = js.native
  def removeAllAriaDescribedBy(): js.Array[ID] = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAriaDescribedBy(vAriaDescribedBy: Int | ID | Control): ID = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def setEditable(bEditable: Boolean): this.type = js.native
  def setEnableCache(bEnableCache: Boolean): this.type = js.native
  def setEnableClear(bEnableClear: Boolean): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setEnableFilterMode(bEnableFilterMode: Boolean): this.type = js.native
  def setEnableListSuggest(bEnableListSuggest: Boolean): this.type = js.native
  def setMaxHistoryItems(iMaxHistoryItems: Int): this.type = js.native
  def setMaxLength(iMaxLength: Int): this.type = js.native
  def setMaxSuggestionItems(iMaxSuggestionItems: Int): this.type = js.native
  def setPlaceholder(sPlaceholder: String): this.type = js.native
  def setSearchProvider(oSearchProvider: SearchProvider): this.type = js.native
  def setShowExternalButton(bShowExternalButton: Boolean): this.type = js.native
  def setShowListExpander(bShowListExpander: Boolean): this.type = js.native
  def setStartSuggestion(iStartSuggestion: Int): this.type = js.native
  def setTextAlign(sTextAlign: TextAlign): this.type = js.native
  def setValue(sValue: String): this.type = js.native
  def setValueState(sValueState: ValueState): this.type = js.native
  def setVisibleItemCount(iVisibleItemCount: Int): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
//  def suggest(sSSuggestValue: String, aASuggestions: /*TODO Type: 'string[]' not found.*/): Unit = js.native
}
     