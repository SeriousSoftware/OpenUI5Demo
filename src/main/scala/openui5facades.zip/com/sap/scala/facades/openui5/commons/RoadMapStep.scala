
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.commons.RoadMapStep


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.RoadMapStep")
@js.native
class RoadMapStep() extends Element {
  def addSubStep(oSubStep: this.type): this.type = js.native
  def destroySubSteps(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getEnabled(): Boolean = js.native
  def getExpanded(): Boolean = js.native
  def getLabel(): String = js.native
  def getMetadata(): Metadata = js.native
  def getSubSteps(): js.Array[RoadMapStep] = js.native
  def getVisible(): Boolean = js.native
  def indexOfSubStep(oSubStep: this.type): Int = js.native
  def insertSubStep(oSubStep: this.type, iIndex: Int): this.type = js.native
  def removeAllSubSteps(): js.Array[RoadMapStep] = js.native
  def removeSubStep(vSubStep: Int | String | this.type): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setExpanded(bExpanded: Boolean): this.type = js.native
  def setLabel(sLabel: String): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     