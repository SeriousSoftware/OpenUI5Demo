
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.P13nColumnsItem
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nColumnsPanel")
@js.native
class P13nColumnsPanel() extends P13nPanel {
  def addColumnsItem(oColumnsItem: P13nColumnsItem): this.type = js.native
  def attachAddColumnsItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachChangeColumnsItems(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSetData(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindColumnsItems(oBindingInfo: Object): this.type = js.native
  def destroyColumnsItems(): this.type = js.native
  def detachAddColumnsItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachChangeColumnsItems(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSetData(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAddColumnsItem(mParameters: Object): this.type = js.native
  def fireChangeColumnsItems(mParameters: Object): this.type = js.native
  def fireSetData(mParameters: Object): this.type = js.native
  def getColumnsItems(): js.Array[P13nColumnsItem] = js.native
  def getMetadata(): Metadata = js.native
  def getOkPayload(): Object = js.native
  def getResetPayload(): Object = js.native
  def getVisibleItemsThreshold(): Int = js.native
  def indexOfColumnsItem(oColumnsItem: P13nColumnsItem): Int = js.native
  def insertColumnsItem(oColumnsItem: P13nColumnsItem, iIndex: Int): this.type = js.native
  def reInitialize(): Unit = js.native
  def removeAllColumnsItems(): js.Array[P13nColumnsItem] = js.native
  def removeColumnsItem(vColumnsItem: Int | String | P13nColumnsItem): P13nColumnsItem = js.native
  def setVisibleItemsThreshold(iVisibleItemsThreshold: Int): this.type = js.native
  def unbindColumnsItems(): this.type = js.native
}
     