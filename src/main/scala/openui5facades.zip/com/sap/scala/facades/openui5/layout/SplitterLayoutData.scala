
package com.sap.scala.facades.openui5.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.layout.SplitterLayoutData")
@js.native
class SplitterLayoutData() extends LayoutData {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getMinSize(): Int = js.native
  def getResizable(): Boolean = js.native
  def getSize(): CSSSize = js.native
  def setMinSize(iMinSize: Int): this.type = js.native
  def setResizable(bResizable: Boolean): this.type = js.native
  def setSize(sSize: CSSSize): this.type = js.native
}
     