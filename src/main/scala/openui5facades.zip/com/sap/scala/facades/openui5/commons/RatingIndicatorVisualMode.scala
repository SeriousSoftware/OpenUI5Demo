package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait RatingIndicatorVisualMode extends js.Object

object RatingIndicatorVisualMode{
  @JSGlobal("sap.ui.commons.RatingIndicatorVisualMode.Continuous")
  @js.native
  object Continuous extends RatingIndicatorVisualMode

  @JSGlobal("sap.ui.commons.RatingIndicatorVisualMode.Full")
  @js.native
  object Full extends RatingIndicatorVisualMode

  @JSGlobal("sap.ui.commons.RatingIndicatorVisualMode.Half")
  @js.native
  object Half extends RatingIndicatorVisualMode
}

/* copy to Enum.scala
sealed trait RatingIndicatorVisualMode{
  private[ui] def toFacade: sap.ui.commons.RatingIndicatorVisualMode
}

object RatingIndicatorVisualMode {
  def fromFacade(s: ui.commons.RatingIndicatorVisualMode): RatingIndicatorVisualMode = s match {
    case ui.commons.RatingIndicatorVisualMode.Continuous => RatingIndicatorVisualMode.Continuous
    case ui.commons.RatingIndicatorVisualMode.Full => RatingIndicatorVisualMode.Full
    case ui.commons.RatingIndicatorVisualMode.Half => RatingIndicatorVisualMode.Half
   case _ =>
     throw new UnsupportedOperationException(s"Unknown RatingIndicatorVisualMode: $s")
  }
  
  object Continuous extends RatingIndicatorVisualMode {
    override private[ui] def toFacade: ui.commons.RatingIndicatorVisualMode = ui.commons.RatingIndicatorVisualMode.Continuous
  }

  object Full extends RatingIndicatorVisualMode {
    override private[ui] def toFacade: ui.commons.RatingIndicatorVisualMode = ui.commons.RatingIndicatorVisualMode.Full
  }

  object Half extends RatingIndicatorVisualMode {
    override private[ui] def toFacade: ui.commons.RatingIndicatorVisualMode = ui.commons.RatingIndicatorVisualMode.Half
  }

}
*/
