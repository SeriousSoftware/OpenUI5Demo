
package com.sap.scala.facades.openui5.base

import com.sap.scala.facades.openui5.base.{Metadata,Interface}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.base.Object")
@js.native
class Object()  {
  def defineClass(sClassName: String, oStaticInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): Metadata = js.native
  def destroy(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getInterface(): Interface = js.native
  def getMetadata(): Unit = js.native
}
     