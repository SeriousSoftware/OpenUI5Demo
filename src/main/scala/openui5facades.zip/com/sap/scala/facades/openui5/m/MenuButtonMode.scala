package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait MenuButtonMode extends js.Object

object MenuButtonMode{
  @JSGlobal("sap.m.MenuButtonMode.Regular")
  @js.native
  object Regular extends MenuButtonMode

  @JSGlobal("sap.m.MenuButtonMode.Split")
  @js.native
  object Split extends MenuButtonMode
}

/* copy to Enum.scala
sealed trait MenuButtonMode{
  private[ui] def toFacade: sap.m.MenuButtonMode
}

object MenuButtonMode {
  def fromFacade(s: m.MenuButtonMode): MenuButtonMode = s match {
    case m.MenuButtonMode.Regular => MenuButtonMode.Regular
    case m.MenuButtonMode.Split => MenuButtonMode.Split
   case _ =>
     throw new UnsupportedOperationException(s"Unknown MenuButtonMode: $s")
  }
  
  object Regular extends MenuButtonMode {
    override private[ui] def toFacade: m.MenuButtonMode = m.MenuButtonMode.Regular
  }

  object Split extends MenuButtonMode {
    override private[ui] def toFacade: m.MenuButtonMode = m.MenuButtonMode.Split
  }

}
*/
