
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Paginator")
@js.native
class Paginator() extends Control {
  def attachPage(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPage(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePage(mParameters: Object): this.type = js.native
  def getCurrentPage(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getNumberOfPages(): Int = js.native
  def setCurrentPage(iCurrentPage: Int): this.type = js.native
  def setNumberOfPages(iNumberOfPages: Int): this.type = js.native
}
     