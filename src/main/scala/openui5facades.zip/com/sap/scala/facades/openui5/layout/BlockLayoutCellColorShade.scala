package com.sap.scala.facades.openui5.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait BlockLayoutCellColorShade extends js.Object

object BlockLayoutCellColorShade{
  @JSGlobal("sap.ui.layout.BlockLayoutCellColorShade.ShadeA")
  @js.native
  object ShadeA extends BlockLayoutCellColorShade

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorShade.ShadeB")
  @js.native
  object ShadeB extends BlockLayoutCellColorShade

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorShade.ShadeC")
  @js.native
  object ShadeC extends BlockLayoutCellColorShade

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorShade.ShadeD")
  @js.native
  object ShadeD extends BlockLayoutCellColorShade
}

/* copy to Enum.scala
sealed trait BlockLayoutCellColorShade{
  private[ui] def toFacade: sap.ui.layout.BlockLayoutCellColorShade
}

object BlockLayoutCellColorShade {
  def fromFacade(s: ui.layout.BlockLayoutCellColorShade): BlockLayoutCellColorShade = s match {
    case ui.layout.BlockLayoutCellColorShade.ShadeA => BlockLayoutCellColorShade.ShadeA
    case ui.layout.BlockLayoutCellColorShade.ShadeB => BlockLayoutCellColorShade.ShadeB
    case ui.layout.BlockLayoutCellColorShade.ShadeC => BlockLayoutCellColorShade.ShadeC
    case ui.layout.BlockLayoutCellColorShade.ShadeD => BlockLayoutCellColorShade.ShadeD
   case _ =>
     throw new UnsupportedOperationException(s"Unknown BlockLayoutCellColorShade: $s")
  }
  
  object ShadeA extends BlockLayoutCellColorShade {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorShade = ui.layout.BlockLayoutCellColorShade.ShadeA
  }

  object ShadeB extends BlockLayoutCellColorShade {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorShade = ui.layout.BlockLayoutCellColorShade.ShadeB
  }

  object ShadeC extends BlockLayoutCellColorShade {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorShade = ui.layout.BlockLayoutCellColorShade.ShadeC
  }

  object ShadeD extends BlockLayoutCellColorShade {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorShade = ui.layout.BlockLayoutCellColorShade.ShadeD
  }

}
*/
