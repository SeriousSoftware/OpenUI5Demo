package com.sap.scala.facades.openui5.commons.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Separation extends js.Object

object Separation{
  @JSGlobal("sap.ui.commons.layout.Separation.Large")
  @js.native
  object Large extends Separation

  @JSGlobal("sap.ui.commons.layout.Separation.LargeWithLine")
  @js.native
  object LargeWithLine extends Separation

  @JSGlobal("sap.ui.commons.layout.Separation.Medium")
  @js.native
  object Medium extends Separation

  @JSGlobal("sap.ui.commons.layout.Separation.MediumWithLine")
  @js.native
  object MediumWithLine extends Separation

  @JSGlobal("sap.ui.commons.layout.Separation.None")
  @js.native
  object None extends Separation

  @JSGlobal("sap.ui.commons.layout.Separation.Small")
  @js.native
  object Small extends Separation

  @JSGlobal("sap.ui.commons.layout.Separation.SmallWithLine")
  @js.native
  object SmallWithLine extends Separation
}

/* copy to Enum.scala
sealed trait Separation{
  private[ui] def toFacade: sap.ui.commons.layout.Separation
}

object Separation {
  def fromFacade(s: ui.commons.layout.Separation): Separation = s match {
    case ui.commons.layout.Separation.Large => Separation.Large
    case ui.commons.layout.Separation.LargeWithLine => Separation.LargeWithLine
    case ui.commons.layout.Separation.Medium => Separation.Medium
    case ui.commons.layout.Separation.MediumWithLine => Separation.MediumWithLine
    case ui.commons.layout.Separation.None => Separation.None
    case ui.commons.layout.Separation.Small => Separation.Small
    case ui.commons.layout.Separation.SmallWithLine => Separation.SmallWithLine
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Separation: $s")
  }
  
  object Large extends Separation {
    override private[ui] def toFacade: ui.commons.layout.Separation = ui.commons.layout.Separation.Large
  }

  object LargeWithLine extends Separation {
    override private[ui] def toFacade: ui.commons.layout.Separation = ui.commons.layout.Separation.LargeWithLine
  }

  object Medium extends Separation {
    override private[ui] def toFacade: ui.commons.layout.Separation = ui.commons.layout.Separation.Medium
  }

  object MediumWithLine extends Separation {
    override private[ui] def toFacade: ui.commons.layout.Separation = ui.commons.layout.Separation.MediumWithLine
  }

  object None extends Separation {
    override private[ui] def toFacade: ui.commons.layout.Separation = ui.commons.layout.Separation.None
  }

  object Small extends Separation {
    override private[ui] def toFacade: ui.commons.layout.Separation = ui.commons.layout.Separation.Small
  }

  object SmallWithLine extends Separation {
    override private[ui] def toFacade: ui.commons.layout.Separation = ui.commons.layout.Separation.SmallWithLine
  }

}
*/
