package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait MenuBarDesign extends js.Object

object MenuBarDesign{
  @JSGlobal("sap.ui.commons.MenuBarDesign.Header")
  @js.native
  object Header extends MenuBarDesign

  @JSGlobal("sap.ui.commons.MenuBarDesign.Standard")
  @js.native
  object Standard extends MenuBarDesign
}

/* copy to Enum.scala
sealed trait MenuBarDesign{
  private[ui] def toFacade: sap.ui.commons.MenuBarDesign
}

object MenuBarDesign {
  def fromFacade(s: ui.commons.MenuBarDesign): MenuBarDesign = s match {
    case ui.commons.MenuBarDesign.Header => MenuBarDesign.Header
    case ui.commons.MenuBarDesign.Standard => MenuBarDesign.Standard
   case _ =>
     throw new UnsupportedOperationException(s"Unknown MenuBarDesign: $s")
  }
  
  object Header extends MenuBarDesign {
    override private[ui] def toFacade: ui.commons.MenuBarDesign = ui.commons.MenuBarDesign.Header
  }

  object Standard extends MenuBarDesign {
    override private[ui] def toFacade: ui.commons.MenuBarDesign = ui.commons.MenuBarDesign.Standard
  }

}
*/
