package com.sap.scala.facades.openui5.m.MessageBox

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Icon extends js.Object

object Icon{
  @JSGlobal("sap.m.MessageBox.Icon.ERROR")
  @js.native
  object ERROR extends Icon

  @JSGlobal("sap.m.MessageBox.Icon.INFORMATION")
  @js.native
  object INFORMATION extends Icon

  @JSGlobal("sap.m.MessageBox.Icon.NONE")
  @js.native
  object NONE extends Icon

  @JSGlobal("sap.m.MessageBox.Icon.QUESTION")
  @js.native
  object QUESTION extends Icon

  @JSGlobal("sap.m.MessageBox.Icon.SUCCESS")
  @js.native
  object SUCCESS extends Icon

  @JSGlobal("sap.m.MessageBox.Icon.WARNING")
  @js.native
  object WARNING extends Icon
}

/* copy to Enum.scala
sealed trait Icon{
  private[ui] def toFacade: sap.m.MessageBox.Icon
}

object Icon {
  def fromFacade(s: m.MessageBox.Icon): Icon = s match {
    case m.MessageBox.Icon.ERROR => Icon.ERROR
    case m.MessageBox.Icon.INFORMATION => Icon.INFORMATION
    case m.MessageBox.Icon.NONE => Icon.NONE
    case m.MessageBox.Icon.QUESTION => Icon.QUESTION
    case m.MessageBox.Icon.SUCCESS => Icon.SUCCESS
    case m.MessageBox.Icon.WARNING => Icon.WARNING
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Icon: $s")
  }
  
  object ERROR extends Icon {
    override private[ui] def toFacade: m.MessageBox.Icon = m.MessageBox.Icon.ERROR
  }

  object INFORMATION extends Icon {
    override private[ui] def toFacade: m.MessageBox.Icon = m.MessageBox.Icon.INFORMATION
  }

  object NONE extends Icon {
    override private[ui] def toFacade: m.MessageBox.Icon = m.MessageBox.Icon.NONE
  }

  object QUESTION extends Icon {
    override private[ui] def toFacade: m.MessageBox.Icon = m.MessageBox.Icon.QUESTION
  }

  object SUCCESS extends Icon {
    override private[ui] def toFacade: m.MessageBox.Icon = m.MessageBox.Icon.SUCCESS
  }

  object WARNING extends Icon {
    override private[ui] def toFacade: m.MessageBox.Icon = m.MessageBox.Icon.WARNING
  }

}
*/
