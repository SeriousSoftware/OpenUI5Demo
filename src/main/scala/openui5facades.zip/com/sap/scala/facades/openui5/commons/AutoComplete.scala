
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.AutoComplete")
@js.native
class AutoComplete() extends ComboBox {
  def attachSuggest(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSuggest(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireSuggest(mParameters: Object): this.type = js.native
  def getEnableScrolling(): Boolean = js.native
  def getListBox(): Unit = js.native
  def getMetadata(): Metadata = js.native
  def getSelectedItemId(): Unit = js.native
  def getSelectedKey(): Unit = js.native
  def setEnableScrolling(bEnableScrolling: Boolean): this.type = js.native
  def setFilterFunction(fFilter: js.Function1[Event[EventProps], Unit]): Unit = js.native
  def setListBox(): Unit = js.native
  def setSelectedItemId(): Unit = js.native
  def setSelectedKey(): Unit = js.native
}
     