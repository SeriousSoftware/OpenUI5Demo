
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.core.Manifest


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.ComponentMetadata")
@js.native
class ComponentMetadata()  {
  def getComponentName(): String = js.native
//  def getComponents(): /*TODO Type: 'string[]' not found.*/ = js.native
  def getConfig(sKey: String, bDoNotMerge: Boolean): Object = js.native
//  def getCustomEntry(sKey: String, bMerged: Boolean): /*TODO Type: 'Object' not found.*/ = js.native
//  def getDependencies(): /*TODO Type: 'Object' not found.*/ = js.native
//  def getIncludes(): /*TODO Type: 'string[]' not found.*/ = js.native
//  def getLibs(): /*TODO Type: 'string[]' not found.*/ = js.native
//  def getManifest(): /*TODO Type: 'Object' not found.*/ = js.native
//  def getManifestEntry(sKey: String, bMerged: Boolean): /*TODO Type: 'any' not found.*/ | /*TODO Type: 'null' not found.*/ = js.native
  def getManifestObject(): Manifest = js.native
  def getMetadataVersion(): Int = js.native
//  def getRawManifest(): /*TODO Type: 'Object' not found.*/ = js.native
  def getUI5Version(): String = js.native
  def getVersion(): String = js.native
  def isBaseClass(): Boolean = js.native
}
     