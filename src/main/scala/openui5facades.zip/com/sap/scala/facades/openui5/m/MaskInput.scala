
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.MaskInputRule


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.MaskInput")
@js.native
class MaskInput() extends InputBase {
//  def _feedReplaceChar(sChar: /*TODO Type: 'String' not found.*/, iPlacePosition: Int, sCurrentInputValue: String): /*TODO Type: 'String' not found.*/ = js.native
//  def _isCharAllowed(sChar: /*TODO Type: 'String' not found.*/, iIndex: Int): Unit = js.native
  def addRule(oRule: MaskInputRule): this.type = js.native
  def destroyRules(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMask(): String = js.native
  def getMetadata(): Metadata = js.native
  def getPlaceholderSymbol(): String = js.native
  def getRules(): js.Array[MaskInputRule] = js.native
  def indexOfRule(oRule: MaskInputRule): Int = js.native
  def insertRule(oRule: MaskInputRule, iIndex: Int): this.type = js.native
  def removeAllRules(): js.Array[MaskInputRule] = js.native
  def removeRule(vRule: Int | String | MaskInputRule): MaskInputRule = js.native
  def setValue(sValue: String): this.type = js.native
}
     