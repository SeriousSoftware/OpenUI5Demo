
package com.sap.scala.facades.openui5.core.mvc

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Element,Control}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.mvc.View")
@js.native
class View() extends Control {
  def addContent(oContent: Control): this.type = js.native
  def attachAfterInit(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachAfterRendering(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeExit(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeRendering(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def byId(sId: String): Element = js.native
//  def clone(sIdSuffix: String, aLocalIds: /*TODO Type: 'string[]' not found.*/): Element = js.native
  def createId(sId: String): String = js.native
  def destroyContent(): this.type = js.native
  def detachAfterInit(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachAfterRendering(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeExit(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeRendering(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterInit(mParameters: Object): this.type = js.native
  def fireAfterRendering(mParameters: Object): this.type = js.native
  def fireBeforeExit(mParameters: Object): this.type = js.native
  def fireBeforeRendering(mParameters: Object): this.type = js.native
  def getContent(): js.Array[Control] = js.native
  def getController(): Object = js.native
  def getControllerName(): String = js.native
  def getDisplayBlock(): Boolean = js.native
  def getHeight(): CSSSize = js.native
  def getLocalId(sId: String): String = js.native
  def getMetadata(): Metadata = js.native
  def getPreprocessorInfo(bSync: Boolean): Object = js.native
  def getViewData(): Object = js.native
  def getViewName(): String = js.native
  def getWidth(): CSSSize = js.native
  def hasPreprocessor(sType: String): Boolean = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
//  def loaded(): /*TODO Type: 'Promise' not found.*/ = js.native
  def registerPreprocessor(sType: String, vPreprocessor: String | js.Function1[Event[EventProps], Unit], sViewType: String, bSyncSupport: Boolean, bOnDemand: Boolean, mSettings: Object): Unit = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
//  def runPreprocessor(sType: String, vSource: Object | String | /*TODO Type: 'Element' not found.*/, bSync: Boolean): /*TODO Type: 'Promise' not found.*/ | Object | String | /*TODO Type: 'Element' not found.*/ = js.native
  def setDisplayBlock(bDisplayBlock: Boolean): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setViewName(sViewName: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     