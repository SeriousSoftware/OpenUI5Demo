
package com.sap.scala.facades.openui5.f.semantic

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.f.semantic.MainAction")
@js.native
class MainAction() extends SemanticButton {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getText(): String = js.native
  def setText(sText: String): this.type = js.native
}
     