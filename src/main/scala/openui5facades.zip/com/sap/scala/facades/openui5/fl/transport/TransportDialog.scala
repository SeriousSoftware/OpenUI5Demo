
package com.sap.scala.facades.openui5.fl.transport

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.fl.transport.TransportDialog")
@js.native
class TransportDialog() extends Dialog {
  def attachCancel(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachOk(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachCancel(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachOk(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireCancel(mParameters: Object): this.type = js.native
  def fireOk(mParameters: Object): this.type = js.native
  def getHidePackage(): Boolean = js.native
//  def getLrepObject(): /*TODO Type: 'any' not found.*/ = js.native
  def getMetadata(): Metadata = js.native
  def getPkg(): String = js.native
//  def getTransports(): /*TODO Type: 'any' not found.*/ = js.native
  def setHidePackage(bHide: Boolean): Unit = js.native
  def setLrepObject(oObject: Object): Unit = js.native
  def setPkg(sPackage: String): Unit = js.native
//  def setTransports(aSelection: /*TODO Type: 'array' not found.*/): Unit = js.native
}
     