
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,ValueState,TextDirection}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.ProgressIndicator")
@js.native
class ProgressIndicator() extends Control {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getDisplayValue(): String = js.native
  def getEnabled(): Boolean = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getPercentValue(): Float = js.native
  def getShowValue(): Boolean = js.native
  def getState(): ValueState = js.native
  def getTextDirection(): TextDirection = js.native
  def getWidth(): CSSSize = js.native
  def setDisplayValue(sDisplayValue: String): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setPercentValue(fPercentValue: Float): this.type = js.native
  def setShowValue(bShowValue: Boolean): this.type = js.native
  def setState(sState: ValueState): this.type = js.native
  def setTextDirection(sTextDirection: TextDirection): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     