
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{MenuItem,Dialog}
import com.sap.scala.facades.openui5.unified.Menu


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.Menu")
@js.native
class Menu() extends Control {
  def addItem(oItem: MenuItem): this.type = js.native
  def attachClosed(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachItemSelected(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindItems(oBindingInfo: Object): this.type = js.native
  def close(): Unit = js.native
  def destroyItems(): this.type = js.native
  def detachClosed(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachItemSelected(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireClosed(mParameters: Object): this.type = js.native
  def fireItemSelected(mParameters: Object): this.type = js.native
  def getItems(): js.Array[MenuItem] = js.native
  def getMetadata(): Metadata = js.native
  def getTitle(): String = js.native
  def indexOfItem(oItem: MenuItem): Int = js.native
  def init(): Unit = js.native
  def insertItem(oItem: MenuItem, iIndex: Int): this.type = js.native
//  def openBy(oControl: /*TODO Type: 'undefined' not found.*/, bWithKeyboard: /*TODO Type: 'undefined' not found.*/): Unit = js.native
  def removeAllItems(): js.Array[MenuItem] = js.native
  def removeItem(vItem: Int | String | MenuItem): MenuItem = js.native
//  def setTitle(sTitle: /*TODO Type: 'String' not found.*/): Unit = js.native
  def unbindItems(): this.type = js.native
}
     