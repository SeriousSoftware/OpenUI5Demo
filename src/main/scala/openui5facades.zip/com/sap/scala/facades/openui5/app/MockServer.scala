
package com.sap.scala.facades.openui5.app




import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.app.MockServer")
@js.native
class MockServer() extends ManagedObject {

}
     