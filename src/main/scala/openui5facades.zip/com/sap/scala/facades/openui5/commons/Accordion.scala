
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize
import com.sap.scala.facades.openui5.commons.AccordionSection


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Accordion")
@js.native
class Accordion() extends Control {
  def addSection(oSection: AccordionSection): this.type = js.native
  def attachSectionClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSectionOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSectionsReorder(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def closeSection(sSectionId: String): Unit = js.native
  def destroySections(): this.type = js.native
  def detachSectionClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSectionOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSectionsReorder(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireSectionClose(mParameters: Object): this.type = js.native
  def fireSectionOpen(mParameters: Object): this.type = js.native
  def fireSectionsReorder(mParameters: Object): this.type = js.native
  def getMetadata(): Metadata = js.native
  def getOpenedSectionsId(): String = js.native
  def getSections(): js.Array[AccordionSection] = js.native
  def getWidth(): CSSSize = js.native
  def indexOfSection(oSection: AccordionSection): Int = js.native
  def insertSection(oSection: AccordionSection, iIndex: Int): this.type = js.native
  def openSection(sSectionId: String): Unit = js.native
  def removeAllSections(): js.Array[AccordionSection] = js.native
  def removeSection(vSection: Int | String | AccordionSection): AccordionSection = js.native
  def setOpenedSectionsId(sOpenedSectionsId: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     