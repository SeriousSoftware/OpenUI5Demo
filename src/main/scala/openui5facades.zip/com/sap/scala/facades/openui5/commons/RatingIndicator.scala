
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{URI,Control,ID}
import com.sap.scala.facades.openui5.commons.RatingIndicatorVisualMode


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.RatingIndicator")
@js.native
class RatingIndicator() extends Control {
  def addAriaDescribedBy(vAriaDescribedBy: ID | Control): this.type = js.native
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def attachChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindValue(oBindingInfo: Object): this.type = js.native
  def detachChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireChange(mParameters: Object): this.type = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getAriaDescribedBy(): js.Array[ID] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getAverageValue(): Float = js.native
  def getEditable(): Boolean = js.native
  def getIconHovered(): URI = js.native
  def getIconSelected(): URI = js.native
  def getIconUnselected(): URI = js.native
  def getMaxValue(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getValue(): Float = js.native
  def getVisualMode(): RatingIndicatorVisualMode = js.native
  def removeAllAriaDescribedBy(): js.Array[ID] = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAriaDescribedBy(vAriaDescribedBy: Int | ID | Control): ID = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def setAverageValue(fAverageValue: Float): this.type = js.native
  def setEditable(bEditable: Boolean): this.type = js.native
  def setIconHovered(sIconHovered: URI): this.type = js.native
  def setIconSelected(sIconSelected: URI): this.type = js.native
  def setIconUnselected(sIconUnselected: URI): this.type = js.native
  def setMaxValue(iMaxValue: Int): this.type = js.native
  def setValue(fValue: Float): this.type = js.native
  def setVisualMode(sVisualMode: RatingIndicatorVisualMode): this.type = js.native
  def unbindValue(): this.type = js.native
}
     