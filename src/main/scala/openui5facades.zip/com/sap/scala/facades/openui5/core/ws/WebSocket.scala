
package com.sap.scala.facades.openui5.core.ws

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.ws.ReadyState


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.ws.WebSocket")
@js.native
class WebSocket() extends EventProvider {
  def attachClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachError(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachMessage(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def close(iCode: Int, sReason: String): this.type = js.native
  def detachClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachError(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachMessage(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireClose(mArguments: Object): this.type = js.native
  def fireError(mArguments: Object): this.type = js.native
  def fireMessage(mArguments: Object): this.type = js.native
  def fireOpen(mArguments: Object): this.type = js.native
  def getInterface(): Unit = js.native
  def getMetadata(): Metadata = js.native
  def getProtocol(): String = js.native
  def getReadyState(): ReadyState = js.native
  def send(sMessage: String): this.type = js.native
}
     