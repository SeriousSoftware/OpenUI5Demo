
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.GrowingList")
@js.native
class GrowingList() extends List {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getScrollToLoad(): Boolean = js.native
  def getThreshold(): Int = js.native
  def getTriggerText(): String = js.native
  def setScrollToLoad(bScrollToLoad: Boolean): this.type = js.native
  def setThreshold(iThreshold: Int): this.type = js.native
  def setTriggerText(sTriggerText: String): this.type = js.native
}
     