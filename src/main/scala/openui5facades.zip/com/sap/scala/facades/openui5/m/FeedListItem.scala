
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{ListType,LinkConversion,FormattedText}
import com.sap.scala.facades.openui5.core.URI


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.FeedListItem")
@js.native
class FeedListItem() extends ListItemBase {
  def attachIconPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSenderPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachIconPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSenderPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireIconPress(mParameters: Object): this.type = js.native
  def fireSenderPress(mParameters: Object): this.type = js.native
  def getActiveIcon(): URI = js.native
  def getConvertedLinksDefaultTarget(): String = js.native
  def getConvertLinksToAnchorTags(): LinkConversion = js.native
  def getIcon(): URI = js.native
  def getIconActive(): Boolean = js.native
  def getIconDensityAware(): Boolean = js.native
  def getInfo(): String = js.native
  def getMaxCharacters(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getSender(): String = js.native
  def getSenderActive(): Boolean = js.native
  def getShowIcon(): Boolean = js.native
  def getText(): String = js.native
  def getTimestamp(): String = js.native
  def setActiveIcon(sActiveIcon: URI): this.type = js.native
  def setConvertedLinksDefaultTarget(sConvertedLinksDefaultTarget: String): this.type = js.native
  def setConvertLinksToAnchorTags(sConvertLinksToAnchorTags: LinkConversion): this.type = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setIconActive(bIconActive: Boolean): this.type = js.native
  def setIconDensityAware(bIconDensityAware: Boolean): this.type = js.native
  def setInfo(sInfo: String): this.type = js.native
  def setMaxCharacters(iMaxCharacters: Int): this.type = js.native
  def setSender(sSender: String): this.type = js.native
  def setSenderActive(bSenderActive: Boolean): this.type = js.native
  def setShowIcon(bShowIcon: Boolean): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTimestamp(sTimestamp: String): this.type = js.native
  def setType(jsType: ListType): this.type = js.native
  def setUnread(value: Boolean): this.type = js.native
}
     