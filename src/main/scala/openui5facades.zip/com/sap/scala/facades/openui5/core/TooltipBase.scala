
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{Collision,Dock}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.TooltipBase")
@js.native
class TooltipBase() extends Control {
  def attachClosed(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachClosed(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireClosed(mParameters: Object): this.type = js.native
  def getAtPosition(): Dock = js.native
  def getCloseDelay(): Int = js.native
  def getCloseDuration(): Int = js.native
  def getCollision(): Collision = js.native
  def getMetadata(): Metadata = js.native
  def getMyPosition(): Dock = js.native
  def getOffset(): String = js.native
  def getOpenDelay(): Int = js.native
  def getOpenDuration(): Int = js.native
  def getText(): String = js.native
  def setAtPosition(sAtPosition: Dock): this.type = js.native
  def setCloseDelay(iCloseDelay: Int): this.type = js.native
  def setCloseDuration(iCloseDuration: Int): this.type = js.native
  def setCollision(sCollision: Collision): this.type = js.native
  def setMyPosition(sMyPosition: Dock): this.type = js.native
  def setOffset(sOffset: String): this.type = js.native
  def setOpenDelay(iOpenDelay: Int): this.type = js.native
  def setOpenDuration(iOpenDuration: Int): this.type = js.native
  def setText(sText: String): this.type = js.native
}
     