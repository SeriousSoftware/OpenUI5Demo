
package com.sap.scala.facades.openui5.core.util

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.util.MockServer")
@js.native
class MockServer() extends ManagedObject {
  def attachAfter(event: String, fnCallback: js.Function1[Event[EventProps], Unit], sEntitySet: String): Unit = js.native
  def attachBefore(event: String, fnCallback: js.Function1[Event[EventProps], Unit], sEntitySet: String): Unit = js.native
  def config(mConfig: Object): Unit = js.native
  def destroy(bSuppressInvalidate: Boolean): Unit = js.native
  def destroyAll(): Unit = js.native
  def detachAfter(event: String, fnCallback: js.Function1[Event[EventProps], Unit], sEntitySet: String): Unit = js.native
  def detachBefore(event: String, fnCallback: js.Function1[Event[EventProps], Unit], sEntitySet: String): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
//  def getEntitySetData(sEntitySetName: /*TODO Type: 'undefined' not found.*/): /*TODO Type: 'array' not found.*/ = js.native
  def getMetadata(): Metadata = js.native
//  def getRequests(): /*TODO Type: 'object[]' not found.*/ = js.native
  def getRootUri(): String = js.native
  def isStarted(): Boolean = js.native
  def respond(): Unit = js.native
//  def setEntitySetData(sEntitySetName: /*TODO Type: 'undefined' not found.*/, aData: /*TODO Type: 'undefined' not found.*/): Unit = js.native
//  def setRequests(requests: /*TODO Type: 'object[]' not found.*/): Unit = js.native
  def setRootUri(rootUri: String): Unit = js.native
  def simulate(sMetadataUrl: String, vMockdataSettings: String | Object): Unit = js.native
  def start(): Unit = js.native
  def startAll(): Unit = js.native
  def stop(): Unit = js.native
  def stopAll(): Unit = js.native
}
     