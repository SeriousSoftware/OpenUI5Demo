
package com.sap.scala.facades.openui5.core.tmpl

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.mvc.View
import com.sap.scala.facades.openui5.core.{Control,ID}
import com.sap.scala.facades.openui5.core.tmpl.Template


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.tmpl.TemplateControl")
@js.native
class TemplateControl() extends Control {
  def attachAfterRendering(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeRendering(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
//  def bindList(sPath: String): /*TODO Type: 'any' not found.*/ = js.native
//  def bindProp(sPath: String): /*TODO Type: 'any' not found.*/ = js.native
  def createControl(mSettings: Object, sParentPath: String, bDoNotAdd: Boolean, oView: View): Control = js.native
  def createDOMElement(mSettings: Object, sParentPath: String, bDoNotAdd: Boolean): Control = js.native
  def detachAfterRendering(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeRendering(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterRendering(mParameters: Object): this.type = js.native
  def fireBeforeRendering(mParameters: Object): this.type = js.native
  def getContext(): Object = js.native
  def getMetadata(): Metadata = js.native
  def getTemplate(): ID = js.native
  def getTemplateRenderer(): js.Function1[Event[EventProps], Unit] = js.native
  def isInline(): Boolean = js.native
  def setContext(oContext: Object): this.type = js.native
  def setTemplate(oTemplate: ID | Template): this.type = js.native
  def setTemplateRenderer(fnRenderer: js.Function1[Event[EventProps], Unit]): Template = js.native
}
     