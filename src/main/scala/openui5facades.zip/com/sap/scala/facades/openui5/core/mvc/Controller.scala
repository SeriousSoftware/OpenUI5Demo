
package com.sap.scala.facades.openui5.core.mvc

import com.sap.scala.facades.openui5.core.mvc.View
import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{Element,Component}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.mvc.Controller")
@js.native
class Controller() extends EventProvider {
  def byId(sId: String): Element = js.native
  def createId(sId: String): String = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getOwnerComponent(): Component = js.native
  def getView(): View = js.native
  def onAfterRendering(): Unit = js.native
  def onBeforeRendering(): Unit = js.native
  def onExit(): Unit = js.native
  def onInit(): Unit = js.native
  def registerExtensionProvider(sExtensionProvider: String): Unit = js.native
}
     