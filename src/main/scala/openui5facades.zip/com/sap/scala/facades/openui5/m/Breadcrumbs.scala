
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{Link,Select,Text}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.Breadcrumbs")
@js.native
class Breadcrumbs() extends Control {
  def addLink(oLink: Link): this.type = js.native
  def destroyLinks(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getCurrentLocationText(): String = js.native
  def getLinks(): js.Array[Link] = js.native
  def getMetadata(): Metadata = js.native
  def indexOfLink(oLink: Link): Int = js.native
  def insertLink(oLink: Link, iIndex: Int): this.type = js.native
  def removeAllLinks(): js.Array[Link] = js.native
  def removeLink(vLink: Int | String | Link): Link = js.native
  def setCurrentLocationText(sCurrentLocationText: String): this.type = js.native
}
     