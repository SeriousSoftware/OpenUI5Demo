
package com.sap.scala.facades.openui5.commons




import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.MenuItemBase")
@js.native
class MenuItemBase() extends MenuItemBase {

}
     