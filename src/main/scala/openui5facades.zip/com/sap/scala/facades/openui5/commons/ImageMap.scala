
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.commons.Area


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.ImageMap")
@js.native
class ImageMap() extends Control {
  def addArea(oArea: Area): this.type = js.native
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
//  def createArea(content: /*TODO Type: 'any' not found.*/): this.type = js.native
  def destroyAreas(): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePress(mParameters: Object): this.type = js.native
  def getAreas(): js.Array[Area] = js.native
  def getMetadata(): Metadata = js.native
  def getName(): String = js.native
  def indexOfArea(oArea: Area): Int = js.native
  def insertArea(oArea: Area, iIndex: Int): this.type = js.native
  def removeAllAreas(): js.Array[Area] = js.native
  def removeArea(vArea: Int | String | Area): Area = js.native
  def setName(sName: String): this.type = js.native
}
     