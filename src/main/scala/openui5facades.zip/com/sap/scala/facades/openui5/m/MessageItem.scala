
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.Link
import com.sap.scala.facades.openui5.core.{URI,MessageType}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.MessageItem")
@js.native
class MessageItem() extends Item {
  def destroyLink(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getCounter(): Int = js.native
  def getDescription(): String = js.native
  def getGroupName(): String = js.native
  def getLink(): Link = js.native
  def getLongtextUrl(): URI = js.native
  def getMarkupDescription(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getSubtitle(): String = js.native
  def getTitle(): String = js.native
  def getType(): MessageType = js.native
  def setCounter(iCounter: Int): this.type = js.native
  def setDescription(sDescription: String): this.type = js.native
  def setGroupName(sGroupName: String): this.type = js.native
  def setLink(oLink: Link): this.type = js.native
  def setLongtextUrl(sLongtextUrl: URI): this.type = js.native
  def setMarkupDescription(bMarkupDescription: Boolean): this.type = js.native
  def setSubtitle(sSubtitle: String): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setType(sType: MessageType): this.type = js.native
}
     