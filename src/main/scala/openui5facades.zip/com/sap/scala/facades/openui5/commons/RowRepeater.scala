
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control,Title}
import com.sap.scala.facades.openui5.commons.{Paginator,RowRepeaterFilter,Toolbar,RowRepeaterDesign,Button,RowRepeaterSorter}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.RowRepeater")
@js.native
class RowRepeater() extends Control {
  def addFilter(oFilter: RowRepeaterFilter): this.type = js.native
  def addRow(oRow: Control): this.type = js.native
  def addSorter(oSorter: RowRepeaterSorter): this.type = js.native
  def applyFilter(sId: String): Unit = js.native
  def attachFilter(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachPage(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachResize(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSort(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindRows(oBindingInfo: Object): this.type = js.native
  def destroyFilters(): this.type = js.native
  def destroyNoData(): this.type = js.native
  def destroyRows(): this.type = js.native
  def destroySorters(): this.type = js.native
  def destroyTitle(): this.type = js.native
  def detachFilter(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPage(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachResize(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSort(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireFilter(mParameters: Object): this.type = js.native
  def firePage(mParameters: Object): this.type = js.native
  def fireResize(mParameters: Object): this.type = js.native
  def fireSort(mParameters: Object): this.type = js.native
  def firstPage(): Unit = js.native
  def getCurrentPage(): Int = js.native
  def getDesign(): RowRepeaterDesign = js.native
  def getFilters(): js.Array[RowRepeaterFilter] = js.native
  def getFixedRowHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getNoData(): Control = js.native
  def getNumberOfRows(): Int = js.native
  def getRows(): js.Array[Control] = js.native
  def getShowMoreSteps(): Int = js.native
  def getSorters(): js.Array[RowRepeaterSorter] = js.native
  def getThreshold(): Int = js.native
  def getTitle(): Title = js.native
  def gotoPage(iPageNumber: Int): Unit = js.native
  def indexOfFilter(oFilter: RowRepeaterFilter): Int = js.native
  def indexOfRow(oRow: Control): Int = js.native
  def indexOfSorter(oSorter: RowRepeaterSorter): Int = js.native
  def insertFilter(oFilter: RowRepeaterFilter, iIndex: Int): this.type = js.native
  def insertRow(oRow: Control, iIndex: Int): this.type = js.native
  def insertSorter(oSorter: RowRepeaterSorter, iIndex: Int): this.type = js.native
  def lastPage(): Unit = js.native
  def nextPage(): Unit = js.native
  def previousPage(): Unit = js.native
  def removeAllFilters(): js.Array[RowRepeaterFilter] = js.native
  def removeAllRows(): js.Array[Control] = js.native
  def removeAllSorters(): js.Array[RowRepeaterSorter] = js.native
  def removeFilter(vFilter: Int | String | RowRepeaterFilter): RowRepeaterFilter = js.native
  def removeRow(vRow: Int | String | Control): Control = js.native
  def removeSorter(vSorter: Int | String | RowRepeaterSorter): RowRepeaterSorter = js.native
  def resize(iNumberOfRows: Int): Unit = js.native
  def setCurrentPage(iCurrentPage: Int): this.type = js.native
  def setDesign(sDesign: RowRepeaterDesign): this.type = js.native
  def setFixedRowHeight(sFixedRowHeight: CSSSize): this.type = js.native
  def setNoData(oNoData: Control): this.type = js.native
  def setNumberOfRows(iNumberOfRows: Int): this.type = js.native
  def setShowMoreSteps(iShowMoreSteps: Int): this.type = js.native
  def setThreshold(iThreshold: Int): this.type = js.native
  def setTitle(oTitle: Title): this.type = js.native
  def triggerShowMore(): this.type = js.native
  def triggerSort(sId: String): Unit = js.native
  def unbindRows(): this.type = js.native
}
     