
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,ValueState,Control,ID,Item}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.RadioButtonGroup")
@js.native
class RadioButtonGroup() extends Control {
  def addAriaDescribedBy(vAriaDescribedBy: ID | Control): this.type = js.native
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def addItem(oItem: Item): this.type = js.native
  def attachSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindItems(oBindingInfo: Object): this.type = js.native
  def clone(): this.type = js.native
  def destroyItems(): this.type = js.native
  def detachSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireSelect(mParameters: Object): this.type = js.native
  def getAriaDescribedBy(): js.Array[ID] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getColumns(): Int = js.native
  def getEditable(): Boolean = js.native
  def getEnabled(): Boolean = js.native
  def getItems(): js.Array[Item] = js.native
  def getMetadata(): Metadata = js.native
  def getSelectedIndex(): Int = js.native
  def getSelectedItem(): Item = js.native
  def getValueState(): ValueState = js.native
  def getWidth(): CSSSize = js.native
  def indexOfItem(oItem: Item): Int = js.native
  def insertItem(oItem: Item, iIndex: Int): this.type = js.native
  def removeAllAriaDescribedBy(): js.Array[ID] = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAllItems(): js.Array[Item] = js.native
  def removeAriaDescribedBy(vAriaDescribedBy: Int | ID | Control): ID = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def removeItem(vItem: Int | String | Item): Item = js.native
  def setColumns(iColumns: Int): this.type = js.native
  def setEditable(bEditable: Boolean): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setSelectedIndex(iSelectedIndex: Int): this.type = js.native
  def setSelectedItem(oSelectedItem: Item): Unit = js.native
  def setValueState(sValueState: ValueState): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
  def unbindItems(): this.type = js.native
}
     