package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait InputType extends js.Object

object InputType{
  @JSGlobal("sap.m.InputType.Date")
  @js.native
  object Date extends InputType

  @JSGlobal("sap.m.InputType.Datetime")
  @js.native
  object Datetime extends InputType

  @JSGlobal("sap.m.InputType.DatetimeLocale")
  @js.native
  object DatetimeLocale extends InputType

  @JSGlobal("sap.m.InputType.Email")
  @js.native
  object Email extends InputType

  @JSGlobal("sap.m.InputType.Month")
  @js.native
  object Month extends InputType

  @JSGlobal("sap.m.InputType.Number")
  @js.native
  object Number extends InputType

  @JSGlobal("sap.m.InputType.Password")
  @js.native
  object Password extends InputType

  @JSGlobal("sap.m.InputType.Tel")
  @js.native
  object Tel extends InputType

  @JSGlobal("sap.m.InputType.Text")
  @js.native
  object Text extends InputType

  @JSGlobal("sap.m.InputType.Time")
  @js.native
  object Time extends InputType

  @JSGlobal("sap.m.InputType.Url")
  @js.native
  object Url extends InputType

  @JSGlobal("sap.m.InputType.Week")
  @js.native
  object Week extends InputType
}

/* copy to Enum.scala
sealed trait InputType{
  private[ui] def toFacade: sap.m.InputType
}

object InputType {
  def fromFacade(s: m.InputType): InputType = s match {
    case m.InputType.Date => InputType.Date
    case m.InputType.Datetime => InputType.Datetime
    case m.InputType.DatetimeLocale => InputType.DatetimeLocale
    case m.InputType.Email => InputType.Email
    case m.InputType.Month => InputType.Month
    case m.InputType.Number => InputType.Number
    case m.InputType.Password => InputType.Password
    case m.InputType.Tel => InputType.Tel
    case m.InputType.Text => InputType.Text
    case m.InputType.Time => InputType.Time
    case m.InputType.Url => InputType.Url
    case m.InputType.Week => InputType.Week
   case _ =>
     throw new UnsupportedOperationException(s"Unknown InputType: $s")
  }
  
  object Date extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Date
  }

  object Datetime extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Datetime
  }

  object DatetimeLocale extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.DatetimeLocale
  }

  object Email extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Email
  }

  object Month extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Month
  }

  object Number extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Number
  }

  object Password extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Password
  }

  object Tel extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Tel
  }

  object Text extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Text
  }

  object Time extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Time
  }

  object Url extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Url
  }

  object Week extends InputType {
    override private[ui] def toFacade: m.InputType = m.InputType.Week
  }

}
*/
