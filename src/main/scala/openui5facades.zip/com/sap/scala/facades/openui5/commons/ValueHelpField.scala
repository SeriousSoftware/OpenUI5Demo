
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.URI


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.ValueHelpField")
@js.native
class ValueHelpField() extends TextField {
  def attachValueHelpRequest(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachValueHelpRequest(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireValueHelpRequest(mParameters: Object): this.type = js.native
  def getIconDisabledURL(): URI = js.native
  def getIconHoverURL(): URI = js.native
  def getIconURL(): URI = js.native
  def getMetadata(): Metadata = js.native
//  def onsapshow(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
  def setIconDisabledURL(sIconDisabledURL: URI): this.type = js.native
  def setIconHoverURL(sIconHoverURL: URI): this.type = js.native
  def setIconURL(sIconURL: URI): this.type = js.native
}
     