
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.CustomData")
@js.native
class CustomData() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getKey(): String = js.native
  def getMetadata(): Metadata = js.native
//  def getValue(): /*TODO Type: 'any' not found.*/ = js.native
  def getWriteToDom(): Boolean = js.native
  def setKey(sKey: String): this.type = js.native
//  def setValue(oValue: /*TODO Type: 'any' not found.*/): this.type = js.native
  def setWriteToDom(bWriteToDom: Boolean): this.type = js.native
}
     