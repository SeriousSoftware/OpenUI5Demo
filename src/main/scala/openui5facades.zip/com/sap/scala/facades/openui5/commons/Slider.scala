
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control,ID}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Slider")
@js.native
class Slider() extends Control {
  def addAriaDescribedBy(vAriaDescribedBy: ID | Control): this.type = js.native
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def attachChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachLiveChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachLiveChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireChange(mParameters: Object): this.type = js.native
  def fireLiveChange(mParameters: Object): this.type = js.native
  def getAriaDescribedBy(): js.Array[ID] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getEditable(): Boolean = js.native
  def getEnabled(): Boolean = js.native
  def getHeight(): CSSSize = js.native
//  def getLabels(): /*TODO Type: 'string[]' not found.*/ = js.native
  def getMax(): Float = js.native
  def getMetadata(): Metadata = js.native
  def getMin(): Float = js.native
  def getSmallStepWidth(): Float = js.native
  def getStepLabels(): Boolean = js.native
  def getTotalUnits(): Int = js.native
  def getValue(): Float = js.native
  def getVertical(): Boolean = js.native
  def getWidth(): CSSSize = js.native
  def removeAllAriaDescribedBy(): js.Array[ID] = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAriaDescribedBy(vAriaDescribedBy: Int | ID | Control): ID = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def setEditable(bEditable: Boolean): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
//  def setLabels(sLabels: /*TODO Type: 'string[]' not found.*/): this.type = js.native
  def setMax(fMax: Float): this.type = js.native
  def setMin(fMin: Float): this.type = js.native
  def setSmallStepWidth(fSmallStepWidth: Float): this.type = js.native
  def setStepLabels(bStepLabels: Boolean): this.type = js.native
  def setTotalUnits(iTotalUnits: Int): this.type = js.native
  def setValue(fValue: Float): this.type = js.native
  def setVertical(bVertical: Boolean): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     