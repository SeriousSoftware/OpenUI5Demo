package com.sap.scala.facades.openui5.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait SideContentPosition extends js.Object

object SideContentPosition{
  @JSGlobal("sap.ui.layout.SideContentPosition.Begin")
  @js.native
  object Begin extends SideContentPosition

  @JSGlobal("sap.ui.layout.SideContentPosition.End")
  @js.native
  object End extends SideContentPosition
}

/* copy to Enum.scala
sealed trait SideContentPosition{
  private[ui] def toFacade: sap.ui.layout.SideContentPosition
}

object SideContentPosition {
  def fromFacade(s: ui.layout.SideContentPosition): SideContentPosition = s match {
    case ui.layout.SideContentPosition.Begin => SideContentPosition.Begin
    case ui.layout.SideContentPosition.End => SideContentPosition.End
   case _ =>
     throw new UnsupportedOperationException(s"Unknown SideContentPosition: $s")
  }
  
  object Begin extends SideContentPosition {
    override private[ui] def toFacade: ui.layout.SideContentPosition = ui.layout.SideContentPosition.Begin
  }

  object End extends SideContentPosition {
    override private[ui] def toFacade: ui.layout.SideContentPosition = ui.layout.SideContentPosition.End
  }

}
*/
