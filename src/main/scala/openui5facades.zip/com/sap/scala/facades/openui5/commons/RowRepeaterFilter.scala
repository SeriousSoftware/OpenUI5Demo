
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.RowRepeaterFilter")
@js.native
class RowRepeaterFilter() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getFilters(): Object = js.native
  def getIcon(): String = js.native
  def getMetadata(): Metadata = js.native
  def getText(): String = js.native
  def setFilters(oFilters: Object): this.type = js.native
  def setIcon(sIcon: String): this.type = js.native
  def setText(sText: String): this.type = js.native
}
     