
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{Table,PlanningCalendarView,PlanningCalendarRow}
import com.sap.scala.facades.openui5.core.{CSSSize,Control,ID}
import com.sap.scala.facades.openui5.unified.{DateTypeRange,GroupAppointmentsMode,CalendarAppointmentVisualization,CalendarLegend}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.PlanningCalendar")
@js.native
class PlanningCalendar() extends Control {
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def addRow(oRow: PlanningCalendarRow): this.type = js.native
  def addSpecialDate(oSpecialDate: DateTypeRange): this.type = js.native
  def addToolbarContent(oToolbarContent: Control): this.type = js.native
  def addView(oView: PlanningCalendarView): this.type = js.native
  def attachAppointmentSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachIntervalSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachRowHeaderClick(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachRowSelectionChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachStartDateChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachViewChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyRows(): this.type = js.native
  def destroySpecialDates(): this.type = js.native
  def destroyToolbarContent(): this.type = js.native
  def destroyViews(): this.type = js.native
  def detachAppointmentSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachIntervalSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachRowHeaderClick(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachRowSelectionChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachStartDateChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachViewChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAppointmentSelect(mParameters: Object): this.type = js.native
  def fireIntervalSelect(mParameters: Object): this.type = js.native
  def fireRowHeaderClick(mParameters: Object): this.type = js.native
  def fireRowSelectionChange(mParameters: Object): this.type = js.native
  def fireStartDateChange(mParameters: Object): this.type = js.native
  def fireViewChange(mParameters: Object): this.type = js.native
  def getAppointmentsReducedHeight(): Boolean = js.native
  def getAppointmentsVisualization(): CalendarAppointmentVisualization = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getGroupAppointmentsMode(): GroupAppointmentsMode = js.native
  def getHeight(): CSSSize = js.native
  def getLegend(): ID = js.native
  def getMaxDate(): Object = js.native
  def getMetadata(): Metadata = js.native
  def getMinDate(): Object = js.native
  def getNoDataText(): String = js.native
  def getRows(): js.Array[PlanningCalendarRow] = js.native
  def getSelectedRows(): js.Array[PlanningCalendarRow] = js.native
  def getShowEmptyIntervalHeaders(): Boolean = js.native
  def getShowIntervalHeaders(): Boolean = js.native
  def getShowRowHeaders(): Boolean = js.native
  def getSingleSelection(): Boolean = js.native
  def getSpecialDates(): js.Array[DateTypeRange] = js.native
  def getStartDate(): Object = js.native
  def getToolbarContent(): js.Array[Control] = js.native
  def getViewKey(): String = js.native
  def getViews(): js.Array[PlanningCalendarView] = js.native
  def getWidth(): CSSSize = js.native
  def indexOfRow(oRow: PlanningCalendarRow): Int = js.native
  def indexOfSpecialDate(oSpecialDate: DateTypeRange): Int = js.native
  def indexOfToolbarContent(oToolbarContent: Control): Int = js.native
  def indexOfView(oView: PlanningCalendarView): Int = js.native
  def insertRow(oRow: PlanningCalendarRow, iIndex: Int): this.type = js.native
  def insertSpecialDate(oSpecialDate: DateTypeRange, iIndex: Int): this.type = js.native
  def insertToolbarContent(oToolbarContent: Control, iIndex: Int): this.type = js.native
  def insertView(oView: PlanningCalendarView, iIndex: Int): this.type = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAllRows(): js.Array[PlanningCalendarRow] = js.native
  def removeAllSpecialDates(): js.Array[DateTypeRange] = js.native
  def removeAllToolbarContent(): js.Array[Control] = js.native
  def removeAllViews(): js.Array[PlanningCalendarView] = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def removeRow(vRow: Int | String | PlanningCalendarRow): PlanningCalendarRow = js.native
  def removeSpecialDate(vSpecialDate: Int | String | DateTypeRange): DateTypeRange = js.native
  def removeToolbarContent(vToolbarContent: Int | String | Control): Control = js.native
  def removeView(vView: Int | String | PlanningCalendarView): PlanningCalendarView = js.native
  def selectAllRows(bSelect: Boolean): this.type = js.native
  def setAppointmentsReducedHeight(bAppointmentsReducedHeight: Boolean): this.type = js.native
  def setAppointmentsVisualization(sAppointmentsVisualization: CalendarAppointmentVisualization): this.type = js.native
  def setGroupAppointmentsMode(sGroupAppointmentsMode: GroupAppointmentsMode): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setLegend(oLegend: ID | CalendarLegend): this.type = js.native
  def setMaxDate(oMaxDate: Object): this.type = js.native
  def setMinDate(oMinDate: Object): this.type = js.native
  def setNoDataText(sNoDataText: String): this.type = js.native
  def setShowEmptyIntervalHeaders(bShowEmptyIntervalHeaders: Boolean): this.type = js.native
  def setShowIntervalHeaders(bShowIntervalHeaders: Boolean): this.type = js.native
  def setShowRowHeaders(bShowRowHeaders: Boolean): this.type = js.native
  def setSingleSelection(bSingleSelection: Boolean): this.type = js.native
//  def setStartDate(oStartDate: /*TODO Type: 'Date' not found.*/): this.type = js.native
  def setViewKey(sViewKey: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     