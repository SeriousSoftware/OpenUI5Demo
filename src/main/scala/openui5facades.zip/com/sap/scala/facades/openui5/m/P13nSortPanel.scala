
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.P13nSortItem
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nSortPanel")
@js.native
class P13nSortPanel() extends P13nPanel {
  def addSortItem(oSortItem: P13nSortItem): this.type = js.native
  def attachAddSortItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachRemoveSortItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachUpdateSortItem(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindSortItems(oBindingInfo: Object): this.type = js.native
  def destroySortItems(): this.type = js.native
  def detachAddSortItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachRemoveSortItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachUpdateSortItem(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAddSortItem(mParameters: Object): this.type = js.native
  def fireRemoveSortItem(mParameters: Object): this.type = js.native
  def fireUpdateSortItem(mParameters: Object): this.type = js.native
  def getContainerQuery(): Boolean = js.native
  def getLayoutMode(): String = js.native
  def getMetadata(): Metadata = js.native
  def getSortItems(): js.Array[P13nSortItem] = js.native
  def indexOfSortItem(oSortItem: P13nSortItem): Int = js.native
  def insertSortItem(oSortItem: P13nSortItem, iIndex: Int): this.type = js.native
  def removeAllSortItems(): js.Array[P13nSortItem] = js.native
  def removeInvalidConditions(): Unit = js.native
  def removeSortItem(vSortItem: Int | String | P13nSortItem): P13nSortItem = js.native
  def removeValidationErrors(): Unit = js.native
  def setContainerQuery(bContainerQuery: Boolean): this.type = js.native
  def setLayoutMode(sLayoutMode: String): this.type = js.native
//  def setOperations(array: /*TODO Type: 'array' not found.*/): this.type = js.native
  def unbindSortItems(): this.type = js.native
  def validateConditions(): Boolean = js.native
}
     