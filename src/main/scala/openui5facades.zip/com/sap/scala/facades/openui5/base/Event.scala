
package com.sap.scala.facades.openui5.base

import com.sap.scala.facades.openui5.base.{Metadata,EventProvider}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.base.Event")
@js.native
class Event() extends Object {
  def cancelBubble(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getId(): String = js.native
  def getMetadata(): Metadata = js.native
//  def getParameter(sName: String): /*TODO Type: 'any' not found.*/ = js.native
//  def getParameters(): /*TODO Type: 'map' not found.*/ = js.native
  def getSource(): EventProvider = js.native
  def preventDefault(): Unit = js.native
}
     