
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,BarColor}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.ProgressIndicator")
@js.native
class ProgressIndicator() extends Control {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getBarColor(): BarColor = js.native
  def getDisplayValue(): String = js.native
  def getEnabled(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getPercentValue(): Int = js.native
  def getShowValue(): Boolean = js.native
  def getWidth(): CSSSize = js.native
  def setBarColor(sBarColor: BarColor): this.type = js.native
  def setDisplayValue(sDisplayValue: String): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setPercentValue(iPercentValue: Int): this.type = js.native
  def setShowValue(bShowValue: Boolean): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     