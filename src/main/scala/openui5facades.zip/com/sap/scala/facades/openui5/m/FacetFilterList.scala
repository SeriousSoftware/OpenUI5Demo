
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{FacetFilterListDataType,ListMode}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.FacetFilterList")
@js.native
class FacetFilterList() extends List {
  def attachListClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachListOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachListClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachListOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireListClose(mParameters: Object): this.type = js.native
  def fireListOpen(mParameters: Object): this.type = js.native
  def getActive(): Boolean = js.native
  def getAllCount(): Int = js.native
  def getDataType(): FacetFilterListDataType = js.native
  def getEnableCaseInsensitiveSearch(): Boolean = js.native
  def getKey(): String = js.native
  def getMetadata(): Metadata = js.native
  def getMultiSelect(): Boolean = js.native
  def getRetainListSequence(): Boolean = js.native
  def getSelectedKeys(): Object = js.native
  def getSequence(): Int = js.native
  def getShowRemoveFacetIcon(): Boolean = js.native
  def getTitle(): String = js.native
  def getWordWrap(): Boolean = js.native
  def removeSelectedKey(sKey: String, sText: String): Unit = js.native
  def removeSelectedKeys(): Unit = js.native
  def setActive(bActive: Boolean): this.type = js.native
  def setAllCount(iAllCount: Int): this.type = js.native
  def setDataType(sDataType: FacetFilterListDataType): this.type = js.native
  def setEnableCaseInsensitiveSearch(bEnableCaseInsensitiveSearch: Boolean): this.type = js.native
  def setKey(sKey: String): this.type = js.native
  def setMode(mode: ListMode): Unit = js.native
  def setMultiSelect(bMultiSelect: Boolean): this.type = js.native
  def setRetainListSequence(bRetainListSequence: Boolean): this.type = js.native
  def setSelectedKeys(oAKeys: Object): Unit = js.native
  def setSequence(iSequence: Int): this.type = js.native
  def setShowRemoveFacetIcon(bShowRemoveFacetIcon: Boolean): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setWordWrap(bWordWrap: Boolean): this.type = js.native
}
     