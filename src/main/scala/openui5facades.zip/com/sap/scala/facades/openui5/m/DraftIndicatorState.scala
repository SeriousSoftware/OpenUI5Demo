package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait DraftIndicatorState extends js.Object

object DraftIndicatorState{
  @JSGlobal("sap.m.DraftIndicatorState.Clear")
  @js.native
  object Clear extends DraftIndicatorState

  @JSGlobal("sap.m.DraftIndicatorState.Saved")
  @js.native
  object Saved extends DraftIndicatorState

  @JSGlobal("sap.m.DraftIndicatorState.Saving")
  @js.native
  object Saving extends DraftIndicatorState
}

/* copy to Enum.scala
sealed trait DraftIndicatorState{
  private[ui] def toFacade: sap.m.DraftIndicatorState
}

object DraftIndicatorState {
  def fromFacade(s: m.DraftIndicatorState): DraftIndicatorState = s match {
    case m.DraftIndicatorState.Clear => DraftIndicatorState.Clear
    case m.DraftIndicatorState.Saved => DraftIndicatorState.Saved
    case m.DraftIndicatorState.Saving => DraftIndicatorState.Saving
   case _ =>
     throw new UnsupportedOperationException(s"Unknown DraftIndicatorState: $s")
  }
  
  object Clear extends DraftIndicatorState {
    override private[ui] def toFacade: m.DraftIndicatorState = m.DraftIndicatorState.Clear
  }

  object Saved extends DraftIndicatorState {
    override private[ui] def toFacade: m.DraftIndicatorState = m.DraftIndicatorState.Saved
  }

  object Saving extends DraftIndicatorState {
    override private[ui] def toFacade: m.DraftIndicatorState = m.DraftIndicatorState.Saving
  }

}
*/
