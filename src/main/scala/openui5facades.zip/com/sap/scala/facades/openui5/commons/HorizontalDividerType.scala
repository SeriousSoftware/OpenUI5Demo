package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait HorizontalDividerType extends js.Object

object HorizontalDividerType{
  @JSGlobal("sap.ui.commons.HorizontalDividerType.Area")
  @js.native
  object Area extends HorizontalDividerType

  @JSGlobal("sap.ui.commons.HorizontalDividerType.Page")
  @js.native
  object Page extends HorizontalDividerType
}

/* copy to Enum.scala
sealed trait HorizontalDividerType{
  private[ui] def toFacade: sap.ui.commons.HorizontalDividerType
}

object HorizontalDividerType {
  def fromFacade(s: ui.commons.HorizontalDividerType): HorizontalDividerType = s match {
    case ui.commons.HorizontalDividerType.Area => HorizontalDividerType.Area
    case ui.commons.HorizontalDividerType.Page => HorizontalDividerType.Page
   case _ =>
     throw new UnsupportedOperationException(s"Unknown HorizontalDividerType: $s")
  }
  
  object Area extends HorizontalDividerType {
    override private[ui] def toFacade: ui.commons.HorizontalDividerType = ui.commons.HorizontalDividerType.Area
  }

  object Page extends HorizontalDividerType {
    override private[ui] def toFacade: ui.commons.HorizontalDividerType = ui.commons.HorizontalDividerType.Page
  }

}
*/
