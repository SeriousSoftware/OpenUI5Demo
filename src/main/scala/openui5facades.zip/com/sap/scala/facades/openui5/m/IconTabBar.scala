
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{IconTabHeader,IconTab,IconTabHeaderMode,BackgroundDesign}
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.IconTabBar")
@js.native
class IconTabBar() extends Control {
  def addContent(oContent: Control): this.type = js.native
  def addItem(oItem: IconTab): this.type = js.native
  def attachExpand(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindAggregation(sAggregationName: String, oBindingInfo: Object): this.type = js.native
  def destroyContent(): this.type = js.native
  def destroyItems(): this.type = js.native
  def detachExpand(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireExpand(mParameters: Object): this.type = js.native
  def fireSelect(mParameters: Object): this.type = js.native
  def getApplyContentPadding(): Boolean = js.native
  def getBackgroundDesign(): BackgroundDesign = js.native
  def getContent(): js.Array[Control] = js.native
  def getEnableTabReordering(): Boolean = js.native
  def getExpandable(): Boolean = js.native
  def getExpanded(): Boolean = js.native
  def getHeaderBackgroundDesign(): BackgroundDesign = js.native
  def getHeaderMode(): IconTabHeaderMode = js.native
  def getItems(): js.Array[IconTab] = js.native
  def getMetadata(): Metadata = js.native
  def getSelectedKey(): String = js.native
  def getShowOverflowSelectList(): Boolean = js.native
  def getShowSelection(): Boolean = js.native
  def getStretchContentHeight(): Boolean = js.native
  def getUpperCase(): Boolean = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def indexOfItem(oItem: IconTab): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def insertItem(oItem: IconTab, iIndex: Int): this.type = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeAllItems(): js.Array[IconTab] = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def removeItem(vItem: Int | String | IconTab): IconTab = js.native
  def setApplyContentPadding(bApplyContentPadding: Boolean): this.type = js.native
  def setBackgroundDesign(sBackgroundDesign: BackgroundDesign): this.type = js.native
  def setEnableTabReordering(value: Boolean): this.type = js.native
  def setExpandable(bExpandable: Boolean): this.type = js.native
  def setExpanded(bExpanded: Boolean): this.type = js.native
  def setHeaderBackgroundDesign(headerBackgroundDesign: BackgroundDesign): this.type = js.native
  def setHeaderMode(mode: IconTabHeaderMode): this.type = js.native
  def setSelectedKey(sValue: String): this.type = js.native
  def setShowOverflowSelectList(value: Boolean): this.type = js.native
  def setShowSelection(bShowSelection: Boolean): this.type = js.native
  def setStretchContentHeight(bStretchContentHeight: Boolean): this.type = js.native
  def setUpperCase(bUpperCase: Boolean): this.type = js.native
}
     