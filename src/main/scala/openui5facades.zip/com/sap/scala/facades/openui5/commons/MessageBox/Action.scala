package com.sap.scala.facades.openui5.commons.MessageBox

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Action extends js.Object

object Action{
  @JSGlobal("sap.ui.commons.MessageBox.Action.ABORT")
  @js.native
  object ABORT extends Action

  @JSGlobal("sap.ui.commons.MessageBox.Action.CANCEL")
  @js.native
  object CANCEL extends Action

  @JSGlobal("sap.ui.commons.MessageBox.Action.CLOSE")
  @js.native
  object CLOSE extends Action

  @JSGlobal("sap.ui.commons.MessageBox.Action.IGNORE")
  @js.native
  object IGNORE extends Action

  @JSGlobal("sap.ui.commons.MessageBox.Action.NO")
  @js.native
  object NO extends Action

  @JSGlobal("sap.ui.commons.MessageBox.Action.OK")
  @js.native
  object OK extends Action

  @JSGlobal("sap.ui.commons.MessageBox.Action.RETRY")
  @js.native
  object RETRY extends Action

  @JSGlobal("sap.ui.commons.MessageBox.Action.YES")
  @js.native
  object YES extends Action
}

/* copy to Enum.scala
sealed trait Action{
  private[ui] def toFacade: sap.ui.commons.MessageBox.Action
}

object Action {
  def fromFacade(s: ui.commons.MessageBox.Action): Action = s match {
    case ui.commons.MessageBox.Action.ABORT => Action.ABORT
    case ui.commons.MessageBox.Action.CANCEL => Action.CANCEL
    case ui.commons.MessageBox.Action.CLOSE => Action.CLOSE
    case ui.commons.MessageBox.Action.IGNORE => Action.IGNORE
    case ui.commons.MessageBox.Action.NO => Action.NO
    case ui.commons.MessageBox.Action.OK => Action.OK
    case ui.commons.MessageBox.Action.RETRY => Action.RETRY
    case ui.commons.MessageBox.Action.YES => Action.YES
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Action: $s")
  }
  
  object ABORT extends Action {
    override private[ui] def toFacade: ui.commons.MessageBox.Action = ui.commons.MessageBox.Action.ABORT
  }

  object CANCEL extends Action {
    override private[ui] def toFacade: ui.commons.MessageBox.Action = ui.commons.MessageBox.Action.CANCEL
  }

  object CLOSE extends Action {
    override private[ui] def toFacade: ui.commons.MessageBox.Action = ui.commons.MessageBox.Action.CLOSE
  }

  object IGNORE extends Action {
    override private[ui] def toFacade: ui.commons.MessageBox.Action = ui.commons.MessageBox.Action.IGNORE
  }

  object NO extends Action {
    override private[ui] def toFacade: ui.commons.MessageBox.Action = ui.commons.MessageBox.Action.NO
  }

  object OK extends Action {
    override private[ui] def toFacade: ui.commons.MessageBox.Action = ui.commons.MessageBox.Action.OK
  }

  object RETRY extends Action {
    override private[ui] def toFacade: ui.commons.MessageBox.Action = ui.commons.MessageBox.Action.RETRY
  }

  object YES extends Action {
    override private[ui] def toFacade: ui.commons.MessageBox.Action = ui.commons.MessageBox.Action.YES
  }

}
*/
