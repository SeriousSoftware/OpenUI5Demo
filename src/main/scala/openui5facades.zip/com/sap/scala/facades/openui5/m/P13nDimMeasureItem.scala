
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nDimMeasureItem")
@js.native
class P13nDimMeasureItem() extends Item {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getColumnKey(): String = js.native
  def getIndex(): Int = js.native
  def getMetadata(): Metadata = js.native
  def getRole(): String = js.native
  def getVisible(): Boolean = js.native
  def setColumnKey(sColumnKey: String): this.type = js.native
  def setIndex(iIndex: Int): this.type = js.native
  def setRole(sRole: String): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     