
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.IconTabBarSelectList
import com.sap.scala.facades.openui5.core.{URI,RenderManager}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.IconTabSeparator")
@js.native
class IconTabSeparator() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getIcon(): URI = js.native
  def getIconDensityAware(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getVisible(): Boolean = js.native
  def render(rm: RenderManager): Unit = js.native
  def renderInSelectList(rm: RenderManager, selectList: IconTabBarSelectList): Unit = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setIconDensityAware(bIconDensityAware: Boolean): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     