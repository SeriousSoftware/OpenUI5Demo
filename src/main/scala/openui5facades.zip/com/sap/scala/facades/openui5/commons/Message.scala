
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.commons.MessageType


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Message")
@js.native
class Message() extends Control {
  def bindDetails(fnCallBack: js.Function1[Event[EventProps], Unit]): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAssociatedElementId(): String = js.native
  def getDesign(): String = js.native
  def getMetadata(): Metadata = js.native
  def getText(): String = js.native
  def getType(): MessageType = js.native
  def setAssociatedElementId(sAssociatedElementId: String): this.type = js.native
  def setDesign(sDesign: String): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setType(sType: MessageType): this.type = js.native
}
     