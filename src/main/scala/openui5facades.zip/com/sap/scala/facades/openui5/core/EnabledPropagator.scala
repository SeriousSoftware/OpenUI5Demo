
package com.sap.scala.facades.openui5.core




import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.EnabledPropagator")
@js.native
class EnabledPropagator()  {

}
     