
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.P13nItem


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nPanel")
@js.native
class P13nPanel() extends Control {
  def addItem(oItem: P13nItem): this.type = js.native
  def attachBeforeNavigationTo(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def beforeNavigationTo(): Unit = js.native
  def bindItems(oBindingInfo: Object): this.type = js.native
  def destroyItems(): this.type = js.native
  def detachBeforeNavigationTo(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireBeforeNavigationTo(mParameters: Object): this.type = js.native
  def getChangeNotifier(): Object = js.native
  def getItems(): js.Array[P13nItem] = js.native
  def getMetadata(): Metadata = js.native
  def getOkPayload(): Object = js.native
  def getResetPayload(): Unit = js.native
  def getTitle(): String = js.native
  def getTitleLarge(): String = js.native
  def getType(): String = js.native
  def getValidationExecutor(): Object = js.native
  def getValidationListener(): Object = js.native
  def getVerticalScrolling(): Boolean = js.native
  def indexOfItem(oItem: P13nItem): Int = js.native
  def insertItem(oItem: P13nItem, iIndex: Int): this.type = js.native
  def onAfterNavigationFrom(): Unit = js.native
  def onBeforeNavigationFrom(): Boolean = js.native
  def removeAllItems(): js.Array[P13nItem] = js.native
  def removeItem(vItem: Int | String | P13nItem): P13nItem = js.native
  def setChangeNotifier(oChangeNotifier: Object): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setTitleLarge(sTitleLarge: String): this.type = js.native
  def setType(sType: String): this.type = js.native
  def setValidationExecutor(oValidationExecutor: Object): this.type = js.native
  def setValidationListener(oValidationListener: Object): this.type = js.native
  def setVerticalScrolling(bVerticalScrolling: Boolean): this.type = js.native
  def unbindItems(): this.type = js.native
}
     