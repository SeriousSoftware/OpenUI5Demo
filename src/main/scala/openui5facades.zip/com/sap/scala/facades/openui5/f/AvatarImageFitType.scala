package com.sap.scala.facades.openui5.f

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait AvatarImageFitType extends js.Object

object AvatarImageFitType{
  @JSGlobal("sap.f.AvatarImageFitType.Contain")
  @js.native
  object Contain extends AvatarImageFitType

  @JSGlobal("sap.f.AvatarImageFitType.Cover")
  @js.native
  object Cover extends AvatarImageFitType
}

/* copy to Enum.scala
sealed trait AvatarImageFitType{
  private[ui] def toFacade: sap.f.AvatarImageFitType
}

object AvatarImageFitType {
  def fromFacade(s: f.AvatarImageFitType): AvatarImageFitType = s match {
    case f.AvatarImageFitType.Contain => AvatarImageFitType.Contain
    case f.AvatarImageFitType.Cover => AvatarImageFitType.Cover
   case _ =>
     throw new UnsupportedOperationException(s"Unknown AvatarImageFitType: $s")
  }
  
  object Contain extends AvatarImageFitType {
    override private[ui] def toFacade: f.AvatarImageFitType = f.AvatarImageFitType.Contain
  }

  object Cover extends AvatarImageFitType {
    override private[ui] def toFacade: f.AvatarImageFitType = f.AvatarImageFitType.Cover
  }

}
*/
