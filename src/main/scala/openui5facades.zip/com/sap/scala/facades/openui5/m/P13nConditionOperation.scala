package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait P13nConditionOperation extends js.Object

object P13nConditionOperation{
  @JSGlobal("sap.m.P13nConditionOperation.Ascending")
  @js.native
  object Ascending extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.Average")
  @js.native
  object Average extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.BT")
  @js.native
  object BT extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.Contains")
  @js.native
  object Contains extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.Descending")
  @js.native
  object Descending extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.Empty")
  @js.native
  object Empty extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.EndsWith")
  @js.native
  object EndsWith extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.EQ")
  @js.native
  object EQ extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.GE")
  @js.native
  object GE extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.GroupAscending")
  @js.native
  object GroupAscending extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.GroupDescending")
  @js.native
  object GroupDescending extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.GT")
  @js.native
  object GT extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.Initial")
  @js.native
  object Initial extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.LE")
  @js.native
  object LE extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.LT")
  @js.native
  object LT extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.Maximum")
  @js.native
  object Maximum extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.Minimum")
  @js.native
  object Minimum extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.NotEmpty")
  @js.native
  object NotEmpty extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.StartsWith")
  @js.native
  object StartsWith extends P13nConditionOperation

  @JSGlobal("sap.m.P13nConditionOperation.Total")
  @js.native
  object Total extends P13nConditionOperation
}

/* copy to Enum.scala
sealed trait P13nConditionOperation{
  private[ui] def toFacade: sap.m.P13nConditionOperation
}

object P13nConditionOperation {
  def fromFacade(s: m.P13nConditionOperation): P13nConditionOperation = s match {
    case m.P13nConditionOperation.Ascending => P13nConditionOperation.Ascending
    case m.P13nConditionOperation.Average => P13nConditionOperation.Average
    case m.P13nConditionOperation.BT => P13nConditionOperation.BT
    case m.P13nConditionOperation.Contains => P13nConditionOperation.Contains
    case m.P13nConditionOperation.Descending => P13nConditionOperation.Descending
    case m.P13nConditionOperation.Empty => P13nConditionOperation.Empty
    case m.P13nConditionOperation.EndsWith => P13nConditionOperation.EndsWith
    case m.P13nConditionOperation.EQ => P13nConditionOperation.EQ
    case m.P13nConditionOperation.GE => P13nConditionOperation.GE
    case m.P13nConditionOperation.GroupAscending => P13nConditionOperation.GroupAscending
    case m.P13nConditionOperation.GroupDescending => P13nConditionOperation.GroupDescending
    case m.P13nConditionOperation.GT => P13nConditionOperation.GT
    case m.P13nConditionOperation.Initial => P13nConditionOperation.Initial
    case m.P13nConditionOperation.LE => P13nConditionOperation.LE
    case m.P13nConditionOperation.LT => P13nConditionOperation.LT
    case m.P13nConditionOperation.Maximum => P13nConditionOperation.Maximum
    case m.P13nConditionOperation.Minimum => P13nConditionOperation.Minimum
    case m.P13nConditionOperation.NotEmpty => P13nConditionOperation.NotEmpty
    case m.P13nConditionOperation.StartsWith => P13nConditionOperation.StartsWith
    case m.P13nConditionOperation.Total => P13nConditionOperation.Total
   case _ =>
     throw new UnsupportedOperationException(s"Unknown P13nConditionOperation: $s")
  }
  
  object Ascending extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.Ascending
  }

  object Average extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.Average
  }

  object BT extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.BT
  }

  object Contains extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.Contains
  }

  object Descending extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.Descending
  }

  object Empty extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.Empty
  }

  object EndsWith extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.EndsWith
  }

  object EQ extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.EQ
  }

  object GE extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.GE
  }

  object GroupAscending extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.GroupAscending
  }

  object GroupDescending extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.GroupDescending
  }

  object GT extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.GT
  }

  object Initial extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.Initial
  }

  object LE extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.LE
  }

  object LT extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.LT
  }

  object Maximum extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.Maximum
  }

  object Minimum extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.Minimum
  }

  object NotEmpty extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.NotEmpty
  }

  object StartsWith extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.StartsWith
  }

  object Total extends P13nConditionOperation {
    override private[ui] def toFacade: m.P13nConditionOperation = m.P13nConditionOperation.Total
  }

}
*/
