
package com.sap.scala.facades.openui5.core.service

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.service.Service")
@js.native
class Service() extends Object {
  def destroy(): Unit = js.native
  def exit(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getContext(): Object = js.native
  def getInterface(): Object = js.native
  def getMetadata(): Metadata = js.native
  def init(): Unit = js.native
}
     