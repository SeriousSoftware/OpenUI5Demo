
package com.sap.scala.facades.openui5.commons.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.layout.PositionContainer")
@js.native
class PositionContainer() extends Element {
  def destroyControl(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getBottom(): CSSSize = js.native
  def getCenterHorizontally(): Boolean = js.native
  def getCenterVertically(): Boolean = js.native
  def getControl(): Control = js.native
  def getLeft(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getRight(): CSSSize = js.native
  def getTop(): CSSSize = js.native
  def setBottom(sBottom: CSSSize): this.type = js.native
  def setCenterHorizontally(bCenterHorizontally: Boolean): this.type = js.native
  def setCenterVertically(bCenterVertically: Boolean): this.type = js.native
  def setControl(oControl: Control): this.type = js.native
  def setLeft(sLeft: CSSSize): this.type = js.native
  def setRight(sRight: CSSSize): this.type = js.native
  def setTop(sTop: CSSSize): this.type = js.native
  def updatePosition(oPos: Object): Unit = js.native
}
     