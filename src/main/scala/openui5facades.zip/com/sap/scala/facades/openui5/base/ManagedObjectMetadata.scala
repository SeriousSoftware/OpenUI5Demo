
package com.sap.scala.facades.openui5.base




import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.base.ManagedObjectMetadata")
@js.native
class ManagedObjectMetadata()  {
//  def getAggregation(sName: String): /*TODO Type: 'Object' not found.*/ = js.native
//  def getAggregations(): /*TODO Type: 'map' not found.*/ = js.native
//  def getAllAggregations(): /*TODO Type: 'map' not found.*/ = js.native
//  def getAllAssociations(): /*TODO Type: 'map' not found.*/ = js.native
//  def getAllEvents(): /*TODO Type: 'map' not found.*/ = js.native
//  def getAllPrivateAggregations(): /*TODO Type: 'map' not found.*/ = js.native
//  def getAllProperties(): /*TODO Type: 'map' not found.*/ = js.native
//  def getAssociation(sName: String): /*TODO Type: 'Object' not found.*/ = js.native
//  def getAssociations(): /*TODO Type: 'map' not found.*/ = js.native
//  def getEvent(sName: String): /*TODO Type: 'Object' not found.*/ = js.native
//  def getEvents(): /*TODO Type: 'map' not found.*/ = js.native
  def getLibraryName(): String = js.native
  def getManagedAggregation(sAggregationName: String): Object = js.native
//  def getProperties(): /*TODO Type: 'map' not found.*/ = js.native
//  def getProperty(sName: String): /*TODO Type: 'Object' not found.*/ = js.native
//  def getPropertyDefaults(): /*TODO Type: 'map' not found.*/ = js.native
//  def getPropertyLikeSetting(sName: String): /*TODO Type: 'Object' not found.*/ = js.native
  def hasAggregation(sName: String): Boolean = js.native
  def hasAssociation(sName: String): Boolean = js.native
  def hasEvent(sName: String): Boolean = js.native
  def hasProperty(sName: String): Boolean = js.native
  def isGeneratedId(sId: String): Boolean = js.native
//  def loadDesignTime(): /*TODO Type: 'Promise' not found.*/ = js.native
  def uid(): String = js.native
  def uid(sIdPrefix: String): String = js.native
}
     