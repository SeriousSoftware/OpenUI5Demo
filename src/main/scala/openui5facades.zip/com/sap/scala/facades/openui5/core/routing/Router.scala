
package com.sap.scala.facades.openui5.core.routing

import com.sap.scala.facades.openui5.core.mvc.View
import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.routing.{Targets,Route,Views}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.routing.Router")
@js.native
class Router() extends EventProvider {
  def addRoute(oConfig: Object, oParent: Route): Unit = js.native
  def attachBeforeRouteMatched(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBypassed(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachRouteMatched(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachRoutePatternMatched(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachTitleChanged(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachViewCreated(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroy(): this.type = js.native
  def detachBeforeRouteMatched(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBypassed(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachRouteMatched(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachRoutePatternMatched(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachTitleChanged(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachViewCreated(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireBeforeRouteMatched(mArguments: Object): this.type = js.native
  def fireBypassed(mArguments: Object): this.type = js.native
  def fireRouteMatched(mArguments: Object): this.type = js.native
  def fireRoutePatternMatched(mArguments: Object): this.type = js.native
  def fireViewCreated(mArguments: Object): this.type = js.native
  def getMetadata(): Metadata = js.native
  def getRoute(sName: String): Route = js.native
  def getRouter(sName: String): this.type = js.native
//  def getTargets(): Targets | /*TODO Type: 'undefined' not found.*/ = js.native
//  def getTitleHistory(): /*TODO Type: 'array' not found.*/ = js.native
  def getURL(sName: String, oParameters: Object): String = js.native
  def getView(sViewName: String, sViewType: String, sViewId: String): View = js.native
  def getViews(): Views = js.native
  def initialize(bIgnoreInitialHash: Boolean): this.type = js.native
  def navTo(sName: String, oParameters: Object, bReplace: Boolean): this.type = js.native
  def parse(sNewHash: String): Unit = js.native
  def register(sName: String): Unit = js.native
  def setView(sViewName: String, oView: View): this.type = js.native
  def stop(): this.type = js.native
}
     