
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.AccordionSection")
@js.native
class AccordionSection() extends Element {
  def addContent(oContent: Control): this.type = js.native
  def attachScroll(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyContent(): this.type = js.native
  def detachScroll(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireScroll(mParameters: Object): this.type = js.native
  def getCollapsed(): Boolean = js.native
  def getContent(): js.Array[Control] = js.native
  def getEnabled(): Boolean = js.native
  def getMaxHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getTitle(): String = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def setCollapsed(bCollapsed: Boolean): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setMaxHeight(sMaxHeight: CSSSize): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
}
     