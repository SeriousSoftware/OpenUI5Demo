package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait TextViewDesign extends js.Object

object TextViewDesign{
  @JSGlobal("sap.ui.commons.TextViewDesign.Bold")
  @js.native
  object Bold extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.H1")
  @js.native
  object H1 extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.H2")
  @js.native
  object H2 extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.H3")
  @js.native
  object H3 extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.H4")
  @js.native
  object H4 extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.H5")
  @js.native
  object H5 extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.H6")
  @js.native
  object H6 extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.Italic")
  @js.native
  object Italic extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.Monospace")
  @js.native
  object Monospace extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.Small")
  @js.native
  object Small extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.Standard")
  @js.native
  object Standard extends TextViewDesign

  @JSGlobal("sap.ui.commons.TextViewDesign.Underline")
  @js.native
  object Underline extends TextViewDesign
}

/* copy to Enum.scala
sealed trait TextViewDesign{
  private[ui] def toFacade: sap.ui.commons.TextViewDesign
}

object TextViewDesign {
  def fromFacade(s: ui.commons.TextViewDesign): TextViewDesign = s match {
    case ui.commons.TextViewDesign.Bold => TextViewDesign.Bold
    case ui.commons.TextViewDesign.H1 => TextViewDesign.H1
    case ui.commons.TextViewDesign.H2 => TextViewDesign.H2
    case ui.commons.TextViewDesign.H3 => TextViewDesign.H3
    case ui.commons.TextViewDesign.H4 => TextViewDesign.H4
    case ui.commons.TextViewDesign.H5 => TextViewDesign.H5
    case ui.commons.TextViewDesign.H6 => TextViewDesign.H6
    case ui.commons.TextViewDesign.Italic => TextViewDesign.Italic
    case ui.commons.TextViewDesign.Monospace => TextViewDesign.Monospace
    case ui.commons.TextViewDesign.Small => TextViewDesign.Small
    case ui.commons.TextViewDesign.Standard => TextViewDesign.Standard
    case ui.commons.TextViewDesign.Underline => TextViewDesign.Underline
   case _ =>
     throw new UnsupportedOperationException(s"Unknown TextViewDesign: $s")
  }
  
  object Bold extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.Bold
  }

  object H1 extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.H1
  }

  object H2 extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.H2
  }

  object H3 extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.H3
  }

  object H4 extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.H4
  }

  object H5 extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.H5
  }

  object H6 extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.H6
  }

  object Italic extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.Italic
  }

  object Monospace extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.Monospace
  }

  object Small extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.Small
  }

  object Standard extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.Standard
  }

  object Underline extends TextViewDesign {
    override private[ui] def toFacade: ui.commons.TextViewDesign = ui.commons.TextViewDesign.Underline
  }

}
*/
