package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait IconTabFilterDesign extends js.Object

object IconTabFilterDesign{
  @JSGlobal("sap.m.IconTabFilterDesign.Horizontal")
  @js.native
  object Horizontal extends IconTabFilterDesign

  @JSGlobal("sap.m.IconTabFilterDesign.Vertical")
  @js.native
  object Vertical extends IconTabFilterDesign
}

/* copy to Enum.scala
sealed trait IconTabFilterDesign{
  private[ui] def toFacade: sap.m.IconTabFilterDesign
}

object IconTabFilterDesign {
  def fromFacade(s: m.IconTabFilterDesign): IconTabFilterDesign = s match {
    case m.IconTabFilterDesign.Horizontal => IconTabFilterDesign.Horizontal
    case m.IconTabFilterDesign.Vertical => IconTabFilterDesign.Vertical
   case _ =>
     throw new UnsupportedOperationException(s"Unknown IconTabFilterDesign: $s")
  }
  
  object Horizontal extends IconTabFilterDesign {
    override private[ui] def toFacade: m.IconTabFilterDesign = m.IconTabFilterDesign.Horizontal
  }

  object Vertical extends IconTabFilterDesign {
    override private[ui] def toFacade: m.IconTabFilterDesign = m.IconTabFilterDesign.Vertical
  }

}
*/
