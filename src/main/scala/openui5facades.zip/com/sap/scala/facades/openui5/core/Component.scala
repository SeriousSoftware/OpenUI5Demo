
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.ManagedObject
import com.sap.scala.facades.openui5.core.{Manifest,ComponentMetadata,EventBus}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.Component")
@js.native
class Component() extends ManagedObject {
//  def createComponent(vUsage: String | Object): this.type | /*TODO Type: 'Promise' not found.*/ = js.native
  def exit(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getComponentData(): Object = js.native
  def getEventBus(): EventBus = js.native
  def getInterface(): Unit = js.native
  def getManifest(): Object = js.native
//  def getManifestEntry(sKey: String): /*TODO Type: 'any' not found.*/ | /*TODO Type: 'null' not found.*/ = js.native
  def getManifestObject(): Manifest = js.native
  def getMetadata(): ComponentMetadata = js.native
  def getMetadata(): ComponentMetadata = js.native
  def getOwnerComponentFor(oObject: ManagedObject): this.type = js.native
  def getOwnerIdFor(oObject: ManagedObject): String = js.native
//  def getService(sLocalServiceAlias: String): /*TODO Type: 'Promise' not found.*/ = js.native
  def init(): Unit = js.native
  def onConfigChange(sConfigKey: String): Unit = js.native
  def onWindowBeforeUnload(): String = js.native
//  def onWindowError(sMessage: String, sFile: String, iLine: /*TODO Type: 'number' not found.*/): Unit = js.native
  def onWindowUnload(): Unit = js.native
//  def runAsOwner(fn: js.Function1[Event[EventProps], Unit]): /*TODO Type: 'any' not found.*/ = js.native
}
     