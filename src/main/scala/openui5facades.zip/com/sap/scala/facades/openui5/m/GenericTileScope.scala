package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait GenericTileScope extends js.Object

object GenericTileScope{
  @JSGlobal("sap.m.GenericTileScope.Actions")
  @js.native
  object Actions extends GenericTileScope

  @JSGlobal("sap.m.GenericTileScope.Display")
  @js.native
  object Display extends GenericTileScope
}

/* copy to Enum.scala
sealed trait GenericTileScope{
  private[ui] def toFacade: sap.m.GenericTileScope
}

object GenericTileScope {
  def fromFacade(s: m.GenericTileScope): GenericTileScope = s match {
    case m.GenericTileScope.Actions => GenericTileScope.Actions
    case m.GenericTileScope.Display => GenericTileScope.Display
   case _ =>
     throw new UnsupportedOperationException(s"Unknown GenericTileScope: $s")
  }
  
  object Actions extends GenericTileScope {
    override private[ui] def toFacade: m.GenericTileScope = m.GenericTileScope.Actions
  }

  object Display extends GenericTileScope {
    override private[ui] def toFacade: m.GenericTileScope = m.GenericTileScope.Display
  }

}
*/
