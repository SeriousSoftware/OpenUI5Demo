
package com.sap.scala.facades.openui5.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.Control
import com.sap.scala.facades.openui5.layout.{SideContentVisibility,SideContentFallDown,SideContentPosition}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.layout.DynamicSideContent")
@js.native
class DynamicSideContent() extends Control {
  def addMainContent(oControl: Object): this.type = js.native
  def addSideContent(oControl: Object): this.type = js.native
  def attachBreakpointChanged(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyMainContent(): this.type = js.native
  def destroySideContent(): this.type = js.native
  def detachBreakpointChanged(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireBreakpointChanged(mParameters: Object): this.type = js.native
  def getContainerQuery(): Boolean = js.native
//  def getCurrentBreakpoint(): /*TODO Type: 'String' not found.*/ = js.native
  def getEqualSplit(): Boolean = js.native
  def getMainContent(): js.Array[Control] = js.native
  def getMetadata(): Metadata = js.native
  def getShowMainContent(): Boolean = js.native
  def getShowSideContent(): Boolean = js.native
  def getSideContent(): js.Array[Control] = js.native
  def getSideContentFallDown(): SideContentFallDown = js.native
  def getSideContentPosition(): SideContentPosition = js.native
  def getSideContentVisibility(): SideContentVisibility = js.native
  def indexOfMainContent(oMainContent: Control): Int = js.native
  def indexOfSideContent(oSideContent: Control): Int = js.native
  def insertMainContent(oMainContent: Control, iIndex: Int): this.type = js.native
  def insertSideContent(oSideContent: Control, iIndex: Int): this.type = js.native
  def removeAllMainContent(): js.Array[Control] = js.native
  def removeAllSideContent(): js.Array[Control] = js.native
  def removeMainContent(vMainContent: Int | String | Control): Control = js.native
  def removeSideContent(vSideContent: Int | String | Control): Control = js.native
  def setContainerQuery(bContainerQuery: Boolean): this.type = js.native
  def setEqualSplit(bState: Boolean): this.type = js.native
  def setShowMainContent(bVisible: Boolean, bSuppressVisualUpdate: Boolean): this.type = js.native
  def setShowSideContent(bVisible: Boolean, bSuppressVisualUpdate: Boolean): this.type = js.native
  def setSideContentFallDown(sSideContentFallDown: SideContentFallDown): this.type = js.native
  def setSideContentPosition(sSideContentPosition: SideContentPosition): this.type = js.native
  def setSideContentVisibility(sVisibility: SideContentVisibility, bSuppressVisualUpdate: Boolean): this.type = js.native
  def toggle(): this.type = js.native
}
     