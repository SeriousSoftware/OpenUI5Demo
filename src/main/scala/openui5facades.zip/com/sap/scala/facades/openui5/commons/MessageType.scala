package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait MessageType extends js.Object

object MessageType{
  @JSGlobal("sap.ui.commons.MessageType.Error")
  @js.native
  object Error extends MessageType

  @JSGlobal("sap.ui.commons.MessageType.Success")
  @js.native
  object Success extends MessageType

  @JSGlobal("sap.ui.commons.MessageType.Warning")
  @js.native
  object Warning extends MessageType
}

/* copy to Enum.scala
sealed trait MessageType{
  private[ui] def toFacade: sap.ui.commons.MessageType
}

object MessageType {
  def fromFacade(s: ui.commons.MessageType): MessageType = s match {
    case ui.commons.MessageType.Error => MessageType.Error
    case ui.commons.MessageType.Success => MessageType.Success
    case ui.commons.MessageType.Warning => MessageType.Warning
   case _ =>
     throw new UnsupportedOperationException(s"Unknown MessageType: $s")
  }
  
  object Error extends MessageType {
    override private[ui] def toFacade: ui.commons.MessageType = ui.commons.MessageType.Error
  }

  object Success extends MessageType {
    override private[ui] def toFacade: ui.commons.MessageType = ui.commons.MessageType.Success
  }

  object Warning extends MessageType {
    override private[ui] def toFacade: ui.commons.MessageType = ui.commons.MessageType.Warning
  }

}
*/
