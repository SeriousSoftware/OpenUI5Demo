package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait LightBoxLoadingStates extends js.Object

object LightBoxLoadingStates{
  @JSGlobal("sap.m.LightBoxLoadingStates.Error")
  @js.native
  object Error extends LightBoxLoadingStates

  @JSGlobal("sap.m.LightBoxLoadingStates.Loaded")
  @js.native
  object Loaded extends LightBoxLoadingStates

  @JSGlobal("sap.m.LightBoxLoadingStates.Loading")
  @js.native
  object Loading extends LightBoxLoadingStates

  @JSGlobal("sap.m.LightBoxLoadingStates.TimeOutError")
  @js.native
  object TimeOutError extends LightBoxLoadingStates
}

/* copy to Enum.scala
sealed trait LightBoxLoadingStates{
  private[ui] def toFacade: sap.m.LightBoxLoadingStates
}

object LightBoxLoadingStates {
  def fromFacade(s: m.LightBoxLoadingStates): LightBoxLoadingStates = s match {
    case m.LightBoxLoadingStates.Error => LightBoxLoadingStates.Error
    case m.LightBoxLoadingStates.Loaded => LightBoxLoadingStates.Loaded
    case m.LightBoxLoadingStates.Loading => LightBoxLoadingStates.Loading
    case m.LightBoxLoadingStates.TimeOutError => LightBoxLoadingStates.TimeOutError
   case _ =>
     throw new UnsupportedOperationException(s"Unknown LightBoxLoadingStates: $s")
  }
  
  object Error extends LightBoxLoadingStates {
    override private[ui] def toFacade: m.LightBoxLoadingStates = m.LightBoxLoadingStates.Error
  }

  object Loaded extends LightBoxLoadingStates {
    override private[ui] def toFacade: m.LightBoxLoadingStates = m.LightBoxLoadingStates.Loaded
  }

  object Loading extends LightBoxLoadingStates {
    override private[ui] def toFacade: m.LightBoxLoadingStates = m.LightBoxLoadingStates.Loading
  }

  object TimeOutError extends LightBoxLoadingStates {
    override private[ui] def toFacade: m.LightBoxLoadingStates = m.LightBoxLoadingStates.TimeOutError
  }

}
*/
