
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.URI


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.ApplicationHeader")
@js.native
class ApplicationHeader() extends Control {
  def attachLogoff(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachLogoff(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireLogoff(mParameters: Object): this.type = js.native
  def getDisplayLogoff(): Boolean = js.native
  def getDisplayWelcome(): Boolean = js.native
  def getLogoSrc(): URI = js.native
  def getLogoText(): String = js.native
  def getMetadata(): Metadata = js.native
  def getUserName(): String = js.native
  def setDisplayLogoff(bDisplayLogoff: Boolean): this.type = js.native
  def setDisplayWelcome(bDisplayWelcome: Boolean): this.type = js.native
  def setLogoSrc(sLogoSrc: URI): this.type = js.native
  def setLogoText(sLogoText: String): this.type = js.native
  def setUserName(sUserName: String): this.type = js.native
}
     