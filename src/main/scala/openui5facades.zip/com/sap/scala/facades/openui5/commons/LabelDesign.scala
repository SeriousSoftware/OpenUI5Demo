package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait LabelDesign extends js.Object

object LabelDesign{
  @JSGlobal("sap.ui.commons.LabelDesign.Bold")
  @js.native
  object Bold extends LabelDesign

  @JSGlobal("sap.ui.commons.LabelDesign.Standard")
  @js.native
  object Standard extends LabelDesign
}

/* copy to Enum.scala
sealed trait LabelDesign{
  private[ui] def toFacade: sap.ui.commons.LabelDesign
}

object LabelDesign {
  def fromFacade(s: ui.commons.LabelDesign): LabelDesign = s match {
    case ui.commons.LabelDesign.Bold => LabelDesign.Bold
    case ui.commons.LabelDesign.Standard => LabelDesign.Standard
   case _ =>
     throw new UnsupportedOperationException(s"Unknown LabelDesign: $s")
  }
  
  object Bold extends LabelDesign {
    override private[ui] def toFacade: ui.commons.LabelDesign = ui.commons.LabelDesign.Bold
  }

  object Standard extends LabelDesign {
    override private[ui] def toFacade: ui.commons.LabelDesign = ui.commons.LabelDesign.Standard
  }

}
*/
