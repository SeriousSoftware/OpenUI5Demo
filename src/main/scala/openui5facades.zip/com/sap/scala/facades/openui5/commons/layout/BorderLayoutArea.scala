
package com.sap.scala.facades.openui5.commons.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control}
import com.sap.scala.facades.openui5.commons.layout.BorderLayoutAreaTypes


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.layout.BorderLayoutArea")
@js.native
class BorderLayoutArea() extends Element {
  def addContent(oContent: Control): this.type = js.native
  def destroyContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAreaId(): BorderLayoutAreaTypes = js.native
  def getContent(): js.Array[Control] = js.native
  def getContentAlign(): String = js.native
  def getMetadata(): Metadata = js.native
  def getOverflowX(): String = js.native
  def getOverflowY(): String = js.native
  def getSize(): CSSSize = js.native
  def getVisible(): Boolean = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def setAreaId(sAreaId: BorderLayoutAreaTypes): this.type = js.native
  def setContentAlign(sContentAlign: String): this.type = js.native
  def setOverflowX(sOverflowX: String): this.type = js.native
  def setOverflowY(sOverflowY: String): this.type = js.native
  def setSize(sSize: CSSSize): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     