
package com.sap.scala.facades.openui5.base

import com.sap.scala.facades.openui5.base.{Metadata,ManagedObject}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.base.ManagedObjectObserver")
@js.native
class ManagedObjectObserver()  {
  def disconnect(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def isObserved(oObject: ManagedObject, oConfiguration: Object): Boolean = js.native
  def observe(oObject: ManagedObject, oConfiguration: Object): Unit = js.native
  def unobserve(oObject: ManagedObject, oConfiguration: Object): Unit = js.native
}
     