package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ScrollBarAction extends js.Object

object ScrollBarAction{
  @JSGlobal("sap.ui.core.ScrollBarAction.Drag")
  @js.native
  object Drag extends ScrollBarAction

  @JSGlobal("sap.ui.core.ScrollBarAction.MouseWheel")
  @js.native
  object MouseWheel extends ScrollBarAction

  @JSGlobal("sap.ui.core.ScrollBarAction.Page")
  @js.native
  object Page extends ScrollBarAction

  @JSGlobal("sap.ui.core.ScrollBarAction.Step")
  @js.native
  object Step extends ScrollBarAction
}

/* copy to Enum.scala
sealed trait ScrollBarAction{
  private[ui] def toFacade: sap.ui.core.ScrollBarAction
}

object ScrollBarAction {
  def fromFacade(s: ui.core.ScrollBarAction): ScrollBarAction = s match {
    case ui.core.ScrollBarAction.Drag => ScrollBarAction.Drag
    case ui.core.ScrollBarAction.MouseWheel => ScrollBarAction.MouseWheel
    case ui.core.ScrollBarAction.Page => ScrollBarAction.Page
    case ui.core.ScrollBarAction.Step => ScrollBarAction.Step
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ScrollBarAction: $s")
  }
  
  object Drag extends ScrollBarAction {
    override private[ui] def toFacade: ui.core.ScrollBarAction = ui.core.ScrollBarAction.Drag
  }

  object MouseWheel extends ScrollBarAction {
    override private[ui] def toFacade: ui.core.ScrollBarAction = ui.core.ScrollBarAction.MouseWheel
  }

  object Page extends ScrollBarAction {
    override private[ui] def toFacade: ui.core.ScrollBarAction = ui.core.ScrollBarAction.Page
  }

  object Step extends ScrollBarAction {
    override private[ui] def toFacade: ui.core.ScrollBarAction = ui.core.ScrollBarAction.Step
  }

}
*/
