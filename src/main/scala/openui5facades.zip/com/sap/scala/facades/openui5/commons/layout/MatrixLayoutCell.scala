
package com.sap.scala.facades.openui5.commons.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.Control
import com.sap.scala.facades.openui5.commons.layout.{HAlign,Separation,VAlign,BackgroundDesign,Padding}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.layout.MatrixLayoutCell")
@js.native
class MatrixLayoutCell() extends Element {
  def addContent(oContent: Control): this.type = js.native
  def addStyleClass(sStyleClass: String): this.type = js.native
  def destroyContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getBackgroundDesign(): BackgroundDesign = js.native
  def getColSpan(): Int = js.native
  def getContent(): js.Array[Control] = js.native
  def getHAlign(): HAlign = js.native
  def getMetadata(): Metadata = js.native
  def getPadding(): Padding = js.native
  def getRowSpan(): Int = js.native
  def getSeparation(): Separation = js.native
  def getVAlign(): VAlign = js.native
  def hasStyleClass(sStyleClass: String): Boolean = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def removeStyleClass(sStyleClass: String): this.type = js.native
  def setBackgroundDesign(sBackgroundDesign: BackgroundDesign): this.type = js.native
  def setColSpan(iColSpan: Int): this.type = js.native
  def setHAlign(sHAlign: HAlign): this.type = js.native
  def setPadding(sPadding: Padding): this.type = js.native
  def setRowSpan(iRowSpan: Int): this.type = js.native
  def setSeparation(sSeparation: Separation): this.type = js.native
  def setVAlign(sVAlign: VAlign): this.type = js.native
}
     