package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ButtonStyle extends js.Object

object ButtonStyle{
  @JSGlobal("sap.ui.commons.ButtonStyle.Accept")
  @js.native
  object Accept extends ButtonStyle

  @JSGlobal("sap.ui.commons.ButtonStyle.Default")
  @js.native
  object Default extends ButtonStyle

  @JSGlobal("sap.ui.commons.ButtonStyle.Emph")
  @js.native
  object Emph extends ButtonStyle

  @JSGlobal("sap.ui.commons.ButtonStyle.Reject")
  @js.native
  object Reject extends ButtonStyle
}

/* copy to Enum.scala
sealed trait ButtonStyle{
  private[ui] def toFacade: sap.ui.commons.ButtonStyle
}

object ButtonStyle {
  def fromFacade(s: ui.commons.ButtonStyle): ButtonStyle = s match {
    case ui.commons.ButtonStyle.Accept => ButtonStyle.Accept
    case ui.commons.ButtonStyle.Default => ButtonStyle.Default
    case ui.commons.ButtonStyle.Emph => ButtonStyle.Emph
    case ui.commons.ButtonStyle.Reject => ButtonStyle.Reject
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ButtonStyle: $s")
  }
  
  object Accept extends ButtonStyle {
    override private[ui] def toFacade: ui.commons.ButtonStyle = ui.commons.ButtonStyle.Accept
  }

  object Default extends ButtonStyle {
    override private[ui] def toFacade: ui.commons.ButtonStyle = ui.commons.ButtonStyle.Default
  }

  object Emph extends ButtonStyle {
    override private[ui] def toFacade: ui.commons.ButtonStyle = ui.commons.ButtonStyle.Emph
  }

  object Reject extends ButtonStyle {
    override private[ui] def toFacade: ui.commons.ButtonStyle = ui.commons.ButtonStyle.Reject
  }

}
*/
