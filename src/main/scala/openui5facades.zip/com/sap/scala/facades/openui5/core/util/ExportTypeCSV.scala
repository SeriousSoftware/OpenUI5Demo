
package com.sap.scala.facades.openui5.core.util

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.util.ExportTypeCSV")
@js.native
class ExportTypeCSV() extends ExportType {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def generate(): String = js.native
  def getMetadata(): Metadata = js.native
  def getSeparatorChar(): String = js.native
  def setSeparatorChar(sSeparatorChar: String): this.type = js.native
}
     