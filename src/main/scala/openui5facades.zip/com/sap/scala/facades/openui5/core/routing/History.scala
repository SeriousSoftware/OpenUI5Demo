
package com.sap.scala.facades.openui5.core.routing

import com.sap.scala.facades.openui5.core.routing.HistoryDirection


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.routing.History")
@js.native
class History()  {
  def getDirection(sNewHash: String): HistoryDirection = js.native
  def getInstance(): this.type = js.native
  def getPreviousHash(): String = js.native
}
     