
package com.sap.scala.facades.openui5.f.semantic

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{OverflowToolbarButton,DraftIndicator,Button}
import com.sap.scala.facades.openui5.core.Control
import com.sap.scala.facades.openui5.f.DynamicPage
import com.sap.scala.facades.openui5.f.semantic.{SendMessageAction,PositiveAction,TitleMainAction,FavoriteAction,CopyAction,FlagAction,ShareInJamAction,PrintAction,SendEmailAction,DiscussInJamAction,FullScreenAction,NegativeAction,MessagesIndicator,CloseAction,AddAction,ExitFullScreenAction,FooterMainAction,DeleteAction}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.f.semantic.SemanticPage")
@js.native
class SemanticPage() extends Control {
  def addCustomShareAction(oCustomShareAction: Button): this.type = js.native
  def addFooterCustomAction(oFooterCustomAction: Button): this.type = js.native
  def addHeaderContent(oHeaderContent: Control): this.type = js.native
  def addTitleCustomIconAction(oTitleCustomIconAction: OverflowToolbarButton): this.type = js.native
  def addTitleCustomTextAction(oTitleCustomTextAction: Button): this.type = js.native
  def addTitleExpandedContent(oTitleExpandedContent: Control): this.type = js.native
  def addTitleSnappedContent(oTitleSnappedContent: Control): this.type = js.native
  def destroyAddAction(): this.type = js.native
  def destroyCloseAction(): this.type = js.native
  def destroyContent(): this.type = js.native
  def destroyCopyAction(): this.type = js.native
  def destroyCustomShareActions(): this.type = js.native
  def destroyDeleteAction(): this.type = js.native
  def destroyDiscussInJamAction(): this.type = js.native
  def destroyDraftIndicator(): this.type = js.native
  def destroyExitFullScreenAction(): this.type = js.native
  def destroyFavoriteAction(): this.type = js.native
  def destroyFlagAction(): this.type = js.native
  def destroyFooterCustomActions(): this.type = js.native
  def destroyFooterMainAction(): this.type = js.native
  def destroyFullScreenAction(): this.type = js.native
  def destroyHeaderContent(): this.type = js.native
  def destroyMessagesIndicator(): this.type = js.native
  def destroyNegativeAction(): this.type = js.native
  def destroyPositiveAction(): this.type = js.native
  def destroyPrintAction(): this.type = js.native
  def destroySaveAsTileAction(): this.type = js.native
  def destroySendEmailAction(): this.type = js.native
  def destroySendMessageAction(): this.type = js.native
  def destroyShareInJamAction(): this.type = js.native
  def destroyTitleCustomIconActions(): this.type = js.native
  def destroyTitleCustomTextActions(): this.type = js.native
  def destroyTitleExpandedContent(): this.type = js.native
  def destroyTitleHeading(): this.type = js.native
  def destroyTitleMainAction(): this.type = js.native
  def destroyTitleSnappedContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAddAction(): AddAction = js.native
  def getCloseAction(): CloseAction = js.native
  def getContent(): Control = js.native
  def getCopyAction(): CopyAction = js.native
  def getCustomShareActions(): js.Array[Button] = js.native
  def getDeleteAction(): DeleteAction = js.native
  def getDiscussInJamAction(): DiscussInJamAction = js.native
  def getDraftIndicator(): DraftIndicator = js.native
  def getExitFullScreenAction(): ExitFullScreenAction = js.native
  def getFavoriteAction(): FavoriteAction = js.native
  def getFlagAction(): FlagAction = js.native
  def getFooterCustomActions(): js.Array[Button] = js.native
  def getFooterMainAction(): FooterMainAction = js.native
  def getFullScreenAction(): FullScreenAction = js.native
  def getHeaderContent(): js.Array[Control] = js.native
  def getHeaderExpanded(): Boolean = js.native
  def getHeaderPinnable(): Boolean = js.native
  def getMessagesIndicator(): MessagesIndicator = js.native
  def getMetadata(): Metadata = js.native
  def getNegativeAction(): NegativeAction = js.native
  def getPositiveAction(): PositiveAction = js.native
  def getPreserveHeaderStateOnScroll(): Boolean = js.native
  def getPrintAction(): PrintAction = js.native
  def getSaveAsTileAction(): Button = js.native
  def getSendEmailAction(): SendEmailAction = js.native
  def getSendMessageAction(): SendMessageAction = js.native
  def getShareInJamAction(): ShareInJamAction = js.native
  def getShowFooter(): Boolean = js.native
  def getTitleCustomIconActions(): js.Array[OverflowToolbarButton] = js.native
  def getTitleCustomTextActions(): js.Array[Button] = js.native
  def getTitleExpandedContent(): js.Array[Control] = js.native
  def getTitleHeading(): Control = js.native
  def getTitleMainAction(): TitleMainAction = js.native
  def getTitleSnappedContent(): js.Array[Control] = js.native
  def getToggleHeaderOnTitleClick(): Boolean = js.native
  def indexOfCustomShareAction(oCustomShareAction: Button): Int = js.native
  def indexOfFooterCustomAction(oFooterCustomAction: Button): Int = js.native
  def indexOfHeaderContent(oHeaderContent: Control): Int = js.native
  def indexOfTitleCustomIconAction(oTitleCustomIconAction: OverflowToolbarButton): Int = js.native
  def indexOfTitleCustomTextAction(oTitleCustomTextAction: Button): Int = js.native
  def indexOfTitleExpandedContent(oTitleExpandedContent: Control): Int = js.native
  def indexOfTitleSnappedContent(oTitleSnappedContent: Control): Int = js.native
  def insertCustomShareAction(oCustomShareAction: Button, iIndex: Int): this.type = js.native
  def insertFooterCustomAction(oFooterCustomAction: Button, iIndex: Int): this.type = js.native
  def insertHeaderContent(oHeaderContent: Control, iIndex: Int): this.type = js.native
  def insertTitleCustomIconAction(oTitleCustomIconAction: OverflowToolbarButton, iIndex: Int): this.type = js.native
  def insertTitleCustomTextAction(oTitleCustomTextAction: Button, iIndex: Int): this.type = js.native
  def insertTitleExpandedContent(oTitleExpandedContent: Control, iIndex: Int): this.type = js.native
  def insertTitleSnappedContent(oTitleSnappedContent: Control, iIndex: Int): this.type = js.native
  def removeAllCustomShareActions(): js.Array[Button] = js.native
  def removeAllFooterCustomActions(): js.Array[Button] = js.native
  def removeAllHeaderContent(): js.Array[Control] = js.native
  def removeAllTitleCustomIconActions(): js.Array[OverflowToolbarButton] = js.native
  def removeAllTitleCustomTextActions(): js.Array[Button] = js.native
  def removeAllTitleExpandedContent(): js.Array[Control] = js.native
  def removeAllTitleSnappedContent(): js.Array[Control] = js.native
  def removeCustomShareAction(vCustomShareAction: Int | String | Button): Button = js.native
  def removeFooterCustomAction(vFooterCustomAction: Int | String | Button): Button = js.native
  def removeHeaderContent(vHeaderContent: Int | String | Control): Control = js.native
  def removeTitleCustomIconAction(vTitleCustomIconAction: Int | String | OverflowToolbarButton): OverflowToolbarButton = js.native
  def removeTitleCustomTextAction(vTitleCustomTextAction: Int | String | Button): Button = js.native
  def removeTitleExpandedContent(vTitleExpandedContent: Int | String | Control): Control = js.native
  def removeTitleSnappedContent(vTitleSnappedContent: Int | String | Control): Control = js.native
  def setAddAction(oAddAction: AddAction): this.type = js.native
  def setCloseAction(oCloseAction: CloseAction): this.type = js.native
  def setContent(oContent: Control): this.type = js.native
  def setCopyAction(oCopyAction: CopyAction): this.type = js.native
  def setDeleteAction(oDeleteAction: DeleteAction): this.type = js.native
  def setDiscussInJamAction(oDiscussInJamAction: DiscussInJamAction): this.type = js.native
  def setDraftIndicator(oDraftIndicator: DraftIndicator): this.type = js.native
  def setExitFullScreenAction(oExitFullScreenAction: ExitFullScreenAction): this.type = js.native
  def setFavoriteAction(oFavoriteAction: FavoriteAction): this.type = js.native
  def setFlagAction(oFlagAction: FlagAction): this.type = js.native
  def setFooterMainAction(oFooterMainAction: FooterMainAction): this.type = js.native
  def setFullScreenAction(oFullScreenAction: FullScreenAction): this.type = js.native
  def setHeaderExpanded(bHeaderExpanded: Boolean): this.type = js.native
  def setHeaderPinnable(bHeaderPinnable: Boolean): this.type = js.native
  def setMessagesIndicator(oMessagesIndicator: MessagesIndicator): this.type = js.native
  def setNegativeAction(oNegativeAction: NegativeAction): this.type = js.native
  def setPositiveAction(oPositiveAction: PositiveAction): this.type = js.native
  def setPreserveHeaderStateOnScroll(bPreserveHeaderStateOnScroll: Boolean): this.type = js.native
  def setPrintAction(oPrintAction: PrintAction): this.type = js.native
  def setSaveAsTileAction(oSaveAsTileAction: Button): this.type = js.native
  def setSendEmailAction(oSendEmailAction: SendEmailAction): this.type = js.native
  def setSendMessageAction(oSendMessageAction: SendMessageAction): this.type = js.native
  def setShareInJamAction(oShareInJamAction: ShareInJamAction): this.type = js.native
  def setShowFooter(bShowFooter: Boolean): this.type = js.native
  def setTitleHeading(oTitleHeading: Control): this.type = js.native
  def setTitleMainAction(oTitleMainAction: TitleMainAction): this.type = js.native
  def setToggleHeaderOnTitleClick(bToggleHeaderOnTitleClick: Boolean): this.type = js.native
}
     