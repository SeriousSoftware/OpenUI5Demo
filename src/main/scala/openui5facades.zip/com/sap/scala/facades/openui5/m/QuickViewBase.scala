
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.QuickViewPage


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.QuickViewBase")
@js.native
class QuickViewBase() extends Control {
  def addPage(oPage: QuickViewPage): this.type = js.native
  def attachAfterNavigate(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachNavigate(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindPages(oBindingInfo: Object): this.type = js.native
  def destroyPages(): this.type = js.native
  def detachAfterNavigate(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachNavigate(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterNavigate(mParameters: Object): this.type = js.native
  def fireNavigate(mParameters: Object): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getPages(): js.Array[QuickViewPage] = js.native
  def indexOfPage(oPage: QuickViewPage): Int = js.native
  def insertPage(oPage: QuickViewPage, iIndex: Int): this.type = js.native
  def navigateBack(): Unit = js.native
  def removeAllPages(): js.Array[QuickViewPage] = js.native
  def removePage(vPage: Int | String | QuickViewPage): QuickViewPage = js.native
  def unbindPages(): this.type = js.native
}
     