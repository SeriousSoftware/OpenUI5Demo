
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{Size,ValueColor,DeviationIndicator,LoadState}
import com.sap.scala.facades.openui5.core.{CSSSize,URI}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.NumericContent")
@js.native
class NumericContent() extends Control {
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePress(mParameters: Object): this.type = js.native
  def getAnimateTextChange(): Boolean = js.native
  def getFormatterValue(): Boolean = js.native
  def getIcon(): URI = js.native
  def getIconDescription(): String = js.native
  def getIndicator(): DeviationIndicator = js.native
  def getMetadata(): Metadata = js.native
  def getNullifyValue(): Boolean = js.native
  def getScale(): String = js.native
  def getSize(): Size = js.native
  def getState(): LoadState = js.native
  def getTruncateValueTo(): Int = js.native
  def getValue(): String = js.native
  def getValueColor(): ValueColor = js.native
  def getWidth(): CSSSize = js.native
  def getWithMargin(): Boolean = js.native
  def setAnimateTextChange(bAnimateTextChange: Boolean): this.type = js.native
  def setFormatterValue(bFormatterValue: Boolean): this.type = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setIconDescription(sIconDescription: String): this.type = js.native
  def setIndicator(sIndicator: DeviationIndicator): this.type = js.native
  def setNullifyValue(bNullifyValue: Boolean): this.type = js.native
  def setScale(sScale: String): this.type = js.native
  def setSize(sSize: Size): this.type = js.native
  def setState(sState: LoadState): this.type = js.native
  def setTruncateValueTo(iTruncateValueTo: Int): this.type = js.native
  def setValue(sValue: String): this.type = js.native
  def setValueColor(sValueColor: ValueColor): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
  def setWithMargin(bWithMargin: Boolean): this.type = js.native
}
     