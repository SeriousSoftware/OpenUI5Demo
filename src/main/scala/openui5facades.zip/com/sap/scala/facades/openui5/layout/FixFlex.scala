
package com.sap.scala.facades.openui5.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.layout.FixFlex")
@js.native
class FixFlex() extends Control {
  def addFixContent(oFixContent: Control): this.type = js.native
  def destroyFixContent(): this.type = js.native
  def destroyFlexContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getFixContent(): js.Array[Control] = js.native
  def getFixContentSize(): CSSSize = js.native
  def getFixFirst(): Boolean = js.native
  def getFlexContent(): Control = js.native
  def getMetadata(): Metadata = js.native
  def getMinFlexSize(): Int = js.native
  def getVertical(): Boolean = js.native
  def indexOfFixContent(oFixContent: Control): Int = js.native
  def insertFixContent(oFixContent: Control, iIndex: Int): this.type = js.native
  def removeAllFixContent(): js.Array[Control] = js.native
  def removeFixContent(vFixContent: Int | String | Control): Control = js.native
  def setFixContentSize(sFixContentSize: CSSSize): this.type = js.native
  def setFixFirst(bFixFirst: Boolean): this.type = js.native
  def setFlexContent(oFlexContent: Control): this.type = js.native
  def setMinFlexSize(iMinFlexSize: Int): this.type = js.native
  def setVertical(bVertical: Boolean): this.type = js.native
}
     