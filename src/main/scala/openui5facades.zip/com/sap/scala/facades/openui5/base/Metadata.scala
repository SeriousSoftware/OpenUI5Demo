
package com.sap.scala.facades.openui5.base




import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.base.Metadata")
@js.native
class Metadata()  {
//  def getAllPublicMethods(): /*TODO Type: 'string[]' not found.*/ = js.native
  def getClass(): js.Function1[Event[EventProps], Unit] = js.native
  def getName(): String = js.native
  def getParent(): this.type = js.native
//  def getPublicMethods(): /*TODO Type: 'string[]' not found.*/ = js.native
  def isAbstract(): Boolean = js.native
  def isDeprecated(): Boolean = js.native
  def isFinal(): Boolean = js.native
  def isInstanceOf(sInterface: String): Boolean = js.native
}
     