
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.{Metadata,ManagedObject}
import com.sap.scala.facades.openui5.m.Button
import com.sap.scala.facades.openui5.core.{CSSSize,URI,Control}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.PDFViewer")
@js.native
class PDFViewer() extends Control {
  def addPopupButton(oPopupButton: Button): this.type = js.native
  def attachError(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachLoaded(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachSourceValidationFailed(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyErrorPlaceholder(): this.type = js.native
  def destroyPopupButtons(): this.type = js.native
  def detachError(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachLoaded(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachSourceValidationFailed(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def downloadPDF(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireError(mParameters: Object): this.type = js.native
  def fireLoaded(mParameters: Object): this.type = js.native
  def fireSourceValidationFailed(mParameters: Object): this.type = js.native
  def getErrorMessage(): String = js.native
  def getErrorPlaceholder(): Control = js.native
  def getErrorPlaceholderMessage(): String = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getPopupButtons(): js.Array[Button] = js.native
  def getPopupHeaderTitle(): String = js.native
  def getShowDownloadButton(): Boolean = js.native
  def getSource(): URI = js.native
  def getTitle(): String = js.native
  def getWidth(): CSSSize = js.native
  def indexOfPopupButton(oPopupButton: Button): Int = js.native
  def insertPopupButton(oPopupButton: Button, iIndex: Int): this.type = js.native
  def invalidate(oOrigin: ManagedObject): Unit = js.native
  def open(): Unit = js.native
  def removeAllPopupButtons(): js.Array[Button] = js.native
  def removePopupButton(vPopupButton: Int | String | Button): Button = js.native
  def setErrorMessage(sErrorMessage: String): this.type = js.native
  def setErrorPlaceholder(oErrorPlaceholder: Control): this.type = js.native
  def setErrorPlaceholderMessage(sErrorPlaceholderMessage: String): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setPopupHeaderTitle(sPopupHeaderTitle: String): this.type = js.native
  def setShowDownloadButton(bShowDownloadButton: Boolean): this.type = js.native
  def setSource(sSource: URI): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     