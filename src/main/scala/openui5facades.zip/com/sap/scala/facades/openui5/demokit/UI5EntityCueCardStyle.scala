package com.sap.scala.facades.openui5.demokit

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait UI5EntityCueCardStyle extends js.Object

object UI5EntityCueCardStyle{
  @JSGlobal("sap.ui.demokit.UI5EntityCueCardStyle.Demokit")
  @js.native
  object Demokit extends UI5EntityCueCardStyle

  @JSGlobal("sap.ui.demokit.UI5EntityCueCardStyle.Standard")
  @js.native
  object Standard extends UI5EntityCueCardStyle
}

/* copy to Enum.scala
sealed trait UI5EntityCueCardStyle{
  private[ui] def toFacade: sap.ui.demokit.UI5EntityCueCardStyle
}

object UI5EntityCueCardStyle {
  def fromFacade(s: ui.demokit.UI5EntityCueCardStyle): UI5EntityCueCardStyle = s match {
    case ui.demokit.UI5EntityCueCardStyle.Demokit => UI5EntityCueCardStyle.Demokit
    case ui.demokit.UI5EntityCueCardStyle.Standard => UI5EntityCueCardStyle.Standard
   case _ =>
     throw new UnsupportedOperationException(s"Unknown UI5EntityCueCardStyle: $s")
  }
  
  object Demokit extends UI5EntityCueCardStyle {
    override private[ui] def toFacade: ui.demokit.UI5EntityCueCardStyle = ui.demokit.UI5EntityCueCardStyle.Demokit
  }

  object Standard extends UI5EntityCueCardStyle {
    override private[ui] def toFacade: ui.demokit.UI5EntityCueCardStyle = ui.demokit.UI5EntityCueCardStyle.Standard
  }

}
*/
