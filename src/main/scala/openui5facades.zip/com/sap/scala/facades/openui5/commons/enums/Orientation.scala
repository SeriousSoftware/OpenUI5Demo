package com.sap.scala.facades.openui5.commons.enums

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Orientation extends js.Object

object Orientation{
  @JSGlobal("sap.ui.commons.enums.Orientation.horizontal")
  @js.native
  object horizontal extends Orientation

  @JSGlobal("sap.ui.commons.enums.Orientation.vertical")
  @js.native
  object vertical extends Orientation
}

/* copy to Enum.scala
sealed trait Orientation{
  private[ui] def toFacade: sap.ui.commons.enums.Orientation
}

object Orientation {
  def fromFacade(s: ui.commons.enums.Orientation): Orientation = s match {
    case ui.commons.enums.Orientation.horizontal => Orientation.horizontal
    case ui.commons.enums.Orientation.vertical => Orientation.vertical
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Orientation: $s")
  }
  
  object horizontal extends Orientation {
    override private[ui] def toFacade: ui.commons.enums.Orientation = ui.commons.enums.Orientation.horizontal
  }

  object vertical extends Orientation {
    override private[ui] def toFacade: ui.commons.enums.Orientation = ui.commons.enums.Orientation.vertical
  }

}
*/
