package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ComponentLifecycle extends js.Object

object ComponentLifecycle{
  @JSGlobal("sap.ui.core.ComponentLifecycle.Application")
  @js.native
  object Application extends ComponentLifecycle

  @JSGlobal("sap.ui.core.ComponentLifecycle.Container")
  @js.native
  object Container extends ComponentLifecycle

  @JSGlobal("sap.ui.core.ComponentLifecycle.Legacy")
  @js.native
  object Legacy extends ComponentLifecycle
}

/* copy to Enum.scala
sealed trait ComponentLifecycle{
  private[ui] def toFacade: sap.ui.core.ComponentLifecycle
}

object ComponentLifecycle {
  def fromFacade(s: ui.core.ComponentLifecycle): ComponentLifecycle = s match {
    case ui.core.ComponentLifecycle.Application => ComponentLifecycle.Application
    case ui.core.ComponentLifecycle.Container => ComponentLifecycle.Container
    case ui.core.ComponentLifecycle.Legacy => ComponentLifecycle.Legacy
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ComponentLifecycle: $s")
  }
  
  object Application extends ComponentLifecycle {
    override private[ui] def toFacade: ui.core.ComponentLifecycle = ui.core.ComponentLifecycle.Application
  }

  object Container extends ComponentLifecycle {
    override private[ui] def toFacade: ui.core.ComponentLifecycle = ui.core.ComponentLifecycle.Container
  }

  object Legacy extends ComponentLifecycle {
    override private[ui] def toFacade: ui.core.ComponentLifecycle = ui.core.ComponentLifecycle.Legacy
  }

}
*/
