
package com.sap.scala.facades.openui5.core.util

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.util.ExportCell")
@js.native
class ExportCell() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getContent(): String = js.native
  def getMetadata(): Metadata = js.native
  def setContent(sContent: String): this.type = js.native
}
     