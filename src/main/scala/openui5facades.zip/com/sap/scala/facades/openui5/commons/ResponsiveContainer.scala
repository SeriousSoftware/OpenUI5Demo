
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control,ID}
import com.sap.scala.facades.openui5.commons.ResponsiveContainerRange


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.ResponsiveContainer")
@js.native
class ResponsiveContainer() extends Control {
  def addRange(oRange: ResponsiveContainerRange): this.type = js.native
  def attachRangeSwitch(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyRanges(): this.type = js.native
  def detachRangeSwitch(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireRangeSwitch(mParameters: Object): this.type = js.native
  def getDefaultContent(): ID = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getRanges(): js.Array[ResponsiveContainerRange] = js.native
  def getWidth(): CSSSize = js.native
  def indexOfRange(oRange: ResponsiveContainerRange): Int = js.native
  def insertRange(oRange: ResponsiveContainerRange, iIndex: Int): this.type = js.native
  def removeAllRanges(): js.Array[ResponsiveContainerRange] = js.native
  def removeRange(vRange: Int | String | ResponsiveContainerRange): ResponsiveContainerRange = js.native
  def setDefaultContent(oDefaultContent: ID | Control): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     