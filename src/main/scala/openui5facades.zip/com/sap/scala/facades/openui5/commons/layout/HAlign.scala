package com.sap.scala.facades.openui5.commons.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait HAlign extends js.Object

object HAlign{
  @JSGlobal("sap.ui.commons.layout.HAlign.Begin")
  @js.native
  object Begin extends HAlign

  @JSGlobal("sap.ui.commons.layout.HAlign.Center")
  @js.native
  object Center extends HAlign

  @JSGlobal("sap.ui.commons.layout.HAlign.End")
  @js.native
  object End extends HAlign

  @JSGlobal("sap.ui.commons.layout.HAlign.Left")
  @js.native
  object Left extends HAlign

  @JSGlobal("sap.ui.commons.layout.HAlign.Right")
  @js.native
  object Right extends HAlign
}

/* copy to Enum.scala
sealed trait HAlign{
  private[ui] def toFacade: sap.ui.commons.layout.HAlign
}

object HAlign {
  def fromFacade(s: ui.commons.layout.HAlign): HAlign = s match {
    case ui.commons.layout.HAlign.Begin => HAlign.Begin
    case ui.commons.layout.HAlign.Center => HAlign.Center
    case ui.commons.layout.HAlign.End => HAlign.End
    case ui.commons.layout.HAlign.Left => HAlign.Left
    case ui.commons.layout.HAlign.Right => HAlign.Right
   case _ =>
     throw new UnsupportedOperationException(s"Unknown HAlign: $s")
  }
  
  object Begin extends HAlign {
    override private[ui] def toFacade: ui.commons.layout.HAlign = ui.commons.layout.HAlign.Begin
  }

  object Center extends HAlign {
    override private[ui] def toFacade: ui.commons.layout.HAlign = ui.commons.layout.HAlign.Center
  }

  object End extends HAlign {
    override private[ui] def toFacade: ui.commons.layout.HAlign = ui.commons.layout.HAlign.End
  }

  object Left extends HAlign {
    override private[ui] def toFacade: ui.commons.layout.HAlign = ui.commons.layout.HAlign.Left
  }

  object Right extends HAlign {
    override private[ui] def toFacade: ui.commons.layout.HAlign = ui.commons.layout.HAlign.Right
  }

}
*/
