
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.mvc.{Controller,View}
import com.sap.scala.facades.openui5.core.{Element,Control,RenderManager,UIArea,ComponentContainer}
import com.sap.scala.facades.openui5.core.routing.{Router,Targets}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.UIComponent")
@js.native
class UIComponent() extends Component {
  def byId(sId: String): Element = js.native
  def createContent(): View | Control = js.native
  def createId(sId: String): String = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAutoPrefixId(): Boolean = js.native
  def getEventingParent(): Unit = js.native
  def getLocalId(sId: String): String = js.native
  def getMetadata(): Metadata = js.native
  def getRootControl(): Control = js.native
  def getRouter(): Router = js.native
  def getRouterFor(oControllerOrView: View | Controller): Router = js.native
  def getTargets(): Targets = js.native
  def getUIArea(): UIArea = js.native
  def init(): Unit = js.native
  def onAfterRendering(): Unit = js.native
  def onBeforeRendering(): Unit = js.native
  def render(oRenderManager: RenderManager): Unit = js.native
  def setContainer(oContainer: ComponentContainer): this.type = js.native
}
     