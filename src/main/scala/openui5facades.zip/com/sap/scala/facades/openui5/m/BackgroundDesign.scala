package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait BackgroundDesign extends js.Object

object BackgroundDesign{
  @JSGlobal("sap.m.BackgroundDesign.Solid")
  @js.native
  object Solid extends BackgroundDesign

  @JSGlobal("sap.m.BackgroundDesign.Translucent")
  @js.native
  object Translucent extends BackgroundDesign

  @JSGlobal("sap.m.BackgroundDesign.Transparent")
  @js.native
  object Transparent extends BackgroundDesign
}

/* copy to Enum.scala
sealed trait BackgroundDesign{
  private[ui] def toFacade: sap.m.BackgroundDesign
}

object BackgroundDesign {
  def fromFacade(s: m.BackgroundDesign): BackgroundDesign = s match {
    case m.BackgroundDesign.Solid => BackgroundDesign.Solid
    case m.BackgroundDesign.Translucent => BackgroundDesign.Translucent
    case m.BackgroundDesign.Transparent => BackgroundDesign.Transparent
   case _ =>
     throw new UnsupportedOperationException(s"Unknown BackgroundDesign: $s")
  }
  
  object Solid extends BackgroundDesign {
    override private[ui] def toFacade: m.BackgroundDesign = m.BackgroundDesign.Solid
  }

  object Translucent extends BackgroundDesign {
    override private[ui] def toFacade: m.BackgroundDesign = m.BackgroundDesign.Translucent
  }

  object Transparent extends BackgroundDesign {
    override private[ui] def toFacade: m.BackgroundDesign = m.BackgroundDesign.Transparent
  }

}
*/
