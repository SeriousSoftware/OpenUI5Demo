package com.sap.scala.facades.openui5.commons.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait BorderLayoutAreaTypes extends js.Object

object BorderLayoutAreaTypes{
  @JSGlobal("sap.ui.commons.layout.BorderLayoutAreaTypes.begin")
  @js.native
  object begin extends BorderLayoutAreaTypes

  @JSGlobal("sap.ui.commons.layout.BorderLayoutAreaTypes.bottom")
  @js.native
  object bottom extends BorderLayoutAreaTypes

  @JSGlobal("sap.ui.commons.layout.BorderLayoutAreaTypes.center")
  @js.native
  object center extends BorderLayoutAreaTypes

  @JSGlobal("sap.ui.commons.layout.BorderLayoutAreaTypes.end")
  @js.native
  object end extends BorderLayoutAreaTypes

  @JSGlobal("sap.ui.commons.layout.BorderLayoutAreaTypes.top")
  @js.native
  object top extends BorderLayoutAreaTypes
}

/* copy to Enum.scala
sealed trait BorderLayoutAreaTypes{
  private[ui] def toFacade: sap.ui.commons.layout.BorderLayoutAreaTypes
}

object BorderLayoutAreaTypes {
  def fromFacade(s: ui.commons.layout.BorderLayoutAreaTypes): BorderLayoutAreaTypes = s match {
    case ui.commons.layout.BorderLayoutAreaTypes.begin => BorderLayoutAreaTypes.begin
    case ui.commons.layout.BorderLayoutAreaTypes.bottom => BorderLayoutAreaTypes.bottom
    case ui.commons.layout.BorderLayoutAreaTypes.center => BorderLayoutAreaTypes.center
    case ui.commons.layout.BorderLayoutAreaTypes.end => BorderLayoutAreaTypes.end
    case ui.commons.layout.BorderLayoutAreaTypes.top => BorderLayoutAreaTypes.top
   case _ =>
     throw new UnsupportedOperationException(s"Unknown BorderLayoutAreaTypes: $s")
  }
  
  object begin extends BorderLayoutAreaTypes {
    override private[ui] def toFacade: ui.commons.layout.BorderLayoutAreaTypes = ui.commons.layout.BorderLayoutAreaTypes.begin
  }

  object bottom extends BorderLayoutAreaTypes {
    override private[ui] def toFacade: ui.commons.layout.BorderLayoutAreaTypes = ui.commons.layout.BorderLayoutAreaTypes.bottom
  }

  object center extends BorderLayoutAreaTypes {
    override private[ui] def toFacade: ui.commons.layout.BorderLayoutAreaTypes = ui.commons.layout.BorderLayoutAreaTypes.center
  }

  object end extends BorderLayoutAreaTypes {
    override private[ui] def toFacade: ui.commons.layout.BorderLayoutAreaTypes = ui.commons.layout.BorderLayoutAreaTypes.end
  }

  object top extends BorderLayoutAreaTypes {
    override private[ui] def toFacade: ui.commons.layout.BorderLayoutAreaTypes = ui.commons.layout.BorderLayoutAreaTypes.top
  }

}
*/
