
package com.sap.scala.facades.openui5.layout

import com.sap.scala.facades.openui5.base.{Metadata,ManagedObject}
import com.sap.scala.facades.openui5.core.{Element,LayoutData,Orientation}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.layout.PaneContainer")
@js.native
class PaneContainer() extends Element {
  def addPane(oPane: Element): this.type = js.native
  def destroyPanes(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getOrientation(): Orientation = js.native
  def getPanes(): js.Array[Element] = js.native
  def indexOfPane(oPane: Element): Int = js.native
//  def insertPane(oObject: /*TODO Type: 'undefined' not found.*/, iIndex: /*TODO Type: 'undefined' not found.*/): ManagedObject = js.native
  def removeAllPanes(): js.Array[Element] = js.native
  def removePane(vPane: Int | String | Element): Element = js.native
  def setLayoutData(oLayoutData: LayoutData): this.type = js.native
  def setOrientation(sOrientation: Orientation): this.type = js.native
}
     