
package com.sap.scala.facades.openui5.commons.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.layout.ResponsiveFlowLayoutData


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.layout.ResponsiveFlowLayoutData")
@js.native
class ResponsiveFlowLayoutData() extends ResponsiveFlowLayoutData {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMargin(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def setMargin(bMargin: Boolean): ResponsiveFlowLayoutData = js.native
}
     