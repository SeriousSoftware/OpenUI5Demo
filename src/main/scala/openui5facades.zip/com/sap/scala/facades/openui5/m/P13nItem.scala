
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nItem")
@js.native
class P13nItem() extends Item {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAggregationRole(): String = js.native
  def getColumnKey(): String = js.native
  def getHref(): String = js.native
  def getIsDefault(): Boolean = js.native
  def getMaxLength(): String = js.native
  def getMetadata(): Metadata = js.native
  def getPrecision(): String = js.native
  def getPress(): Object = js.native
  def getRole(): String = js.native
  def getScale(): String = js.native
  def getTarget(): String = js.native
  def getText(): String = js.native
  def getType(): String = js.native
//  def getValues(): /*TODO Type: 'string[]' not found.*/ = js.native
  def getVisible(): Boolean = js.native
  def getWidth(): String = js.native
  def setAggregationRole(sAggregationRole: String): this.type = js.native
  def setColumnKey(sColumnKey: String): this.type = js.native
  def setHref(sHref: String): this.type = js.native
  def setIsDefault(bIsDefault: Boolean): this.type = js.native
  def setMaxLength(sMaxLength: String): this.type = js.native
  def setPrecision(sPrecision: String): this.type = js.native
  def setPress(oPress: Object): this.type = js.native
  def setRole(sRole: String): this.type = js.native
  def setScale(sScale: String): this.type = js.native
  def setTarget(sTarget: String): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setType(sType: String): this.type = js.native
//  def setValues(sValues: /*TODO Type: 'string[]' not found.*/): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
  def setWidth(sWidth: String): this.type = js.native
}
     