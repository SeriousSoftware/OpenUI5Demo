
package com.sap.scala.facades.openui5.demokit

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CSSSize


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.demokit.FileUploadIntrospector")
@js.native
class FileUploadIntrospector() extends Control {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAutoRefreshInterval(): String = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getUploadUrl(): String = js.native
  def getWidth(): CSSSize = js.native
  def refresh(): Unit = js.native
  def setAutoRefreshInterval(sAutoRefreshInterval: String): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setUploadUrl(sUploadUrl: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     