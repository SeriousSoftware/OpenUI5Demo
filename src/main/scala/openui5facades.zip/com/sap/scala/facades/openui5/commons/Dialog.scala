
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control,ID,AccessibleRole,OpenState}
import com.sap.scala.facades.openui5.commons.Button
import com.sap.scala.facades.openui5.commons.enums.BorderDesign


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Dialog")
@js.native
class Dialog() extends Control {
  def addButton(oButton: Control): this.type = js.native
  def addContent(oContent: Control): this.type = js.native
  def attachClosed(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def close(): Unit = js.native
  def destroyButtons(): this.type = js.native
  def destroyContent(): this.type = js.native
  def detachClosed(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireClosed(mParameters: Object): this.type = js.native
  def getAccessibleRole(): AccessibleRole = js.native
  def getApplyContentPadding(): Boolean = js.native
  def getAutoClose(): Boolean = js.native
  def getButtons(): js.Array[Control] = js.native
  def getContent(): js.Array[Control] = js.native
  def getContentBorderDesign(): BorderDesign = js.native
  def getDefaultButton(): ID = js.native
  def getEnabled(): Boolean = js.native
  def getHeight(): CSSSize = js.native
  def getInitialFocus(): ID = js.native
  def getKeepInWindow(): Boolean = js.native
  def getMaxHeight(): CSSSize = js.native
  def getMaxWidth(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getMinHeight(): CSSSize = js.native
  def getMinWidth(): CSSSize = js.native
  def getModal(): Boolean = js.native
  def getOpenState(): OpenState = js.native
  def getResizable(): Boolean = js.native
  def getScrollLeft(): Int = js.native
  def getScrollTop(): Int = js.native
  def getShowCloseButton(): Boolean = js.native
  def getTitle(): String = js.native
  def getWidth(): CSSSize = js.native
  def indexOfButton(oButton: Control): Int = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertButton(oButton: Control, iIndex: Int): this.type = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def isOpen(): Boolean = js.native
  def open(): Unit = js.native
  def removeAllButtons(): js.Array[Control] = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeButton(vButton: Int | String | Control): Control = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def setAccessibleRole(sAccessibleRole: AccessibleRole): this.type = js.native
  def setApplyContentPadding(bApplyContentPadding: Boolean): this.type = js.native
  def setAutoClose(bAutoClose: Boolean): this.type = js.native
  def setContentBorderDesign(sContentBorderDesign: BorderDesign): this.type = js.native
  def setDefaultButton(oDefaultButton: ID | Button): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setInitialFocus(oInitialFocus: ID | Control): this.type = js.native
  def setKeepInWindow(bKeepInWindow: Boolean): this.type = js.native
  def setMaxHeight(sMaxHeight: CSSSize): this.type = js.native
  def setMaxWidth(sMaxWidth: CSSSize): this.type = js.native
  def setMinHeight(sMinHeight: CSSSize): this.type = js.native
  def setMinWidth(sMinWidth: CSSSize): this.type = js.native
  def setModal(bModal: Boolean): this.type = js.native
  def setResizable(bResizable: Boolean): this.type = js.native
  def setScrollLeft(iScrollLeft: Int): this.type = js.native
  def setScrollTop(iScrollTop: Int): this.type = js.native
  def setShowCloseButton(bShowCloseButton: Boolean): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     