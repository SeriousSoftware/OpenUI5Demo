
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{Control,AccessibleRole}
import com.sap.scala.facades.openui5.commons.FormattedTextViewControl


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.FormattedTextView")
@js.native
class FormattedTextView() extends Control {
  def addControl(oControl: Control): this.type = js.native
  def destroyControls(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAccessibleRole(): AccessibleRole = js.native
  def getControls(): js.Array[Control] = js.native
  def getHtmlText(): String = js.native
  def getMetadata(): Metadata = js.native
  def hasControls(): Boolean = js.native
  def indexOfControl(oControl: Control): Int = js.native
  def insertControl(oControl: Control, iIndex: Int): this.type = js.native
  def removeAllControls(): js.Array[Control] = js.native
  def removeControl(vControl: Int | String | Control): Control = js.native
  def setAccessibleRole(sAccessibleRole: AccessibleRole): this.type = js.native
  def setContent(sHtmlText: String, aControls: FormattedTextViewControl): Unit = js.native
  def setHtmlText(sText: String): Unit = js.native
}
     