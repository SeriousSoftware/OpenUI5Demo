
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.FacetFilterItem")
@js.native
class FacetFilterItem() extends ListItemBase {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getCount(): Int = js.native
  def getKey(): String = js.native
  def getMetadata(): Metadata = js.native
  def getText(): String = js.native
  def setCount(iCount: Int): this.type = js.native
  def setKey(sKey: String): this.type = js.native
  def setText(sText: String): this.type = js.native
}
     