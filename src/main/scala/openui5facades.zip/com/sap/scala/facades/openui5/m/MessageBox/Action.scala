package com.sap.scala.facades.openui5.m.MessageBox

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Action extends js.Object

object Action{
  @JSGlobal("sap.m.MessageBox.Action.ABORT")
  @js.native
  object ABORT extends Action

  @JSGlobal("sap.m.MessageBox.Action.CANCEL")
  @js.native
  object CANCEL extends Action

  @JSGlobal("sap.m.MessageBox.Action.CLOSE")
  @js.native
  object CLOSE extends Action

  @JSGlobal("sap.m.MessageBox.Action.DELETE")
  @js.native
  object DELETE extends Action

  @JSGlobal("sap.m.MessageBox.Action.IGNORE")
  @js.native
  object IGNORE extends Action

  @JSGlobal("sap.m.MessageBox.Action.NO")
  @js.native
  object NO extends Action

  @JSGlobal("sap.m.MessageBox.Action.OK")
  @js.native
  object OK extends Action

  @JSGlobal("sap.m.MessageBox.Action.RETRY")
  @js.native
  object RETRY extends Action

  @JSGlobal("sap.m.MessageBox.Action.YES")
  @js.native
  object YES extends Action
}

/* copy to Enum.scala
sealed trait Action{
  private[ui] def toFacade: sap.m.MessageBox.Action
}

object Action {
  def fromFacade(s: m.MessageBox.Action): Action = s match {
    case m.MessageBox.Action.ABORT => Action.ABORT
    case m.MessageBox.Action.CANCEL => Action.CANCEL
    case m.MessageBox.Action.CLOSE => Action.CLOSE
    case m.MessageBox.Action.DELETE => Action.DELETE
    case m.MessageBox.Action.IGNORE => Action.IGNORE
    case m.MessageBox.Action.NO => Action.NO
    case m.MessageBox.Action.OK => Action.OK
    case m.MessageBox.Action.RETRY => Action.RETRY
    case m.MessageBox.Action.YES => Action.YES
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Action: $s")
  }
  
  object ABORT extends Action {
    override private[ui] def toFacade: m.MessageBox.Action = m.MessageBox.Action.ABORT
  }

  object CANCEL extends Action {
    override private[ui] def toFacade: m.MessageBox.Action = m.MessageBox.Action.CANCEL
  }

  object CLOSE extends Action {
    override private[ui] def toFacade: m.MessageBox.Action = m.MessageBox.Action.CLOSE
  }

  object DELETE extends Action {
    override private[ui] def toFacade: m.MessageBox.Action = m.MessageBox.Action.DELETE
  }

  object IGNORE extends Action {
    override private[ui] def toFacade: m.MessageBox.Action = m.MessageBox.Action.IGNORE
  }

  object NO extends Action {
    override private[ui] def toFacade: m.MessageBox.Action = m.MessageBox.Action.NO
  }

  object OK extends Action {
    override private[ui] def toFacade: m.MessageBox.Action = m.MessageBox.Action.OK
  }

  object RETRY extends Action {
    override private[ui] def toFacade: m.MessageBox.Action = m.MessageBox.Action.RETRY
  }

  object YES extends Action {
    override private[ui] def toFacade: m.MessageBox.Action = m.MessageBox.Action.YES
  }

}
*/
