
package com.sap.scala.facades.openui5.f

import com.sap.scala.facades.openui5.f.FlexibleColumnLayout


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.f.FlexibleColumnLayoutSemanticHelper")
@js.native
class FlexibleColumnLayoutSemanticHelper()  {
//  def getCurrentUIState(): /*TODO Type: 'Object' not found.*/ = js.native
//  def getDefaultLayouts(): /*TODO Type: 'Object' not found.*/ = js.native
  def getInstanceFor(oFlexibleColumnLayout: FlexibleColumnLayout, oSettings: Object): this.type = js.native
//  def getNextUIState(iLevel: /*TODO Type: 'undefined' not found.*/): /*TODO Type: 'Object' not found.*/ = js.native
}
     