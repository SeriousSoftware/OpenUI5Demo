
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.MaskInputRule")
@js.native
class MaskInputRule() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMaskFormatSymbol(): String = js.native
  def getMetadata(): Metadata = js.native
  def getRegex(): String = js.native
  def setMaskFormatSymbol(sMaskFormatSymbol: String): this.type = js.native
  def setRegex(sRegex: String): this.type = js.native
}
     