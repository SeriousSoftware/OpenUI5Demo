
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,URI,Control,ID}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Link")
@js.native
class Link() extends Control {
  def addAriaDescribedBy(vAriaDescribedBy: ID | Control): this.type = js.native
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePress(mParameters: Object): Boolean = js.native
  def focus(): Unit = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getAriaDescribedBy(): js.Array[ID] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getEnabled(): Boolean = js.native
  def getHelpId(): String = js.native
  def getHref(): URI = js.native
  def getMetadata(): Metadata = js.native
  def getTarget(): String = js.native
  def getText(): String = js.native
  def getWidth(): CSSSize = js.native
  def removeAllAriaDescribedBy(): js.Array[ID] = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAriaDescribedBy(vAriaDescribedBy: Int | ID | Control): ID = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setHelpId(sHelpId: String): this.type = js.native
  def setHref(sHref: URI): this.type = js.native
  def setTarget(sTarget: String): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     