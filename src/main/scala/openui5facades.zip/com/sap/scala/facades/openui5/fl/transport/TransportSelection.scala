
package com.sap.scala.facades.openui5.fl.transport

import com.sap.scala.facades.openui5.fl.Change


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.fl.transport.TransportSelection")
@js.native
class TransportSelection()  {
//  def openTransportSelection(oChange: Change, oControl: Object): /*TODO Type: 'Promise' not found.*/ = js.native
  def selectTransport(oObjectInfo: Object, fOkay: js.Function1[Event[EventProps], Unit], fError: js.Function1[Event[EventProps], Unit], bCompactMode: Boolean, oControl: Object): Unit = js.native
//  def setTransports(aChanges: /*TODO Type: 'array' not found.*/, oControl: Object): /*TODO Type: 'Promise' not found.*/ = js.native
}
     