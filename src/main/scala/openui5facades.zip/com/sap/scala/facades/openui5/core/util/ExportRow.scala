
package com.sap.scala.facades.openui5.core.util

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.util.ExportCell


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.util.ExportRow")
@js.native
class ExportRow() extends ManagedObject {
  def addCell(oCell: ExportCell): this.type = js.native
  def destroyCells(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getCells(): js.Array[ExportCell] = js.native
  def getMetadata(): Metadata = js.native
  def indexOfCell(oCell: ExportCell): Int = js.native
  def insertCell(oCell: ExportCell, iIndex: Int): this.type = js.native
  def removeAllCells(): js.Array[ExportCell] = js.native
  def removeCell(vCell: Int | String | ExportCell): ExportCell = js.native
}
     