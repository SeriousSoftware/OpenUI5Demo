
package com.sap.scala.facades.openui5.core.routing

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.routing.HashChanger")
@js.native
class HashChanger() extends EventProvider {
  def destroy(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireHashChanged(newHash: String, oldHash: String): Unit = js.native
  def getHash(): String = js.native
  def getInstance(): Unit = js.native
  def getMetadata(): Metadata = js.native
  def init(): Unit = js.native
  def replaceHash(sHash: String): Unit = js.native
  def replaceHashChanger(oHashChanger: this.type): Unit = js.native
  def setHash(sHash: String): Unit = js.native
}
     