package com.sap.scala.facades.openui5.commons.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait BackgroundDesign extends js.Object

object BackgroundDesign{
  @JSGlobal("sap.ui.commons.layout.BackgroundDesign.Border")
  @js.native
  object Border extends BackgroundDesign

  @JSGlobal("sap.ui.commons.layout.BackgroundDesign.Fill1")
  @js.native
  object Fill1 extends BackgroundDesign

  @JSGlobal("sap.ui.commons.layout.BackgroundDesign.Fill2")
  @js.native
  object Fill2 extends BackgroundDesign

  @JSGlobal("sap.ui.commons.layout.BackgroundDesign.Fill3")
  @js.native
  object Fill3 extends BackgroundDesign

  @JSGlobal("sap.ui.commons.layout.BackgroundDesign.Header")
  @js.native
  object Header extends BackgroundDesign

  @JSGlobal("sap.ui.commons.layout.BackgroundDesign.Plain")
  @js.native
  object Plain extends BackgroundDesign

  @JSGlobal("sap.ui.commons.layout.BackgroundDesign.Transparent")
  @js.native
  object Transparent extends BackgroundDesign
}

/* copy to Enum.scala
sealed trait BackgroundDesign{
  private[ui] def toFacade: sap.ui.commons.layout.BackgroundDesign
}

object BackgroundDesign {
  def fromFacade(s: ui.commons.layout.BackgroundDesign): BackgroundDesign = s match {
    case ui.commons.layout.BackgroundDesign.Border => BackgroundDesign.Border
    case ui.commons.layout.BackgroundDesign.Fill1 => BackgroundDesign.Fill1
    case ui.commons.layout.BackgroundDesign.Fill2 => BackgroundDesign.Fill2
    case ui.commons.layout.BackgroundDesign.Fill3 => BackgroundDesign.Fill3
    case ui.commons.layout.BackgroundDesign.Header => BackgroundDesign.Header
    case ui.commons.layout.BackgroundDesign.Plain => BackgroundDesign.Plain
    case ui.commons.layout.BackgroundDesign.Transparent => BackgroundDesign.Transparent
   case _ =>
     throw new UnsupportedOperationException(s"Unknown BackgroundDesign: $s")
  }
  
  object Border extends BackgroundDesign {
    override private[ui] def toFacade: ui.commons.layout.BackgroundDesign = ui.commons.layout.BackgroundDesign.Border
  }

  object Fill1 extends BackgroundDesign {
    override private[ui] def toFacade: ui.commons.layout.BackgroundDesign = ui.commons.layout.BackgroundDesign.Fill1
  }

  object Fill2 extends BackgroundDesign {
    override private[ui] def toFacade: ui.commons.layout.BackgroundDesign = ui.commons.layout.BackgroundDesign.Fill2
  }

  object Fill3 extends BackgroundDesign {
    override private[ui] def toFacade: ui.commons.layout.BackgroundDesign = ui.commons.layout.BackgroundDesign.Fill3
  }

  object Header extends BackgroundDesign {
    override private[ui] def toFacade: ui.commons.layout.BackgroundDesign = ui.commons.layout.BackgroundDesign.Header
  }

  object Plain extends BackgroundDesign {
    override private[ui] def toFacade: ui.commons.layout.BackgroundDesign = ui.commons.layout.BackgroundDesign.Plain
  }

  object Transparent extends BackgroundDesign {
    override private[ui] def toFacade: ui.commons.layout.BackgroundDesign = ui.commons.layout.BackgroundDesign.Transparent
  }

}
*/
