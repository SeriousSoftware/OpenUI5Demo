
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control,Title}
import com.sap.scala.facades.openui5.commons.Button
import com.sap.scala.facades.openui5.commons.enums.{AreaDesign,BorderDesign}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Panel")
@js.native
class Panel() extends Control {
  def addButton(oButton: Button): this.type = js.native
  def addContent(oContent: Control): this.type = js.native
  def destroyButtons(): this.type = js.native
  def destroyContent(): this.type = js.native
  def destroyTitle(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getApplyContentPadding(): Boolean = js.native
  def getAreaDesign(): AreaDesign = js.native
  def getBorderDesign(): BorderDesign = js.native
  def getButtons(): js.Array[Button] = js.native
  def getCollapsed(): Boolean = js.native
  def getContent(): js.Array[Control] = js.native
  def getEnabled(): Boolean = js.native
  def getFocusInfo(): Unit = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getScrollLeft(): Int = js.native
  def getScrollTop(): Int = js.native
  def getShowCollapseIcon(): Boolean = js.native
  def getText(): String = js.native
  def getTitle(): Title = js.native
  def getWidth(): CSSSize = js.native
  def indexOfButton(oButton: Button): Int = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertButton(oButton: Button, iIndex: Int): this.type = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def removeAllButtons(): js.Array[Button] = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeButton(vButton: Int | String | Button): Button = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def setApplyContentPadding(bPadding: Boolean): this.type = js.native
  def setAreaDesign(sAreaDesign: AreaDesign): this.type = js.native
  def setBorderDesign(sBorderDesign: BorderDesign): this.type = js.native
  def setCollapsed(bCollapsed: Boolean): this.type = js.native
  def setDimensions(sWidth: CSSSize, sHeight: CSSSize): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setScrollLeft(iPosition: Int): this.type = js.native
  def setScrollTop(iPosition: Int): this.type = js.native
  def setShowCollapseIcon(bShowCollapseIcon: Boolean): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTitle(oTitle: Title): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     