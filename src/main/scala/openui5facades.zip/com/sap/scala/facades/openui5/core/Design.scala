package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Design extends js.Object

object Design{
  @JSGlobal("sap.ui.core.Design.Monospace")
  @js.native
  object Monospace extends Design

  @JSGlobal("sap.ui.core.Design.Standard")
  @js.native
  object Standard extends Design
}

/* copy to Enum.scala
sealed trait Design{
  private[ui] def toFacade: sap.ui.core.Design
}

object Design {
  def fromFacade(s: ui.core.Design): Design = s match {
    case ui.core.Design.Monospace => Design.Monospace
    case ui.core.Design.Standard => Design.Standard
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Design: $s")
  }
  
  object Monospace extends Design {
    override private[ui] def toFacade: ui.core.Design = ui.core.Design.Monospace
  }

  object Standard extends Design {
    override private[ui] def toFacade: ui.core.Design = ui.core.Design.Standard
  }

}
*/
