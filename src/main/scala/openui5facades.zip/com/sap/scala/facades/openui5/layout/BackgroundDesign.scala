package com.sap.scala.facades.openui5.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait BackgroundDesign extends js.Object

object BackgroundDesign{
  @JSGlobal("sap.ui.layout.BackgroundDesign.Solid")
  @js.native
  object Solid extends BackgroundDesign

  @JSGlobal("sap.ui.layout.BackgroundDesign.Translucent")
  @js.native
  object Translucent extends BackgroundDesign

  @JSGlobal("sap.ui.layout.BackgroundDesign.Transparent")
  @js.native
  object Transparent extends BackgroundDesign
}

/* copy to Enum.scala
sealed trait BackgroundDesign{
  private[ui] def toFacade: sap.ui.layout.BackgroundDesign
}

object BackgroundDesign {
  def fromFacade(s: ui.layout.BackgroundDesign): BackgroundDesign = s match {
    case ui.layout.BackgroundDesign.Solid => BackgroundDesign.Solid
    case ui.layout.BackgroundDesign.Translucent => BackgroundDesign.Translucent
    case ui.layout.BackgroundDesign.Transparent => BackgroundDesign.Transparent
   case _ =>
     throw new UnsupportedOperationException(s"Unknown BackgroundDesign: $s")
  }
  
  object Solid extends BackgroundDesign {
    override private[ui] def toFacade: ui.layout.BackgroundDesign = ui.layout.BackgroundDesign.Solid
  }

  object Translucent extends BackgroundDesign {
    override private[ui] def toFacade: ui.layout.BackgroundDesign = ui.layout.BackgroundDesign.Translucent
  }

  object Transparent extends BackgroundDesign {
    override private[ui] def toFacade: ui.layout.BackgroundDesign = ui.layout.BackgroundDesign.Transparent
  }

}
*/
