package com.sap.scala.facades.openui5.commons.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait Padding extends js.Object

object Padding{
  @JSGlobal("sap.ui.commons.layout.Padding.Begin")
  @js.native
  object Begin extends Padding

  @JSGlobal("sap.ui.commons.layout.Padding.Both")
  @js.native
  object Both extends Padding

  @JSGlobal("sap.ui.commons.layout.Padding.End")
  @js.native
  object End extends Padding

  @JSGlobal("sap.ui.commons.layout.Padding.Neither")
  @js.native
  object Neither extends Padding

  @JSGlobal("sap.ui.commons.layout.Padding.None")
  @js.native
  object None extends Padding
}

/* copy to Enum.scala
sealed trait Padding{
  private[ui] def toFacade: sap.ui.commons.layout.Padding
}

object Padding {
  def fromFacade(s: ui.commons.layout.Padding): Padding = s match {
    case ui.commons.layout.Padding.Begin => Padding.Begin
    case ui.commons.layout.Padding.Both => Padding.Both
    case ui.commons.layout.Padding.End => Padding.End
    case ui.commons.layout.Padding.Neither => Padding.Neither
    case ui.commons.layout.Padding.None => Padding.None
   case _ =>
     throw new UnsupportedOperationException(s"Unknown Padding: $s")
  }
  
  object Begin extends Padding {
    override private[ui] def toFacade: ui.commons.layout.Padding = ui.commons.layout.Padding.Begin
  }

  object Both extends Padding {
    override private[ui] def toFacade: ui.commons.layout.Padding = ui.commons.layout.Padding.Both
  }

  object End extends Padding {
    override private[ui] def toFacade: ui.commons.layout.Padding = ui.commons.layout.Padding.End
  }

  object Neither extends Padding {
    override private[ui] def toFacade: ui.commons.layout.Padding = ui.commons.layout.Padding.Neither
  }

  object None extends Padding {
    override private[ui] def toFacade: ui.commons.layout.Padding = ui.commons.layout.Padding.None
  }

}
*/
