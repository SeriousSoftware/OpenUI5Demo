
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{IconTab,IconTabHeaderMode,BackgroundDesign}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.IconTabHeader")
@js.native
class IconTabHeader() extends Control {
  def addItem(oItem: IconTab): this.type = js.native
  def attachSelect(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyItems(): this.type = js.native
  def detachSelect(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireSelect(mParameters: Object): this.type = js.native
  def getBackgroundDesign(): BackgroundDesign = js.native
  def getEnableTabReordering(): Boolean = js.native
  def getItems(): js.Array[IconTab] = js.native
  def getMetadata(): Metadata = js.native
  def getMode(): IconTabHeaderMode = js.native
  def getSelectedKey(): String = js.native
  def getShowOverflowSelectList(): Boolean = js.native
  def getShowSelection(): Boolean = js.native
  def getVisible(): Boolean = js.native
  def indexOfItem(oItem: IconTab): Int = js.native
  def insertItem(oItem: IconTab, iIndex: Int): this.type = js.native
  def removeAllItems(): js.Array[IconTab] = js.native
  def removeItem(vItem: Int | String | IconTab): IconTab = js.native
  def setBackgroundDesign(sBackgroundDesign: BackgroundDesign): this.type = js.native
  def setEnableTabReordering(bEnableTabReordering: Boolean): this.type = js.native
  def setMode(sMode: IconTabHeaderMode): this.type = js.native
  def setSelectedKey(sKey: String): this.type = js.native
  def setShowOverflowSelectList(bShowOverflowSelectList: Boolean): this.type = js.native
  def setShowSelection(bShowSelection: Boolean): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
}
     