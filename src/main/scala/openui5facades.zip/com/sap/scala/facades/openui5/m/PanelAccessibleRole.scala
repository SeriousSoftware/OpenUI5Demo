package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait PanelAccessibleRole extends js.Object

object PanelAccessibleRole{
  @JSGlobal("sap.m.PanelAccessibleRole.Complementary")
  @js.native
  object Complementary extends PanelAccessibleRole

  @JSGlobal("sap.m.PanelAccessibleRole.Form")
  @js.native
  object Form extends PanelAccessibleRole

  @JSGlobal("sap.m.PanelAccessibleRole.Region")
  @js.native
  object Region extends PanelAccessibleRole
}

/* copy to Enum.scala
sealed trait PanelAccessibleRole{
  private[ui] def toFacade: sap.m.PanelAccessibleRole
}

object PanelAccessibleRole {
  def fromFacade(s: m.PanelAccessibleRole): PanelAccessibleRole = s match {
    case m.PanelAccessibleRole.Complementary => PanelAccessibleRole.Complementary
    case m.PanelAccessibleRole.Form => PanelAccessibleRole.Form
    case m.PanelAccessibleRole.Region => PanelAccessibleRole.Region
   case _ =>
     throw new UnsupportedOperationException(s"Unknown PanelAccessibleRole: $s")
  }
  
  object Complementary extends PanelAccessibleRole {
    override private[ui] def toFacade: m.PanelAccessibleRole = m.PanelAccessibleRole.Complementary
  }

  object Form extends PanelAccessibleRole {
    override private[ui] def toFacade: m.PanelAccessibleRole = m.PanelAccessibleRole.Form
  }

  object Region extends PanelAccessibleRole {
    override private[ui] def toFacade: m.PanelAccessibleRole = m.PanelAccessibleRole.Region
  }

}
*/
