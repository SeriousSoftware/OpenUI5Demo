
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{Bar,PlacementType,Button}
import com.sap.scala.facades.openui5.core.{CSSSize,Control,ID}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.Popover")
@js.native
class Popover() extends Control {
  def _afterAdjustPositionAndArrowHook(): Unit = js.native
  def _getAnyHeader(): Unit = js.native
  def addAriaDescribedBy(vAriaDescribedBy: ID | Control): this.type = js.native
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def addContent(oContent: Control): this.type = js.native
  def attachAfterClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachAfterOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeClose(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachBeforeOpen(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def close(): this.type = js.native
  def destroyBeginButton(): this.type = js.native
  def destroyContent(): this.type = js.native
  def destroyCustomHeader(): this.type = js.native
  def destroyEndButton(): this.type = js.native
  def destroyFooter(): this.type = js.native
  def destroySubHeader(): this.type = js.native
  def detachAfterClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachAfterOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeClose(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachBeforeOpen(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireAfterClose(mParameters: Object): this.type = js.native
  def fireAfterOpen(mParameters: Object): this.type = js.native
  def fireBeforeClose(mParameters: Object): this.type = js.native
  def fireBeforeOpen(mParameters: Object): this.type = js.native
  def getAriaDescribedBy(): js.Array[ID] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getBeginButton(): Control = js.native
  def getContent(): js.Array[Control] = js.native
  def getContentHeight(): CSSSize = js.native
  def getContentMinWidth(): CSSSize = js.native
  def getContentWidth(): CSSSize = js.native
  def getCustomHeader(): Control = js.native
  def getEnableScrolling(): Boolean = js.native
  def getEndButton(): Control = js.native
  def getFooter(): Control = js.native
  def getHorizontalScrolling(): Boolean = js.native
  def getInitialFocus(): ID = js.native
  def getLeftButton(): ID = js.native
  def getMetadata(): Metadata = js.native
  def getModal(): Boolean = js.native
  def getOffsetX(): Int = js.native
  def getOffsetY(): Int = js.native
  def getPlacement(): PlacementType = js.native
  def getResizable(): Boolean = js.native
  def getRightButton(): ID = js.native
  def getShowArrow(): Boolean = js.native
  def getShowHeader(): Boolean = js.native
  def getSubHeader(): Control = js.native
  def getTitle(): String = js.native
  def getVerticalScrolling(): Boolean = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def isOpen(): Boolean = js.native
  def openBy(oControl: Object, bSkipInstanceManager: Boolean): this.type = js.native
//  def outerHeight(oElement: /*TODO Type: 'HTMLElement' not found.*/, bIncludeMargin: Boolean): Unit = js.native
//  def outerWidth(oElement: /*TODO Type: 'HTMLElement' not found.*/, bIncludeMargin: Boolean): Unit = js.native
  def removeAllAriaDescribedBy(): js.Array[ID] = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeAriaDescribedBy(vAriaDescribedBy: Int | ID | Control): ID = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def setBeginButton(oBeginButton: Control): this.type = js.native
  def setBounce(bBounce: Boolean): this.type = js.native
  def setContentHeight(sContentHeight: CSSSize): this.type = js.native
  def setContentMinWidth(sContentMinWidth: CSSSize): this.type = js.native
  def setContentWidth(sContentWidth: CSSSize): this.type = js.native
  def setCustomHeader(oCustomHeader: Control): this.type = js.native
  def setEnableScrolling(bEnableScrolling: Boolean): this.type = js.native
  def setEndButton(oEndButton: Control): this.type = js.native
  def setFollowOf(bValue: Boolean): this.type = js.native
  def setFooter(oFooter: Control): this.type = js.native
  def setHorizontalScrolling(bHorizontalScrolling: Boolean): this.type = js.native
  def setInitialFocus(oInitialFocus: ID | Control): this.type = js.native
  def setLeftButton(oLeftButton: ID | Button): this.type = js.native
  def setModal(bModal: Boolean, sModalCSSClass: String): this.type = js.native
  def setOffsetX(iOffsetX: Int): this.type = js.native
  def setOffsetY(iOffsetY: Int): this.type = js.native
  def setPlacement(sPlacement: PlacementType): this.type = js.native
  def setResizable(bResizable: Boolean): this.type = js.native
  def setRightButton(oRightButton: ID | Button): this.type = js.native
  def setShowArrow(bShowArrow: Boolean): this.type = js.native
  def setShowHeader(bShowHeader: Boolean): this.type = js.native
  def setSubHeader(oSubHeader: Control): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
  def setVerticalScrolling(bVerticalScrolling: Boolean): this.type = js.native
}
     