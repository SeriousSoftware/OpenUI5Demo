
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.core.{Configuration,URI,Element,Control}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.RenderManager")
@js.native
class RenderManager() extends Object {
  def addClass(sName: String): this.type = js.native
  def addStyle(sName: String, value: String | Float | Int): this.type = js.native
  def cleanupControlWithoutRendering(oControl: Control): Unit = js.native
  def createInvisiblePlaceholderId(oElement: Element): String = js.native
  def destroy(): Unit = js.native
//  def findPreservedContent(sId: String): /*TODO Type: 'jQuery' not found.*/ = js.native
//  def flush(oTargetDomNode: /*TODO Type: 'Element' not found.*/, bDoNotPreserve: Boolean, vInsert: Boolean | Int): Unit = js.native
  def getConfiguration(): Configuration = js.native
  def getHTML(oControl: Control): String = js.native
//  def getPreserveAreaRef(): /*TODO Type: 'Element' not found.*/ = js.native
  def getRenderer(oControl: Control): Unit = js.native
  def getRenderer(oControl: Control): js.Function1[Event[EventProps], Unit] = js.native
//  def preserveContent(oRootNode: /*TODO Type: 'Element' not found.*/, bPreserveRoot: Boolean, bPreserveNodesWithId: Boolean): Unit = js.native
//  def render(oControl: Control, oTargetDomNode: /*TODO Type: 'Element' not found.*/): Unit = js.native
  def renderControl(oControl: Control): this.type = js.native
  def translate(sKey: String): Unit = js.native
//  def write(sText: String | /*TODO Type: 'number' not found.*/): this.type = js.native
  def writeAcceleratorKey(): this.type = js.native
//  def writeAccessibilityState(oElement: Element, mProps: /*TODO Type: 'Object' not found.*/): this.type = js.native
//  def writeAttribute(sName: String, vValue: String | /*TODO Type: 'number' not found.*/ | Boolean): this.type = js.native
//  def writeAttributeEscaped(sName: String, vValue: /*TODO Type: 'any' not found.*/): this.type = js.native
  def writeClasses(oElement: Element | Boolean): this.type = js.native
  def writeControlData(oControl: Control): this.type = js.native
  def writeElementData(oElement: Element): this.type = js.native
//  def writeEscaped(sText: /*TODO Type: 'any' not found.*/, bLineBreaks: Boolean): this.type = js.native
//  def writeIcon(sURI: URI, aClasses: /*TODO Type: 'array' not found.*/ | String, mAttributes: Object): this.type = js.native
  def writeInvisiblePlaceholderData(oElement: Element): this.type = js.native
  def writeStyles(): this.type = js.native
}
     