
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,ComponentLifecycle,URI,UIComponent,ID}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.ComponentContainer")
@js.native
class ComponentContainer() extends Control {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAsync(): Boolean = js.native
  def getAutoPrefixId(): Boolean = js.native
  def getComponent(): ID = js.native
  def getHandleValidation(): Boolean = js.native
  def getHeight(): CSSSize = js.native
  def getLifecycle(): ComponentLifecycle = js.native
  def getMetadata(): Metadata = js.native
  def getName(): String = js.native
  def getPropagateModel(): Boolean = js.native
  def getSettings(): Object = js.native
  def getUrl(): URI = js.native
  def getUsage(): String = js.native
  def getWidth(): CSSSize = js.native
  def setAsync(bAsync: Boolean): this.type = js.native
  def setAutoPrefixId(bAutoPrefixId: Boolean): this.type = js.native
  def setComponent(vComponent: String | UIComponent): this.type = js.native
  def setHandleValidation(bHandleValidation: Boolean): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setLifecycle(sLifecycle: ComponentLifecycle): this.type = js.native
  def setName(sName: String): this.type = js.native
  def setPropagateModel(bPropagateModel: Boolean): this.type = js.native
  def setSettings(oSettings: Object): this.type = js.native
  def setUrl(sUrl: URI): this.type = js.native
  def setUsage(sUsage: String): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     