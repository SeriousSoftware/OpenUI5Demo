package com.sap.scala.facades.openui5.layout.form

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait SimpleFormLayout extends js.Object

object SimpleFormLayout{
  @JSGlobal("sap.ui.layout.form.SimpleFormLayout.GridLayout")
  @js.native
  object GridLayout extends SimpleFormLayout

  @JSGlobal("sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout")
  @js.native
  object ResponsiveGridLayout extends SimpleFormLayout

  @JSGlobal("sap.ui.layout.form.SimpleFormLayout.ResponsiveLayout")
  @js.native
  object ResponsiveLayout extends SimpleFormLayout
}

/* copy to Enum.scala
sealed trait SimpleFormLayout{
  private[ui] def toFacade: sap.ui.layout.form.SimpleFormLayout
}

object SimpleFormLayout {
  def fromFacade(s: ui.layout.form.SimpleFormLayout): SimpleFormLayout = s match {
    case ui.layout.form.SimpleFormLayout.GridLayout => SimpleFormLayout.GridLayout
    case ui.layout.form.SimpleFormLayout.ResponsiveGridLayout => SimpleFormLayout.ResponsiveGridLayout
    case ui.layout.form.SimpleFormLayout.ResponsiveLayout => SimpleFormLayout.ResponsiveLayout
   case _ =>
     throw new UnsupportedOperationException(s"Unknown SimpleFormLayout: $s")
  }
  
  object GridLayout extends SimpleFormLayout {
    override private[ui] def toFacade: ui.layout.form.SimpleFormLayout = ui.layout.form.SimpleFormLayout.GridLayout
  }

  object ResponsiveGridLayout extends SimpleFormLayout {
    override private[ui] def toFacade: ui.layout.form.SimpleFormLayout = ui.layout.form.SimpleFormLayout.ResponsiveGridLayout
  }

  object ResponsiveLayout extends SimpleFormLayout {
    override private[ui] def toFacade: ui.layout.form.SimpleFormLayout = ui.layout.form.SimpleFormLayout.ResponsiveLayout
  }

}
*/
