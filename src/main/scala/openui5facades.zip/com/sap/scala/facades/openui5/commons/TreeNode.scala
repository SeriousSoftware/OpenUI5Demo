
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{URI,Control,ID}
import com.sap.scala.facades.openui5.commons.TreeNode


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.TreeNode")
@js.native
class TreeNode() extends Element {
  def addAriaDescribedBy(vAriaDescribedBy: ID | Control): this.type = js.native
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def addNode(oNode: this.type): this.type = js.native
  def attachSelected(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachToggleOpenState(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def collapse(bCollapseChildren: Boolean, bDisableCollapseFinishedHandler: Boolean): Unit = js.native
  def destroyNodes(): this.type = js.native
  def detachSelected(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachToggleOpenState(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def expand(bExpandChildren: Boolean, bDisableExpandFinishedHandler: Boolean): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireSelected(mParameters: Object): this.type = js.native
  def fireToggleOpenState(mParameters: Object): this.type = js.native
  def getAriaDescribedBy(): js.Array[ID] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getExpanded(): Boolean = js.native
  def getHasExpander(): Boolean = js.native
  def getIcon(): URI = js.native
  def getIsSelected(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getNodes(): js.Array[TreeNode] = js.native
  def getSelectable(): Boolean = js.native
  def getText(): String = js.native
  def indexOfNode(oNode: this.type): Int = js.native
  def insertNode(oNode: this.type, iIndex: Int): this.type = js.native
  def removeAllAriaDescribedBy(): js.Array[ID] = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAllNodes(): js.Array[TreeNode] = js.native
  def removeAriaDescribedBy(vAriaDescribedBy: Int | ID | Control): ID = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def removeNode(vNode: Int | String | this.type): this.type = js.native
  def select(bSuppressEvent: Boolean, bDeselectOtherNodes: Boolean): Unit = js.native
  def setExpanded(bExpanded: Boolean): this.type = js.native
  def setHasExpander(bHasExpander: Boolean): this.type = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setIsSelected(bIsSelected: Boolean): this.type = js.native
  def setSelectable(bSelectable: Boolean): this.type = js.native
  def setText(sText: String): this.type = js.native
}
     