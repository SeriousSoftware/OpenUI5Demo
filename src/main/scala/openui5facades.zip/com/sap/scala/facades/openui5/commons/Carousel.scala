
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control}
import com.sap.scala.facades.openui5.commons.enums.Orientation


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Carousel")
@js.native
class Carousel() extends Control {
  def addContent(oContent: Control): this.type = js.native
  def bindContent(oBindingInfo: Object): this.type = js.native
  def calculateAndSetSize(): Unit = js.native
  def destroyContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAnimationDuration(): Int = js.native
  def getContent(): js.Array[Control] = js.native
  def getDefaultItemHeight(): Int = js.native
  def getDefaultItemWidth(): Int = js.native
  def getFirstVisibleIndex(): Int = js.native
//  def getFocusDomRef(): /*TODO Type: 'jQuery' not found.*/ = js.native
  def getHandleSize(): Int = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getOrientation(): Orientation = js.native
  def getVisibleItems(): Int = js.native
  def getWidth(): CSSSize = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
//  def onswipeleft(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
//  def onswiperight(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): Unit = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def setAnimationDuration(iAnimationDuration: Int): this.type = js.native
  def setDefaultItemHeight(iDefaultItemHeight: Int): this.type = js.native
  def setDefaultItemWidth(iDefaultItemWidth: Int): this.type = js.native
  def setFirstVisibleIndex(iFirstVisibleIndex: Int): this.type = js.native
  def setHandleSize(iHandleSize: Int): this.type = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setOrientation(sOrientation: Orientation): this.type = js.native
  def setVisibleItems(iVisibleItems: Int): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
  def showElementWithId(sElementId: String): Unit = js.native
  def showNext(): Unit = js.native
  def showPrevious(): Unit = js.native
  def unbindContent(): this.type = js.native
}
     