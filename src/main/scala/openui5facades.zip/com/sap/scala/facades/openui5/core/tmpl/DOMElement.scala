
package com.sap.scala.facades.openui5.core.tmpl

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.tmpl.{DOMAttribute,DOMElement}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.tmpl.DOMElement")
@js.native
class DOMElement() extends Control {
  def addAttribute(oAttribute: DOMAttribute): this.type = js.native
  def addElement(oElement: this.type): this.type = js.native
//  def attr(sName: String, sValue: String): /*TODO Type: 'any' not found.*/ = js.native
  def destroyAttributes(): this.type = js.native
  def destroyElements(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAttributes(): js.Array[DOMAttribute] = js.native
  def getElements(): js.Array[DOMElement] = js.native
  def getMetadata(): Metadata = js.native
  def getTag(): String = js.native
  def getText(): String = js.native
  def indexOfAttribute(oAttribute: DOMAttribute): Int = js.native
  def indexOfElement(oElement: this.type): Int = js.native
  def insertAttribute(oAttribute: DOMAttribute, iIndex: Int): this.type = js.native
  def insertElement(oElement: this.type, iIndex: Int): this.type = js.native
  def removeAllAttributes(): js.Array[DOMAttribute] = js.native
  def removeAllElements(): js.Array[DOMElement] = js.native
  def removeAttr(sName: String): this.type = js.native
  def removeAttribute(vAttribute: Int | String | DOMAttribute): DOMAttribute = js.native
  def removeElement(vElement: Int | String | this.type): this.type = js.native
  def setTag(sTag: String): this.type = js.native
  def setText(sText: String): this.type = js.native
}
     