
package com.sap.scala.facades.openui5.core.delegate

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.delegate.ItemNavigation")
@js.native
class ItemNavigation() extends EventProvider {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getDisabledModifiers(oDisabledModifiers: Object): Object = js.native
//  def getItemDomRefs(): /*TODO Type: 'Element[]' not found.*/ = js.native
  def getMetadata(): Metadata = js.native
//  def getRootDomRef(): /*TODO Type: 'Element' not found.*/ = js.native
//  def hasDisabledModifier(oEvent: /*TODO Type: 'jQuery.Event' not found.*/): /*TODO Type: 'Boolean' not found.*/ = js.native
  def setColumns(iColumns: Int, bNoColumnChange: Boolean): this.type = js.native
  def setCycling(bCycling: Boolean): this.type = js.native
//  def setDisabledModifiers(oDisabledModifiers: /*TODO Type: 'Object' not found.*/): this.type = js.native
  def setHomeEndColumnMode(bStayInRow: Boolean, bCtrlEnabled: Boolean): this.type = js.native
//  def setItemDomRefs(aItemDomRefs: /*TODO Type: 'Element[]' not found.*/): this.type = js.native
  def setPageSize(iPageSize: Int): this.type = js.native
  def setRootDomRef(oDomRef: Object): this.type = js.native
  def setSelectedIndex(iIndex: Int): this.type = js.native
  def setTableMode(bTableMode: Boolean, bTableList: Boolean): this.type = js.native
}
     