
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{Menu,MenuButtonMode,ButtonType}
import com.sap.scala.facades.openui5.core.{CSSSize,URI,Control,TooltipBase,TextDirection}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.MenuButton")
@js.native
class MenuButton() extends Control {
  def attachDefaultAction(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyMenu(): this.type = js.native
  def detachDefaultAction(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireDefaultAction(mParameters: Object): this.type = js.native
  def getActiveIcon(): URI = js.native
  def getButtonMode(): MenuButtonMode = js.native
  def getEnabled(): Boolean = js.native
  def getIcon(): URI = js.native
  def getIconDensityAware(): Boolean = js.native
  def getMenu(): Menu = js.native
  def getMetadata(): Metadata = js.native
  def getText(): String = js.native
  def getTextDirection(): TextDirection = js.native
  def getType(): ButtonType = js.native
  def getUseDefaultActionOnly(): Boolean = js.native
  def getWidth(): CSSSize = js.native
  def init(): Unit = js.native
  def setActiveIcon(sActiveIcon: URI): this.type = js.native
  def setButtonMode(sMode: MenuButtonMode): this.type = js.native
  def setEnabled(bEnabled: Boolean): this.type = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setIconDensityAware(bIconDensityAware: Boolean): this.type = js.native
  def setMenu(oMenu: Menu): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTextDirection(sTextDirection: TextDirection): this.type = js.native
//  def setTooltip(vTooltip: TooltipBase): /*TODO Type: '*' not found.*/ = js.native
  def setType(sType: ButtonType): this.type = js.native
  def setUseDefaultActionOnly(bUseDefaultActionOnly: Boolean): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
}
     