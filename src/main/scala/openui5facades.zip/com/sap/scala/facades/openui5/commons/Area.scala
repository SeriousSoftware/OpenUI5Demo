
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.URI


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Area")
@js.native
class Area() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getAlt(): String = js.native
  def getCoords(): String = js.native
  def getHref(): URI = js.native
  def getMetadata(): Metadata = js.native
  def getShape(): String = js.native
  def setAlt(sAlt: String): this.type = js.native
  def setCoords(sCoords: String): this.type = js.native
  def setHref(sHref: URI): this.type = js.native
  def setShape(sShape: String): this.type = js.native
}
     