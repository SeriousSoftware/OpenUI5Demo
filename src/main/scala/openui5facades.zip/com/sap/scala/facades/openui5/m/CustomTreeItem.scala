
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.CustomTreeItem")
@js.native
class CustomTreeItem() extends TreeItemBase {
  def addContent(oContent: Control): this.type = js.native
  def bindContent(oBindingInfo: Object): this.type = js.native
  def destroyContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getContent(): js.Array[Control] = js.native
  def getMetadata(): Metadata = js.native
  def indexOfContent(oContent: Control): Int = js.native
  def insertContent(oContent: Control, iIndex: Int): this.type = js.native
  def removeAllContent(): js.Array[Control] = js.native
  def removeContent(vContent: Int | String | Control): Control = js.native
  def unbindContent(): this.type = js.native
}
     