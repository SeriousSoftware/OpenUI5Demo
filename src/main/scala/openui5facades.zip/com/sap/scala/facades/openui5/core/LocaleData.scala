
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.CalendarType


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.LocaleData")
@js.native
class LocaleData() extends Object {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
//  def getCalendarWeek(sStyle: String, iWeekNumber: /*TODO Type: 'number' not found.*/): String = js.native
  def getCombinedDateTimePattern(sDateStyle: String, sTimeStyle: String, sCalendarType: CalendarType): String = js.native
  def getCombinedIntervalPattern(sPattern: String, sCalendarType: CalendarType): String = js.native
  def getCurrencyCodeBySymbol(sCurrencySymbol: String): String = js.native
  def getCurrencyDigits(sCurrency: String): Int = js.native
  def getCurrencyPattern(sContext: String): String = js.native
  def getCurrencySymbol(sCurrency: String): String = js.native
  def getCustomDateTimePattern(sSkeleton: String, sCalendarType: CalendarType): String = js.native
  def getCustomIntervalPattern(sSkeleton: String, sGreatestDiff: String, sCalendarType: CalendarType): String = js.native
  def getDatePattern(sStyle: String, sCalendarType: CalendarType): String = js.native
  def getDateTimePattern(sStyle: String, sCalendarType: CalendarType): String = js.native
//  def getDayPeriods(sWidth: String, sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
//  def getDayPeriodsStandAlone(sWidth: String, sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
//  def getDays(sWidth: String, sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
//  def getDaysStandAlone(sWidth: String, sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
  def getDecimalFormat(sStyle: String, sNumber: String, sPlural: String): String = js.native
  def getDecimalPattern(): String = js.native
  def getDisplayName(sType: String, sStyle: String): Unit = js.native
//  def getEraDates(sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
//  def getEras(sWidth: String, sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
  def getFirstDayOfWeek(): Int = js.native
  def getIntervalPattern(sId: String, sCalendarType: CalendarType): String = js.native
  def getLanguages(): Object = js.native
  def getMetadata(): Metadata = js.native
  def getMinimalDaysInFirstWeek(): Int = js.native
//  def getMonths(sWidth: String, sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
//  def getMonthsStandAlone(sWidth: String, sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
  def getNumberSymbol(sType: String): String = js.native
  def getOrientation(): String = js.native
  def getPercentPattern(): String = js.native
  def getPreferredCalendarType(): CalendarType = js.native
  def getPreferredHourSymbol(): Unit = js.native
//  def getQuarters(sWidth: String, sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
//  def getQuartersStandAlone(sWidth: String, sCalendarType: CalendarType): /*TODO Type: 'array' not found.*/ = js.native
  def getRelativeDay(iDiff: Int, sStyle: String): String = js.native
//  def getRelativeHour(iDiff: Int, sStyle: String): String | /*TODO Type: 'null' not found.*/ = js.native
//  def getRelativeMinute(iDiff: Int, sStyle: String): String | /*TODO Type: 'null' not found.*/ = js.native
  def getRelativeMonth(iDiff: Int, sStyle: String): String = js.native
  def getRelativePattern(sScale: String, iDiff: Int, bFuture: Boolean, sStyle: String): String = js.native
//  def getRelativePatterns(aScales: /*TODO Type: 'string[]' not found.*/, sStyle: String): /*TODO Type: 'object[]' not found.*/ = js.native
  def getRelativeSecond(iDiff: Int, sStyle: String): String = js.native
  def getRelativeWeek(iDiff: Int, sStyle: String): String = js.native
  def getRelativeYear(iDiff: Int, sStyle: String): String = js.native
  def getScripts(): Object = js.native
  def getTerritories(): Object = js.native
  def getTimePattern(sStyle: String, sCalendarType: CalendarType): String = js.native
  def getWeekendEnd(): Int = js.native
  def getWeekendStart(): Int = js.native
}
     