
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{Link,Page}
import com.sap.scala.facades.openui5.core.{URI,Control,ID,TextDirection}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.MessagePage")
@js.native
class MessagePage() extends Control {
  def addAriaDescribedBy(vAriaDescribedBy: ID | Control): this.type = js.native
  def addAriaLabelledBy(vAriaLabelledBy: ID | Control): this.type = js.native
  def attachNavButtonPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyCustomDescription(): this.type = js.native
  def destroyCustomText(): this.type = js.native
  def detachNavButtonPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireNavButtonPress(mParameters: Object): this.type = js.native
  def getAriaDescribedBy(): js.Array[ID] = js.native
  def getAriaLabelledBy(): js.Array[ID] = js.native
  def getCustomDescription(): Link = js.native
  def getCustomText(): Link = js.native
  def getDescription(): String = js.native
  def getIcon(): URI = js.native
  def getMetadata(): Metadata = js.native
  def getShowHeader(): Boolean = js.native
  def getShowNavButton(): Boolean = js.native
  def getText(): String = js.native
  def getTextDirection(): TextDirection = js.native
  def getTitle(): String = js.native
  def removeAllAriaDescribedBy(): js.Array[ID] = js.native
  def removeAllAriaLabelledBy(): js.Array[ID] = js.native
  def removeAriaDescribedBy(vAriaDescribedBy: Int | ID | Control): ID = js.native
  def removeAriaLabelledBy(vAriaLabelledBy: Int | ID | Control): ID = js.native
  def setCustomDescription(oCustomDescription: Link): this.type = js.native
  def setCustomText(oCustomText: Link): this.type = js.native
  def setDescription(sDescription: String): this.type = js.native
  def setIcon(sIcon: URI): this.type = js.native
  def setShowHeader(bShowHeader: Boolean): this.type = js.native
  def setShowNavButton(bShowNavButton: Boolean): this.type = js.native
  def setText(sText: String): this.type = js.native
  def setTextDirection(sTextDirection: TextDirection): this.type = js.native
  def setTitle(sTitle: String): this.type = js.native
}
     