
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.LayoutData


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.VariantLayoutData")
@js.native
class VariantLayoutData() extends LayoutData {
  def addMultipleLayoutData(oMultipleLayoutData: LayoutData): this.type = js.native
  def destroyMultipleLayoutData(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getMultipleLayoutData(): js.Array[LayoutData] = js.native
  def indexOfMultipleLayoutData(oMultipleLayoutData: LayoutData): Int = js.native
  def insertMultipleLayoutData(oMultipleLayoutData: LayoutData, iIndex: Int): this.type = js.native
  def removeAllMultipleLayoutData(): js.Array[LayoutData] = js.native
  def removeMultipleLayoutData(vMultipleLayoutData: Int | String | LayoutData): LayoutData = js.native
}
     