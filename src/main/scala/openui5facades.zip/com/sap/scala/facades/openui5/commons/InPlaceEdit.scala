
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{ValueState,Control,TooltipBase}
import com.sap.scala.facades.openui5.commons.TextViewDesign


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.InPlaceEdit")
@js.native
class InPlaceEdit() extends Control {
  def attachChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachLiveChange(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def clearOldText(): Unit = js.native
  def destroyContent(): this.type = js.native
  def detachChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachLiveChange(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireChange(mParameters: Object): this.type = js.native
  def fireLiveChange(mParameters: Object): this.type = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getContent(): Control = js.native
  def getDesign(): TextViewDesign = js.native
  def getMetadata(): Metadata = js.native
  def getTooltip(): String | TooltipBase = js.native
  def getUndoEnabled(): Boolean = js.native
  def getValueState(): ValueState = js.native
  def setContent(oContent: Control): this.type = js.native
  def setDesign(sDesign: TextViewDesign): this.type = js.native
  def setTooltip(oTooltip: String | TooltipBase): this.type = js.native
  def setUndoEnabled(bUndoEnabled: Boolean): this.type = js.native
  def setValueState(sValueState: ValueState): this.type = js.native
}
     