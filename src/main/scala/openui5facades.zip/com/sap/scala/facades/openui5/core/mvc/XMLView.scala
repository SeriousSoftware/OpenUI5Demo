
package com.sap.scala.facades.openui5.core.mvc

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.mvc.XMLView.PreprocessorType


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.mvc.XMLView")
@js.native
class XMLView() extends View {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def registerPreprocessor(sType: String | PreprocessorType, vPreprocessor: String | js.Function1[Event[EventProps], Unit], bSyncSupport: Boolean, bOnDemand: Boolean, mSettings: Object): Unit = js.native
}
     