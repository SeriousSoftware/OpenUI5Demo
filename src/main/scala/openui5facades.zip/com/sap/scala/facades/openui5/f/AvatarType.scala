package com.sap.scala.facades.openui5.f

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait AvatarType extends js.Object

object AvatarType{
  @JSGlobal("sap.f.AvatarType.Icon")
  @js.native
  object Icon extends AvatarType

  @JSGlobal("sap.f.AvatarType.Image")
  @js.native
  object Image extends AvatarType

  @JSGlobal("sap.f.AvatarType.Initials")
  @js.native
  object Initials extends AvatarType
}

/* copy to Enum.scala
sealed trait AvatarType{
  private[ui] def toFacade: sap.f.AvatarType
}

object AvatarType {
  def fromFacade(s: f.AvatarType): AvatarType = s match {
    case f.AvatarType.Icon => AvatarType.Icon
    case f.AvatarType.Image => AvatarType.Image
    case f.AvatarType.Initials => AvatarType.Initials
   case _ =>
     throw new UnsupportedOperationException(s"Unknown AvatarType: $s")
  }
  
  object Icon extends AvatarType {
    override private[ui] def toFacade: f.AvatarType = f.AvatarType.Icon
  }

  object Image extends AvatarType {
    override private[ui] def toFacade: f.AvatarType = f.AvatarType.Image
  }

  object Initials extends AvatarType {
    override private[ui] def toFacade: f.AvatarType = f.AvatarType.Initials
  }

}
*/
