
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.unified.Menu


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.MenuButton")
@js.native
class MenuButton() extends Button {
  def attachItemSelected(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyMenu(): this.type = js.native
  def detachItemSelected(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireItemSelected(mParameters: Object): this.type = js.native
//  def firePress(mArguments: /*TODO Type: 'Map' not found.*/): this.type = js.native
  def getDockButton(): String = js.native
  def getDockMenu(): String = js.native
  def getMenu(): Menu = js.native
  def getMetadata(): Metadata = js.native
  def setDockButton(sDockButton: String): this.type = js.native
  def setDockMenu(sDockMenu: String): this.type = js.native
  def setMenu(oMenu: Menu): this.type = js.native
}
     