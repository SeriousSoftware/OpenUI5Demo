package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait DeviationIndicator extends js.Object

object DeviationIndicator{
  @JSGlobal("sap.m.DeviationIndicator.Down")
  @js.native
  object Down extends DeviationIndicator

  @JSGlobal("sap.m.DeviationIndicator.None")
  @js.native
  object None extends DeviationIndicator

  @JSGlobal("sap.m.DeviationIndicator.Up")
  @js.native
  object Up extends DeviationIndicator
}

/* copy to Enum.scala
sealed trait DeviationIndicator{
  private[ui] def toFacade: sap.m.DeviationIndicator
}

object DeviationIndicator {
  def fromFacade(s: m.DeviationIndicator): DeviationIndicator = s match {
    case m.DeviationIndicator.Down => DeviationIndicator.Down
    case m.DeviationIndicator.None => DeviationIndicator.None
    case m.DeviationIndicator.Up => DeviationIndicator.Up
   case _ =>
     throw new UnsupportedOperationException(s"Unknown DeviationIndicator: $s")
  }
  
  object Down extends DeviationIndicator {
    override private[ui] def toFacade: m.DeviationIndicator = m.DeviationIndicator.Down
  }

  object None extends DeviationIndicator {
    override private[ui] def toFacade: m.DeviationIndicator = m.DeviationIndicator.None
  }

  object Up extends DeviationIndicator {
    override private[ui] def toFacade: m.DeviationIndicator = m.DeviationIndicator.Up
  }

}
*/
