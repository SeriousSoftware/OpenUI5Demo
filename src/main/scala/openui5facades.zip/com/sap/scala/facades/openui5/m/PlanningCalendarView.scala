
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.unified.CalendarIntervalType


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.PlanningCalendarView")
@js.native
class PlanningCalendarView() extends Element {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getDescription(): String = js.native
  def getIntervalsL(): Int = js.native
  def getIntervalsM(): Int = js.native
  def getIntervalsS(): Int = js.native
  def getIntervalType(): CalendarIntervalType = js.native
  def getKey(): String = js.native
  def getMetadata(): Metadata = js.native
  def getShowSubIntervals(): Boolean = js.native
  def setDescription(sDescription: String): this.type = js.native
  def setIntervalsL(iIntervalsL: Int): this.type = js.native
  def setIntervalsM(iIntervalsM: Int): this.type = js.native
  def setIntervalsS(iIntervalsS: Int): this.type = js.native
  def setIntervalType(sIntervalType: CalendarIntervalType): this.type = js.native
  def setKey(sKey: String): this.type = js.native
  def setShowSubIntervals(bShowSubIntervals: Boolean): this.type = js.native
}
     