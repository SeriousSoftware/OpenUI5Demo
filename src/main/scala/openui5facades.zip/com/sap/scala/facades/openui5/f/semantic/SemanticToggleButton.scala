
package com.sap.scala.facades.openui5.f.semantic

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.f.semantic.SemanticToggleButton")
@js.native
class SemanticToggleButton() extends SemanticButton {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getMetadata(): Metadata = js.native
  def getPressed(): Boolean = js.native
  def setPressed(bPressed: Boolean): this.type = js.native
}
     