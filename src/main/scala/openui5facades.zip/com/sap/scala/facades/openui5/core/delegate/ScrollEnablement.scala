
package com.sap.scala.facades.openui5.core.delegate

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.{ListGrowingDirection,IconTabBar}
import com.sap.scala.facades.openui5.core.Control


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.delegate.ScrollEnablement")
@js.native
class ScrollEnablement() extends Object {
  def destroy(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
//  def getChildPosition(vElement: /*TODO Type: 'HTMLElement' not found.*/ | /*TODO Type: 'jQuery' not found.*/): Object = js.native
  def getHorizontal(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getVertical(): Boolean = js.native
  def refresh(): Unit = js.native
//  def scrollToElement(oElement: /*TODO Type: 'HTMLElement' not found.*/, iTime: Int): this.type = js.native
  def setBounce(bBounce: Boolean): Unit = js.native
  def setGrowingList(fnScrollLoadCallback: js.Function1[Event[EventProps], Unit], sScrollLoadDirection: ListGrowingDirection): Unit = js.native
  def setHorizontal(bHorizontal: Boolean): Unit = js.native
  def setIconTabBar(oIconTabBar: IconTabBar, fnScrollEndCallback: js.Function1[Event[EventProps], Unit], fnScrollStartCallback: js.Function1[Event[EventProps], Unit]): Unit = js.native
  def setPullDown(oControl: Control): Unit = js.native
  def setVertical(bVertical: Boolean): Unit = js.native
}
     