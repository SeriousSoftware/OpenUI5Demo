
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.URI


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.PullToRefresh")
@js.native
class PullToRefresh() extends Control {
  def attachRefresh(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def detachRefresh(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireRefresh(mParameters: Object): this.type = js.native
  def getCustomIcon(): URI = js.native
  def getDescription(): String = js.native
  def getIconDensityAware(): Boolean = js.native
  def getMetadata(): Metadata = js.native
  def getShowIcon(): Boolean = js.native
  def hide(): Unit = js.native
  def setCustomIcon(sCustomIcon: URI): this.type = js.native
  def setDescription(sDescription: String): this.type = js.native
  def setIconDensityAware(bIconDensityAware: Boolean): this.type = js.native
  def setShowIcon(bShowIcon: Boolean): this.type = js.native
}
     