package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait ObjectMarkerType extends js.Object

object ObjectMarkerType{
  @JSGlobal("sap.m.ObjectMarkerType.Draft")
  @js.native
  object Draft extends ObjectMarkerType

  @JSGlobal("sap.m.ObjectMarkerType.Favorite")
  @js.native
  object Favorite extends ObjectMarkerType

  @JSGlobal("sap.m.ObjectMarkerType.Flagged")
  @js.native
  object Flagged extends ObjectMarkerType

  @JSGlobal("sap.m.ObjectMarkerType.Locked")
  @js.native
  object Locked extends ObjectMarkerType

  @JSGlobal("sap.m.ObjectMarkerType.LockedBy")
  @js.native
  object LockedBy extends ObjectMarkerType

  @JSGlobal("sap.m.ObjectMarkerType.Unsaved")
  @js.native
  object Unsaved extends ObjectMarkerType

  @JSGlobal("sap.m.ObjectMarkerType.UnsavedBy")
  @js.native
  object UnsavedBy extends ObjectMarkerType
}

/* copy to Enum.scala
sealed trait ObjectMarkerType{
  private[ui] def toFacade: sap.m.ObjectMarkerType
}

object ObjectMarkerType {
  def fromFacade(s: m.ObjectMarkerType): ObjectMarkerType = s match {
    case m.ObjectMarkerType.Draft => ObjectMarkerType.Draft
    case m.ObjectMarkerType.Favorite => ObjectMarkerType.Favorite
    case m.ObjectMarkerType.Flagged => ObjectMarkerType.Flagged
    case m.ObjectMarkerType.Locked => ObjectMarkerType.Locked
    case m.ObjectMarkerType.LockedBy => ObjectMarkerType.LockedBy
    case m.ObjectMarkerType.Unsaved => ObjectMarkerType.Unsaved
    case m.ObjectMarkerType.UnsavedBy => ObjectMarkerType.UnsavedBy
   case _ =>
     throw new UnsupportedOperationException(s"Unknown ObjectMarkerType: $s")
  }
  
  object Draft extends ObjectMarkerType {
    override private[ui] def toFacade: m.ObjectMarkerType = m.ObjectMarkerType.Draft
  }

  object Favorite extends ObjectMarkerType {
    override private[ui] def toFacade: m.ObjectMarkerType = m.ObjectMarkerType.Favorite
  }

  object Flagged extends ObjectMarkerType {
    override private[ui] def toFacade: m.ObjectMarkerType = m.ObjectMarkerType.Flagged
  }

  object Locked extends ObjectMarkerType {
    override private[ui] def toFacade: m.ObjectMarkerType = m.ObjectMarkerType.Locked
  }

  object LockedBy extends ObjectMarkerType {
    override private[ui] def toFacade: m.ObjectMarkerType = m.ObjectMarkerType.LockedBy
  }

  object Unsaved extends ObjectMarkerType {
    override private[ui] def toFacade: m.ObjectMarkerType = m.ObjectMarkerType.Unsaved
  }

  object UnsavedBy extends ObjectMarkerType {
    override private[ui] def toFacade: m.ObjectMarkerType = m.ObjectMarkerType.UnsavedBy
  }

}
*/
