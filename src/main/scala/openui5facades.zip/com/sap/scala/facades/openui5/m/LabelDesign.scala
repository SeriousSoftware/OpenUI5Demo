package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait LabelDesign extends js.Object

object LabelDesign{
  @JSGlobal("sap.m.LabelDesign.Bold")
  @js.native
  object Bold extends LabelDesign

  @JSGlobal("sap.m.LabelDesign.Standard")
  @js.native
  object Standard extends LabelDesign
}

/* copy to Enum.scala
sealed trait LabelDesign{
  private[ui] def toFacade: sap.m.LabelDesign
}

object LabelDesign {
  def fromFacade(s: m.LabelDesign): LabelDesign = s match {
    case m.LabelDesign.Bold => LabelDesign.Bold
    case m.LabelDesign.Standard => LabelDesign.Standard
   case _ =>
     throw new UnsupportedOperationException(s"Unknown LabelDesign: $s")
  }
  
  object Bold extends LabelDesign {
    override private[ui] def toFacade: m.LabelDesign = m.LabelDesign.Bold
  }

  object Standard extends LabelDesign {
    override private[ui] def toFacade: m.LabelDesign = m.LabelDesign.Standard
  }

}
*/
