
package com.sap.scala.facades.openui5.layout

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{CSSSize,Control,Orientation}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.layout.Splitter")
@js.native
class Splitter() extends Control {
  def addContentArea(oContentArea: Control): this.type = js.native
  def attachResize(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def destroyContentAreas(): this.type = js.native
  def detachResize(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def disableAutoResize(bTemporarily: Boolean): Unit = js.native
  def disableKeyboardSupport(): Unit = js.native
  def disableLiveResize(): Unit = js.native
  def enableAutoResize(bTemporarily: Boolean): Unit = js.native
  def enableKeyboardSupport(): Unit = js.native
  def enableLiveResize(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def fireResize(mParameters: Object): this.type = js.native
//  def getCalculatedSizes(): /*TODO Type: 'Number[]' not found.*/ = js.native
  def getContentAreas(): js.Array[Control] = js.native
  def getHeight(): CSSSize = js.native
  def getMetadata(): Metadata = js.native
  def getOrientation(): Orientation = js.native
  def getWidth(): CSSSize = js.native
  def indexOfContentArea(oContentArea: Control): Int = js.native
  def insertContentArea(oContentArea: Control, iIndex: Int): this.type = js.native
  def removeAllContentAreas(): js.Array[Control] = js.native
  def removeContentArea(vContentArea: Int | String | Control): Control = js.native
  def setHeight(sHeight: CSSSize): this.type = js.native
  def setOrientation(sOrientation: Orientation): this.type = js.native
  def setWidth(sWidth: CSSSize): this.type = js.native
  def triggerResize(forceDirectly: Boolean): Unit = js.native
}
     