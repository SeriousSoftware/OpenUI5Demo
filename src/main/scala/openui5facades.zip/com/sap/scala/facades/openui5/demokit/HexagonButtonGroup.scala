
package com.sap.scala.facades.openui5.demokit

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.demokit.HexagonButton


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.demokit.HexagonButtonGroup")
@js.native
class HexagonButtonGroup() extends Control {
  def addButton(oButton: HexagonButton): this.type = js.native
  def destroyButtons(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getButtons(): js.Array[HexagonButton] = js.native
  def getColspan(): Int = js.native
  def getMetadata(): Metadata = js.native
  def indexOfButton(oButton: HexagonButton): Int = js.native
  def insertButton(oButton: HexagonButton, iIndex: Int): this.type = js.native
  def removeAllButtons(): js.Array[HexagonButton] = js.native
  def removeButton(vButton: Int | String | HexagonButton): HexagonButton = js.native
  def setColspan(iColspan: Int): this.type = js.native
}
     