package com.sap.scala.facades.openui5.m

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait DateTimeInputType extends js.Object

object DateTimeInputType{
  @JSGlobal("sap.m.DateTimeInputType.Date")
  @js.native
  object Date extends DateTimeInputType

  @JSGlobal("sap.m.DateTimeInputType.DateTime")
  @js.native
  object DateTime extends DateTimeInputType

  @JSGlobal("sap.m.DateTimeInputType.Time")
  @js.native
  object Time extends DateTimeInputType
}

/* copy to Enum.scala
sealed trait DateTimeInputType{
  private[ui] def toFacade: sap.m.DateTimeInputType
}

object DateTimeInputType {
  def fromFacade(s: m.DateTimeInputType): DateTimeInputType = s match {
    case m.DateTimeInputType.Date => DateTimeInputType.Date
    case m.DateTimeInputType.DateTime => DateTimeInputType.DateTime
    case m.DateTimeInputType.Time => DateTimeInputType.Time
   case _ =>
     throw new UnsupportedOperationException(s"Unknown DateTimeInputType: $s")
  }
  
  object Date extends DateTimeInputType {
    override private[ui] def toFacade: m.DateTimeInputType = m.DateTimeInputType.Date
  }

  object DateTime extends DateTimeInputType {
    override private[ui] def toFacade: m.DateTimeInputType = m.DateTimeInputType.DateTime
  }

  object Time extends DateTimeInputType {
    override private[ui] def toFacade: m.DateTimeInputType = m.DateTimeInputType.Time
  }

}
*/
