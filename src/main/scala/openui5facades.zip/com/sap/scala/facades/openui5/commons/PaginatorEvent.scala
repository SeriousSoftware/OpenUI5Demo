package com.sap.scala.facades.openui5.commons

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait PaginatorEvent extends js.Object

object PaginatorEvent{
  @JSGlobal("sap.ui.commons.PaginatorEvent.First")
  @js.native
  object First extends PaginatorEvent

  @JSGlobal("sap.ui.commons.PaginatorEvent.Goto")
  @js.native
  object Goto extends PaginatorEvent

  @JSGlobal("sap.ui.commons.PaginatorEvent.Last")
  @js.native
  object Last extends PaginatorEvent

  @JSGlobal("sap.ui.commons.PaginatorEvent.Next")
  @js.native
  object Next extends PaginatorEvent

  @JSGlobal("sap.ui.commons.PaginatorEvent.Previous")
  @js.native
  object Previous extends PaginatorEvent
}

/* copy to Enum.scala
sealed trait PaginatorEvent{
  private[ui] def toFacade: sap.ui.commons.PaginatorEvent
}

object PaginatorEvent {
  def fromFacade(s: ui.commons.PaginatorEvent): PaginatorEvent = s match {
    case ui.commons.PaginatorEvent.First => PaginatorEvent.First
    case ui.commons.PaginatorEvent.Goto => PaginatorEvent.Goto
    case ui.commons.PaginatorEvent.Last => PaginatorEvent.Last
    case ui.commons.PaginatorEvent.Next => PaginatorEvent.Next
    case ui.commons.PaginatorEvent.Previous => PaginatorEvent.Previous
   case _ =>
     throw new UnsupportedOperationException(s"Unknown PaginatorEvent: $s")
  }
  
  object First extends PaginatorEvent {
    override private[ui] def toFacade: ui.commons.PaginatorEvent = ui.commons.PaginatorEvent.First
  }

  object Goto extends PaginatorEvent {
    override private[ui] def toFacade: ui.commons.PaginatorEvent = ui.commons.PaginatorEvent.Goto
  }

  object Last extends PaginatorEvent {
    override private[ui] def toFacade: ui.commons.PaginatorEvent = ui.commons.PaginatorEvent.Last
  }

  object Next extends PaginatorEvent {
    override private[ui] def toFacade: ui.commons.PaginatorEvent = ui.commons.PaginatorEvent.Next
  }

  object Previous extends PaginatorEvent {
    override private[ui] def toFacade: ui.commons.PaginatorEvent = ui.commons.PaginatorEvent.Previous
  }

}
*/
