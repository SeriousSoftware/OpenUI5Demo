
package com.sap.scala.facades.openui5.commons

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.{Percentage,Control,Orientation}
import com.sap.scala.facades.openui5.commons.SplitterSize


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.commons.Splitter")
@js.native
class Splitter() extends Control {
  def addFirstPaneContent(oFirstPaneContent: Control): this.type = js.native
  def addSecondPaneContent(oSecondPaneContent: Control): this.type = js.native
  def destroyFirstPaneContent(): this.type = js.native
  def destroySecondPaneContent(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getFirstPaneContent(): js.Array[Control] = js.native
  def getHeight(): SplitterSize = js.native
  def getMetadata(): Metadata = js.native
  def getMinSizeFirstPane(): Percentage = js.native
  def getMinSizeSecondPane(): Percentage = js.native
  def getSecondPaneContent(): js.Array[Control] = js.native
  def getShowScrollBars(): Boolean = js.native
  def getSplitterBarVisible(): Boolean = js.native
  def getSplitterOrientation(): Orientation = js.native
  def getSplitterPosition(): Percentage = js.native
  def getWidth(): SplitterSize = js.native
  def indexOfFirstPaneContent(oFirstPaneContent: Control): Int = js.native
  def indexOfSecondPaneContent(oSecondPaneContent: Control): Int = js.native
  def insertFirstPaneContent(oFirstPaneContent: Control, iIndex: Int): this.type = js.native
  def insertSecondPaneContent(oSecondPaneContent: Control, iIndex: Int): this.type = js.native
  def removeAllFirstPaneContent(): js.Array[Control] = js.native
  def removeAllSecondPaneContent(): js.Array[Control] = js.native
  def removeFirstPaneContent(vFirstPaneContent: Int | String | Control): Control = js.native
  def removeSecondPaneContent(vSecondPaneContent: Int | String | Control): Control = js.native
  def setHeight(sHeight: SplitterSize): this.type = js.native
  def setMinSizeFirstPane(sMinSizeFirstPane: Percentage): this.type = js.native
  def setMinSizeSecondPane(sMinSizeSecondPane: Percentage): this.type = js.native
  def setShowScrollBars(bShowScrollBars: Boolean): this.type = js.native
  def setSplitterBarVisible(bSplitterBarVisible: Boolean): this.type = js.native
  def setSplitterOrientation(sSplitterOrientation: Orientation): this.type = js.native
  def setSplitterPosition(sSplitterPosition: Percentage): this.type = js.native
  def setWidth(sWidth: SplitterSize): this.type = js.native
}
     