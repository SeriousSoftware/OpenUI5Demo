
package com.sap.scala.facades.openui5.f

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.LightBox
import com.sap.scala.facades.openui5.core.{CSSSize,URI}
import com.sap.scala.facades.openui5.f.{AvatarImageFitType,AvatarShape,AvatarSize}


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.f.Avatar")
@js.native
class Avatar() extends Control {
  def attachPress(oData: Object, fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def bindDetailBox(oBindingInfo: Object): this.type = js.native
  def destroyDetailBox(): this.type = js.native
  def detachPress(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def firePress(mParameters: Object): this.type = js.native
  def getAccessibilityInfo(): Unit = js.native
  def getCustomDisplaySize(): CSSSize = js.native
  def getCustomFontSize(): CSSSize = js.native
  def getDetailBox(): LightBox = js.native
  def getDisplayShape(): AvatarShape = js.native
  def getDisplaySize(): AvatarSize = js.native
  def getImageFitType(): AvatarImageFitType = js.native
  def getInitials(): String = js.native
  def getMetadata(): Metadata = js.native
  def getSrc(): URI = js.native
  def setCustomDisplaySize(sCustomDisplaySize: CSSSize): this.type = js.native
  def setCustomFontSize(sCustomFontSize: CSSSize): this.type = js.native
//  def setDetailBox(oLightBox: LightBox | /*TODO Type: 'undefined' not found.*/): Object = js.native
  def setDisplayShape(sDisplayShape: AvatarShape): this.type = js.native
  def setDisplaySize(sDisplaySize: AvatarSize): this.type = js.native
  def setImageFitType(sImageFitType: AvatarImageFitType): this.type = js.native
  def setInitials(sInitials: String): this.type = js.native
  def setSrc(sSrc: URI): this.type = js.native
  def unbindDetailBox(): this.type = js.native
}
     