
package com.sap.scala.facades.openui5.core.support

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.support.Support


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.support.Plugin")
@js.native
class Plugin() extends Object {
//  def $(sSuffix: String): /*TODO Type: 'jQuery' not found.*/ = js.native
  def addStylesheet(sCssResourcePath: String): Unit = js.native
  def exit(oSupportStub: Support): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getId(): String = js.native
  def getMetadata(): Metadata = js.native
  def getTitle(): String = js.native
  def init(oSupportStub: Support): Unit = js.native
  def isActive(): Boolean = js.native
  def isAppPlugin(): Boolean = js.native
  def isToolPlugin(): Boolean = js.native
  def runsAsToolPlugin(): Boolean = js.native
}
     