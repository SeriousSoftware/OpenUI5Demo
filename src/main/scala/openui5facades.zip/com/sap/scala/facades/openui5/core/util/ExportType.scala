
package com.sap.scala.facades.openui5.core.util

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.util.Export


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.util.ExportType")
@js.native
class ExportType() extends ManagedObject {
  def _generate(oExport: Export): String = js.native
//  def cellGenerator(): /*TODO Type: 'Generator' not found.*/ = js.native
//  def columnGenerator(): /*TODO Type: 'Generator' not found.*/ = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def generate(): String = js.native
  def getByteOrderMark(): Boolean = js.native
  def getCharset(): String = js.native
  def getColumnCount(): Int = js.native
  def getFileExtension(): String = js.native
  def getMetadata(): Metadata = js.native
  def getMimeType(): String = js.native
  def getRowCount(): Int = js.native
//  def rowGenerator(): /*TODO Type: 'Generator' not found.*/ = js.native
  def setByteOrderMark(bByteOrderMark: Boolean): this.type = js.native
  def setCharset(sCharset: String): this.type = js.native
  def setFileExtension(sFileExtension: String): this.type = js.native
  def setMimeType(sMimeType: String): this.type = js.native
}
     