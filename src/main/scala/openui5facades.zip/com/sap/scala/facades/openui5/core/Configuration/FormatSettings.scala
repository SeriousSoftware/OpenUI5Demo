
package com.sap.scala.facades.openui5.core.Configuration

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.core.Locale


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.Configuration.FormatSettings")
@js.native
class FormatSettings() extends Object {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getDatePattern(): Unit = js.native
  def getFormatLocale(): Locale = js.native
//  def getLegacyDateCalendarCustomizing(): /*TODO Type: 'object[]' not found.*/ = js.native
  def getLegacyDateFormat(): Unit = js.native
  def getLegacyNumberFormat(): Unit = js.native
  def getLegacyTimeFormat(): Unit = js.native
  def getMetadata(): Metadata = js.native
  def getNumberSymbol(): Unit = js.native
  def getTimePattern(): Unit = js.native
  def setDatePattern(sStyle: String, sPattern: String): this.type = js.native
//  def setFirstDayOfWeek(iValue: /*TODO Type: 'number' not found.*/): this.type = js.native
//  def setLegacyDateCalendarCustomizing(aMappings: /*TODO Type: 'object[]' not found.*/): this.type = js.native
  def setLegacyDateFormat(sFormatId: String): this.type = js.native
  def setLegacyNumberFormat(sFormatId: String): this.type = js.native
  def setLegacyTimeFormat(sFormatId: String): this.type = js.native
  def setNumberSymbol(sStyle: String, sSymbol: String): this.type = js.native
  def setTimePattern(sStyle: String, sPattern: String): this.type = js.native
}
     