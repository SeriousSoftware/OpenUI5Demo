
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.Button
import com.sap.scala.facades.openui5.core.ID


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.ActionSelect")
@js.native
class ActionSelect() extends Select {
  def addButton(vButton: ID | Button): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getButtons(): js.Array[ID] = js.native
  def getMetadata(): Metadata = js.native
//  def removeAllButtons(): /*TODO Type: 'string[]' not found.*/ = js.native
  def removeButton(vButton: Int | String | Button): String = js.native
}
     