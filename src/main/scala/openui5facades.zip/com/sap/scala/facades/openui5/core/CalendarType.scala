package com.sap.scala.facades.openui5.core

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait CalendarType extends js.Object

object CalendarType{
  @JSGlobal("sap.ui.core.CalendarType.Gregorian")
  @js.native
  object Gregorian extends CalendarType

  @JSGlobal("sap.ui.core.CalendarType.Islamic")
  @js.native
  object Islamic extends CalendarType

  @JSGlobal("sap.ui.core.CalendarType.Japanese")
  @js.native
  object Japanese extends CalendarType

  @JSGlobal("sap.ui.core.CalendarType.Persian")
  @js.native
  object Persian extends CalendarType
}

/* copy to Enum.scala
sealed trait CalendarType{
  private[ui] def toFacade: sap.ui.core.CalendarType
}

object CalendarType {
  def fromFacade(s: ui.core.CalendarType): CalendarType = s match {
    case ui.core.CalendarType.Gregorian => CalendarType.Gregorian
    case ui.core.CalendarType.Islamic => CalendarType.Islamic
    case ui.core.CalendarType.Japanese => CalendarType.Japanese
    case ui.core.CalendarType.Persian => CalendarType.Persian
   case _ =>
     throw new UnsupportedOperationException(s"Unknown CalendarType: $s")
  }
  
  object Gregorian extends CalendarType {
    override private[ui] def toFacade: ui.core.CalendarType = ui.core.CalendarType.Gregorian
  }

  object Islamic extends CalendarType {
    override private[ui] def toFacade: ui.core.CalendarType = ui.core.CalendarType.Islamic
  }

  object Japanese extends CalendarType {
    override private[ui] def toFacade: ui.core.CalendarType = ui.core.CalendarType.Japanese
  }

  object Persian extends CalendarType {
    override private[ui] def toFacade: ui.core.CalendarType = ui.core.CalendarType.Persian
  }

}
*/
