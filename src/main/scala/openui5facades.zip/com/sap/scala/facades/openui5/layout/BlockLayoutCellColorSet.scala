package com.sap.scala.facades.openui5.layout

import scala.scalajs.js
import scala.scalajs.js.annotation.JSGlobal

@js.native
sealed trait BlockLayoutCellColorSet extends js.Object

object BlockLayoutCellColorSet{
  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet1")
  @js.native
  object ColorSet1 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet10")
  @js.native
  object ColorSet10 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet11")
  @js.native
  object ColorSet11 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet2")
  @js.native
  object ColorSet2 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet3")
  @js.native
  object ColorSet3 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet4")
  @js.native
  object ColorSet4 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet5")
  @js.native
  object ColorSet5 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet6")
  @js.native
  object ColorSet6 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet7")
  @js.native
  object ColorSet7 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet8")
  @js.native
  object ColorSet8 extends BlockLayoutCellColorSet

  @JSGlobal("sap.ui.layout.BlockLayoutCellColorSet.ColorSet9")
  @js.native
  object ColorSet9 extends BlockLayoutCellColorSet
}

/* copy to Enum.scala
sealed trait BlockLayoutCellColorSet{
  private[ui] def toFacade: sap.ui.layout.BlockLayoutCellColorSet
}

object BlockLayoutCellColorSet {
  def fromFacade(s: ui.layout.BlockLayoutCellColorSet): BlockLayoutCellColorSet = s match {
    case ui.layout.BlockLayoutCellColorSet.ColorSet1 => BlockLayoutCellColorSet.ColorSet1
    case ui.layout.BlockLayoutCellColorSet.ColorSet10 => BlockLayoutCellColorSet.ColorSet10
    case ui.layout.BlockLayoutCellColorSet.ColorSet11 => BlockLayoutCellColorSet.ColorSet11
    case ui.layout.BlockLayoutCellColorSet.ColorSet2 => BlockLayoutCellColorSet.ColorSet2
    case ui.layout.BlockLayoutCellColorSet.ColorSet3 => BlockLayoutCellColorSet.ColorSet3
    case ui.layout.BlockLayoutCellColorSet.ColorSet4 => BlockLayoutCellColorSet.ColorSet4
    case ui.layout.BlockLayoutCellColorSet.ColorSet5 => BlockLayoutCellColorSet.ColorSet5
    case ui.layout.BlockLayoutCellColorSet.ColorSet6 => BlockLayoutCellColorSet.ColorSet6
    case ui.layout.BlockLayoutCellColorSet.ColorSet7 => BlockLayoutCellColorSet.ColorSet7
    case ui.layout.BlockLayoutCellColorSet.ColorSet8 => BlockLayoutCellColorSet.ColorSet8
    case ui.layout.BlockLayoutCellColorSet.ColorSet9 => BlockLayoutCellColorSet.ColorSet9
   case _ =>
     throw new UnsupportedOperationException(s"Unknown BlockLayoutCellColorSet: $s")
  }
  
  object ColorSet1 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet1
  }

  object ColorSet10 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet10
  }

  object ColorSet11 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet11
  }

  object ColorSet2 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet2
  }

  object ColorSet3 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet3
  }

  object ColorSet4 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet4
  }

  object ColorSet5 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet5
  }

  object ColorSet6 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet6
  }

  object ColorSet7 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet7
  }

  object ColorSet8 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet8
  }

  object ColorSet9 extends BlockLayoutCellColorSet {
    override private[ui] def toFacade: ui.layout.BlockLayoutCellColorSet = ui.layout.BlockLayoutCellColorSet.ColorSet9
  }

}
*/
