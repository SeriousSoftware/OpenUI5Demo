
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.P13nGroupItem")
@js.native
class P13nGroupItem() extends Item {
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getColumnKey(): String = js.native
  def getMetadata(): Metadata = js.native
  def getOperation(): String = js.native
  def getShowIfGrouped(): Boolean = js.native
  def setColumnKey(sColumnKey: String): this.type = js.native
  def setOperation(sOperation: String): this.type = js.native
  def setShowIfGrouped(bShowIfGrouped: Boolean): this.type = js.native
}
     