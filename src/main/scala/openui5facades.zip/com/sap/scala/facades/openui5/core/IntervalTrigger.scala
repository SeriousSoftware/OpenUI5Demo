
package com.sap.scala.facades.openui5.core

import com.sap.scala.facades.openui5.base.Metadata


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.ui.core.IntervalTrigger")
@js.native
class IntervalTrigger() extends Object {
  def addListener(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): Unit = js.native
  def destroy(): Unit = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getInterface(): Unit = js.native
  def getMetadata(): Metadata = js.native
  def removeListener(fnFunction: js.Function1[Event[EventProps], Unit], oListener: Object): Unit = js.native
  def setInterval(iInterval: Int): Unit = js.native
}
     