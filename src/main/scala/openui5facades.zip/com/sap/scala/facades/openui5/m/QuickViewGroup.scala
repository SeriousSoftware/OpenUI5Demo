
package com.sap.scala.facades.openui5.m

import com.sap.scala.facades.openui5.base.Metadata
import com.sap.scala.facades.openui5.m.QuickViewGroupElement


import scala.scalajs.js
import scala.scalajs.js.{Array, |}
import scala.scalajs.js.annotation.{ScalaJSDefined, JSGlobal}

@JSGlobal("sap.m.QuickViewGroup")
@js.native
class QuickViewGroup() extends Element {
  def addElement(oElement: QuickViewGroupElement): this.type = js.native
  def bindElements(oBindingInfo: Object): this.type = js.native
  def destroyElements(): this.type = js.native
  def extend(sClassName: String, oClassInfo: Object, FNMetaImpl: js.Function1[Event[EventProps], Unit]): js.Function1[Event[EventProps], Unit] = js.native
  def getElements(): js.Array[QuickViewGroupElement] = js.native
  def getHeading(): String = js.native
  def getMetadata(): Metadata = js.native
  def getVisible(): Boolean = js.native
  def indexOfElement(oElement: QuickViewGroupElement): Int = js.native
  def insertElement(oElement: QuickViewGroupElement, iIndex: Int): this.type = js.native
  def removeAllElements(): js.Array[QuickViewGroupElement] = js.native
  def removeElement(vElement: Int | String | QuickViewGroupElement): QuickViewGroupElement = js.native
  def setHeading(sHeading: String): this.type = js.native
  def setVisible(bVisible: Boolean): this.type = js.native
  def unbindElements(): this.type = js.native
}
     